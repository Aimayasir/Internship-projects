// Layout.jsx
import React from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Users, 
  Utensils, 
  Dumbbell, 
  MessageSquare, 
  Bell, 
  BarChart2, 
  User, 
  Link2, 
  LogOut,
  ChevronRight,
  TrendingUp
} from 'lucide-react';

export const Layout = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/clients', label: 'Client Management', icon: Users },
    { path: '/nutrition', label: 'Meal Plan', icon: Utensils },
    { path: '/workouts', label: 'Workout Plan', icon: Dumbbell },
    { path: '/chat', label: 'Chat Thread', icon: MessageSquare },
    { path: '/notifications', label: 'Notifications', icon: Bell },
    { path: '/analytics', label: 'Analytics', icon: BarChart2 },
    { path: '/group-link', label: 'Group Link / Invite', icon: Link2 },
    { path: '/profile', label: 'Profile Settings', icon: User },
  ];

  // Helper to format breadcrumb matching paths
  const getBreadcrumbs = () => {
    const parts = location.pathname.split('/').filter(p => p);
    if (parts.length === 0) return ['Dashboard'];
    return parts.map(part => {
      // replace dash with space and capitalize
      const name = part.replace(/-/g, ' ');
      return name.charAt(0).toUpperCase() + name.slice(1);
    });
  };

  const breadcrumbs = getBreadcrumbs();

  return (
    <div className="app-container" style={{ display: 'flex', minHeight: '100vh', width: '100vw' }}>
      {/* Sidebar Navigation */}
      <aside style={{
        width: '280px',
        backgroundColor: 'var(--bg-dark)',
        color: 'var(--text-light)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        borderRight: '1px solid var(--border-color-dark)',
        flexShrink: 0
      }}>
        <div>
          {/* Brand Logo */}
          <div style={{
            padding: '2rem 1.5rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            borderBottom: '1px solid var(--border-color-dark)'
          }}>
            <div style={{
              backgroundColor: 'var(--accent-lime-vivid)',
              color: 'var(--bg-dark)',
              padding: '0.5rem',
              borderRadius: 'var(--radius-sm)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <TrendingUp size={24} />
            </div>
            <div>
              <h1 style={{ fontSize: '1.75rem', color: 'var(--text-light)' }}>FitTrack</h1>
              <span style={{ fontSize: '0.65rem', color: 'var(--accent-lime-vivid)', letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 900 }}>Trainer Portal</span>
            </div>
          </div>

          {/* Nav List */}
          <nav style={{ padding: '1.5rem 1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {navItems.map(item => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  style={({ isActive }) => ({
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '0.75rem 1rem',
                    borderRadius: 'var(--radius-md)',
                    color: isActive ? 'var(--bg-dark)' : 'var(--text-dim)',
                    backgroundColor: isActive ? 'var(--accent-lime-vivid)' : 'transparent',
                    textDecoration: 'none',
                    fontWeight: 700,
                    fontFamily: 'var(--font-heading)',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    fontSize: '0.95rem',
                    transition: 'all 0.15s ease'
                  })}
                  className={({ isActive }) => isActive ? 'active' : ''}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* User Info Footer block */}
        {user && (
          <div style={{
            padding: '1.5rem',
            borderTop: '1px solid var(--border-color-dark)',
            display: 'flex',
            flexDirection: 'column',
            gap: '1rem'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <img 
                src={user.photoUrl} 
                alt={user.name} 
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: 'var(--radius-sm)',
                  objectFit: 'cover',
                  border: '1px solid var(--border-color-dark)'
                }}
              />
              <div style={{ overflow: 'hidden' }}>
                <h4 style={{ fontSize: '1rem', color: 'var(--text-light)', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{user.name}</h4>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{user.email}</p>
              </div>
            </div>
            
            <button 
              onClick={handleLogout}
              className="btn btn-secondary"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                justifyContent: 'center',
                width: '100%',
                backgroundColor: '#141414',
                color: 'var(--text-light)',
                border: '1px solid var(--border-color-dark)',
                padding: '0.5rem 1rem'
              }}
            >
              <LogOut size={16} />
              <span>Sign Out</span>
            </button>
          </div>
        )}
      </aside>

      {/* Main Content Pane */}
      <main style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        overflow: 'hidden'
      }}>
        {/* Header Breadcrumbs bar */}
        <header style={{
          height: '70px',
          borderBottom: '1px solid var(--border-color)',
          backgroundColor: 'var(--bg-card)',
          display: 'flex',
          alignItems: 'center',
          padding: '0 2.5rem',
          justifyContent: 'space-between',
          flexShrink: 0
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)', fontWeight: 500 }}>FitTrack</span>
            {breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={crumb}>
                <ChevronRight size={14} className="text-dim" style={{ color: 'var(--text-dim)' }} />
                <span style={{ 
                  fontSize: '0.85rem', 
                  color: idx === breadcrumbs.length - 1 ? 'var(--text-main)' : 'var(--text-dim)',
                  fontWeight: idx === breadcrumbs.length - 1 ? '700' : '500'
                }}>
                  {crumb}
                </span>
              </React.Fragment>
            ))}
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span className="badge badge-lime">Trainer Online</span>
          </div>
        </header>
        
        {/* Page Container */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          backgroundColor: 'var(--bg-page)'
        }}>
          {children}
        </div>
      </main>
    </div>
  );
};
export default Layout;
