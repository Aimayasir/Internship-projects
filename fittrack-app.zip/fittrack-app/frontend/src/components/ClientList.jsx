// ClientList.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Utensils, Dumbbell, UserCheck, Calendar, Star } from 'lucide-react';

export const ClientList = ({ clients, view = 'grid', pathType = 'nutrition' }) => {
  const navigate = useNavigate();

  const handleClientClick = (clientId) => {
    navigate(`/${pathType}/assign/${clientId}`);
  };

  const getStatusColor = (status) => {
    if (status === 'active') return '#10B981';
    if (status === 'at_risk') return '#EF4444';
    return '#6B7280';
  };

  if (clients.length === 0) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem', color: 'var(--text-muted)' }}>
        <p style={{ fontSize: '1.25rem', fontWeight: 600 }}>No clients found matching the criteria.</p>
        <p style={{ fontSize: '0.9rem', color: 'var(--text-dim)', marginTop: '0.5rem' }}>Try refining your filters or search terms.</p>
      </div>
    );
  }

  if (view === 'list') {
    return (
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.95rem' }}>
          <thead>
            <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
              <th style={{ padding: '1rem' }}>Client</th>
              <th style={{ padding: '1rem' }}>Status</th>
              <th style={{ padding: '1rem' }}>Plan Type</th>
              <th style={{ padding: '1rem' }}>Adherence</th>
              <th style={{ padding: '1rem' }}>Joined Date</th>
              <th style={{ padding: '1rem', textTransform: 'uppercase', fontSize: '0.8rem', letterSpacing: '0.05em' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {clients.map(client => (
              <tr 
                key={client.id} 
                style={{ borderBottom: '1px solid var(--border-color)', transition: 'background 0.2s', cursor: 'pointer' }}
                onClick={() => handleClientClick(client.id)}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.01)'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <td style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  {client.photoUrl ? (
                    <img src={client.photoUrl} alt={client.name} style={{ width: '36px', height: '36px', borderRadius: '50%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ width: '36px', height: '36px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyCenter: 'center', fontWeight: 700 }}>
                      {client.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <div style={{ fontWeight: 600 }}>{client.name}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{client.email}</div>
                  </div>
                </td>
                <td style={{ padding: '1rem' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontWeight: 600, fontSize: '0.85rem', color: getStatusColor(client.status) }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: getStatusColor(client.status) }} />
                    {client.status.toUpperCase()}
                  </span>
                </td>
                <td style={{ padding: '1rem' }}>
                  <span className={`badge ${client.planType === 'custom' ? 'badge-blue' : client.planType === 'unassigned' ? 'badge-gray' : 'badge-lime'}`}>
                    {client.planType.replace('_', ' ')}
                  </span>
                </td>
                <td style={{ padding: '1rem', fontWeight: 700 }}>
                  <span style={{ color: client.adherence > 0.8 ? '#10B981' : client.adherence > 0.5 ? '#F59E0B' : '#EF4444' }}>
                    {Math.round(client.adherence * 100)}%
                  </span>
                </td>
                <td style={{ padding: '1rem', color: 'var(--text-muted)' }}>
                  {new Date(client.joinedAt).toLocaleDateString()}
                </td>
                <td style={{ padding: '1rem' }} onClick={(e) => e.stopPropagation()}>
                  <button className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem' }} onClick={() => handleClientClick(client.id)}>
                    Build Plan
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  // Grid/Card view (default)
  return (
    <div className="client-grid">
      {clients.map(client => (
        <div key={client.id} className="card drag-item" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }} onClick={() => handleClientClick(client.id)}>
          {/* Top Row with Profile & Status */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              {client.photoUrl ? (
                <img src={client.photoUrl} alt={client.name} style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', objectFit: 'cover' }} />
              ) : (
                <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.25rem', fontWeight: 700 }}>
                  {client.name.charAt(0)}
                </div>
              )}
              <div>
                <h3 style={{ fontSize: '1.2rem', fontFamily: 'var(--font-heading)' }}>{client.name}</h3>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>{client.email}</span>
              </div>
            </div>
            
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: 700, fontSize: '0.75rem', color: getStatusColor(client.status) }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: getStatusColor(client.status) }} />
              {client.status}
            </span>
          </div>

          {/* Stats Section */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', backgroundColor: 'var(--bg-page)', padding: '0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <div>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Adherence</div>
              <div style={{ fontSize: '1.15rem', fontWeight: 800, color: client.adherence > 0.8 ? '#10B981' : client.adherence > 0.5 ? '#F59E0B' : '#EF4444' }}>
                {Math.round(client.adherence * 100)}%
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Assigned Plan</div>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, marginTop: '0.15rem' }}>
                <span className={`badge ${client.planType === 'custom' ? 'badge-blue' : client.planType === 'unassigned' ? 'badge-gray' : 'badge-lime'}`} style={{ padding: '0.15rem 0.4rem', fontSize: '0.7rem' }}>
                  {client.planType.replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--border-color)', paddingTop: '0.75rem', marginTop: 'auto' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              <Calendar size={12} />
              Joined {new Date(client.joinedAt).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </span>
            
            <button className="btn btn-secondary" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem', display: 'flex', gap: '0.25rem' }}>
              {pathType === 'nutrition' ? <Utensils size={14} /> : <Dumbbell size={14} />}
              <span>Build Canvas</span>
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};
