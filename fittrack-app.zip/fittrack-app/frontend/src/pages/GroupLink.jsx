// GroupLink.jsx
import React, { useState, useEffect } from 'react';
import { apiClient } from '../api/apiClient';
import { Link2, Copy, Check, RotateCw, Calendar, Users, ChevronLeft, ChevronRight } from 'lucide-react';

export const GroupLink = () => {
  const [code, setCode] = useState('BILAL2026');
  const [link, setLink] = useState('https://fittrack.app/join/BILAL2026');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');

  // Join log pagination
  const [joins, setJoins] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [joinsLoading, setJoinsLoading] = useState(true);

  useEffect(() => {
    fetchInviteDetails();
    fetchJoinLog(1);
  }, []);

  const fetchInviteDetails = async () => {
    setLoading(true);
    const res = await apiClient.getInviteCurrent();

    if (res.success) {
      setCode(res.data.code);
      setLink(res.data.link);
    }
    setLoading(false);
  };

  const fetchJoinLog = async (pageNum) => {
    setJoinsLoading(true);
    const res = await apiClient.getInviteLog({ page: pageNum, limit: 3 });

    if (res.success) {
      setJoins(res.data.joins);
      setPage(res.data.pagination.page);
      setTotalPages(res.data.pagination.totalPages);
    }
    setJoinsLoading(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRegenerateCode = async () => {
    setLoading(true);
    const res = await apiClient.regenerateInviteCode();

    if (res.success) {
      setCode(res.data.code);
      setLink(res.data.link);
      setSuccess('Invite code has been successfully regenerated.');
      setTimeout(() => setSuccess(''), 3000);
    }
    setLoading(false);
  };

  return (
    <div className="main-content" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', alignItems: 'flex-start' }}>
      
      {/* Left Panel: Link Generation & Copy box */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <div>
          <h2 className="page-title" style={{ fontSize: '1.8rem' }}>Invite Code Onboarding</h2>
          <p className="page-subtitle">Generate invite codes or direct join links to onboard new clients.</p>
        </div>

        {success && (
          <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', color: '#10B981', border: '1px solid rgba(16, 185, 129, 0.2)', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', fontWeight: 600 }}>
            {success}
          </div>
        )}

        {loading ? (
          <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-dim)' }}>Generating new code...</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div>
              <label>Invite Code</label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginTop: '0.5rem' }}>
                <div style={{
                  backgroundColor: 'var(--bg-page)', border: '2px dashed var(--accent-lime)',
                  color: 'var(--accent-lime)', fontFamily: 'var(--font-heading)', fontSize: '2.25rem',
                  fontWeight: 900, padding: '0.5rem 2rem', borderRadius: 'var(--radius-md)', letterSpacing: '0.1em'
                }}>
                  {code}
                </div>
                <button className="btn btn-secondary" onClick={handleRegenerateCode} style={{ padding: '0.75rem' }}>
                  <RotateCw size={16} />
                </button>
              </div>
            </div>

            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1.25rem' }}>
              <label>Direct Join Onboarding Link</label>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: '0.25rem', marginBottom: '0.5rem' }}>
                Share this direct onboarding deep-link with prospects to fast-track mobile app attachment.
              </p>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input type="text" readOnly value={link} style={{ flex: 1, backgroundColor: 'var(--bg-page)' }} />
                <button className="btn btn-secondary" onClick={handleCopy} style={{ display: 'flex', gap: '0.25rem', minWidth: '100px' }}>
                  {copied ? <Check size={16} style={{ color: '#10B981' }} /> : <Copy size={16} />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Panel: Join log */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', minHeight: '340px' }}>
        <div>
          <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Users size={18} style={{ color: 'var(--accent-blue)' }} />
            <span>Client Onboarding Log</span>
          </h3>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: '0.25rem' }}>
            Paginated audit history of clients who successfully joined your workspace.
          </p>
        </div>

        {joinsLoading ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-dim)' }}>Loading log history...</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', flex: 1 }}>
            {joins.length === 0 ? (
              <div style={{ margin: 'auto', color: 'var(--text-dim)', fontSize: '0.9rem' }}>No joins recorded yet</div>
            ) : (
              joins.map(j => (
                <div 
                  key={j.clientId}
                  style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    border: '1px solid var(--border-color)', padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)',
                    backgroundColor: 'var(--bg-page)', fontSize: '0.9rem'
                  }}
                >
                  <div>
                    <strong style={{ color: 'var(--text-main)' }}>{j.clientName}</strong>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>ID: {j.clientId}</div>
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                    <Calendar size={12} />
                    {new Date(j.joinedAt).toLocaleDateString()} {new Date(j.joinedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))
            )}

            {/* Pagination controls */}
            {totalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                  Page {page} of {totalPages}
                </span>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button className="btn btn-secondary" disabled={page === 1} onClick={() => fetchJoinLog(page - 1)} style={{ padding: '0.35rem 0.75rem' }}>
                    <ChevronLeft size={16} />
                  </button>
                  <button className="btn btn-secondary" disabled={page === totalPages} onClick={() => fetchJoinLog(page + 1)} style={{ padding: '0.35rem 0.75rem' }}>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
};
export default GroupLink;
