// MealAssign.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { apiClient } from '../api/apiClient';
import { 
  Plus, 
  Trash2, 
  Save, 
  Utensils, 
  Search, 
  Sparkles, 
  AlertTriangle,
  RefreshCw,
  ArrowLeft,
  X,
  FileImage,
  ExternalLink,
  ChevronRight,
  GripVertical
} from 'lucide-react';

const getFoodEmoji = (name = '') => {
  const n = name.toLowerCase();
  if (n.includes('chicken') || n.includes('poultry')) return '🍗';
  if (n.includes('egg')) return '🍳';
  if (n.includes('rice') || n.includes('grain')) return '🍚';
  if (n.includes('oat') || n.includes('cereal') || n.includes('porridge')) return '🥣';
  if (n.includes('salmon') || n.includes('fish') || n.includes('seafood')) return '🐟';
  if (n.includes('salad') || n.includes('veg')) return '🥗';
  if (n.includes('avocado')) return '🥑';
  if (n.includes('apple') || n.includes('fruit')) return '🍎';
  if (n.includes('shake') || n.includes('whey') || n.includes('protein')) return '🥛';
  return '🥗';
};

export const MealAssign = () => {
  const { clientId } = useParams();
  const navigate = useNavigate();

  const [client, setClient] = useState(null);
  const [plan, setPlan] = useState(null);
  const [library, setLibrary] = useState([]);
  const [search, setSearch] = useState('');
  const [activeDay, setActiveDay] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Dialogs
  const [showPopup, setShowPopup] = useState(false);
  const [popupMode, setPopupMode] = useState('add'); // 'add' or 'edit'
  const [editingItem, setEditingItem] = useState(null);
  const [showConflictDialog, setShowConflictDialog] = useState(false);
  const [conflictData, setConflictData] = useState(null);
  const [showApplyDefaultDropdown, setShowApplyDefaultDropdown] = useState(false);

  // Global Library Add Modal State
  const [showLibraryAddModal, setShowLibraryAddModal] = useState(false);
  const [libName, setLibName] = useState('');
  const [libCalories, setLibCalories] = useState('');
  const [libProtein, setLibProtein] = useState('');
  const [libCarbs, setLibCarbs] = useState('');
  const [libFat, setLibFat] = useState('');
  const [libUnit, setLibUnit] = useState('g');
  const [libQty, setLibQty] = useState('100');

  // Popup Form Fields
  const [formName, setFormName] = useState('');
  const [formCalories, setFormCalories] = useState('');
  const [formQuantity, setFormQuantity] = useState('');
  const [formUnit, setFormUnit] = useState('g');
  const [formProtein, setFormProtein] = useState('');
  const [formCarbs, setFormCarbs] = useState('');
  const [formFat, setFormFat] = useState('');
  const [formLink, setFormLink] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formTargetSlot, setFormTargetSlot] = useState('breakfast');
  const fileInputRef = useRef(null);

  // Drag and Drop State
  const [draggedSidebarItem, setDraggedSidebarItem] = useState(null);
  const [draggedCanvasItem, setDraggedCanvasItem] = useState(null);
  const [draggedSourceSlot, setDraggedSourceSlot] = useState(null);
  const [activeDragSlot, setActiveDragSlot] = useState(null);

  useEffect(() => {
    fetchClientAndPlan();
    fetchLibrary();
  }, [clientId, search]);

  const fetchClientAndPlan = async () => {
    setLoading(true);
    const clientRes = await apiClient.getClientById(clientId);
    if (clientRes.success) {
      setClient(clientRes.data);
    } else {
      setError(clientRes.error.message);
    }

    const planRes = await apiClient.getNutritionClientPlan(clientId);
    if (planRes.success) {
      setPlan(planRes.data);
    } else {
      // If plan not found, customize/create an empty plan structure
      const custRes = await apiClient.customizeNutrition(clientId);
      if (custRes.success) {
        setPlan(custRes.data);
      }
    }
    setLoading(false);
  };

  const fetchLibrary = async () => {
    const res = await apiClient.getNutritionLibrary({ search });
    if (res.success) {
      setLibrary(res.data.foods);
    }
  };

  // Add Item to Canvas directly from Sidebar library
  const handleAddFoodToSlot = async (foodId, slot) => {
    const res = await apiClient.addNutritionItem(clientId, {
      day: activeDay,
      mealSlot: slot,
      foodId,
      quantity: 100,
      unit: 'g'
    });
    if (res.success) {
      // Refresh current client plan state
      const planRes = await apiClient.getNutritionClientPlan(clientId);
      if (planRes.success) {
        setPlan(planRes.data);
      }
    }
  };

  // Apply default plan variant
  const handleApplyDefault = async (type) => {
    setLoading(true);
    setShowApplyDefaultDropdown(false);
    const res = await apiClient.applyDefaultNutrition(clientId, type);
    if (res.success) {
      setPlan(res.data);
      setSuccess(`Applied default ${type.replace('_', ' ')} plan!`);
      setTimeout(() => setSuccess(''), 3000);
    } else {
      setError(res.error.message);
    }
    setLoading(false);
  };

  // Inline inputs edit helpers
  const handleInlineEdit = (slot, itemId, field, value) => {
    if (!plan) return;
    const updated = { ...plan };
    const dayObj = updated.days.find(d => d.day === activeDay);
    if (!dayObj) return;

    const items = dayObj.meals[slot];
    const item = items.find(i => i.id === itemId);
    if (item) {
      if (field === 'quantity') {
        const oldQty = Number(item.quantity) || 1;
        const newQty = Number(value) || 0;
        const ratio = newQty / oldQty;
        item.quantity = newQty;
        // Scale macros authoritatively on client side for live updates
        item.calories = Math.round(item.calories * ratio);
        item.protein = Math.round(item.protein * ratio);
        item.carbs = Math.round(item.carbs * ratio);
        item.fat = Math.round(item.fat * ratio);
      } else if (field === 'calories') {
        item.calories = Number(value) || 0;
      } else {
        item[field] = value;
      }
    }
    setPlan(updated);
    recalculateClientTotals();
  };

  const recalculateClientTotals = () => {
    if (!plan) return;
    let cal = 0, prot = 0, carb = 0, fat = 0;
    plan.days.forEach(d => {
      Object.keys(d.meals).forEach(slot => {
        d.meals[slot].forEach(item => {
          cal += Number(item.calories || 0);
          prot += Number(item.protein || 0);
          carb += Number(item.carbs || 0);
          fat += Number(item.fat || 0);
        });
      });
    });
    setPlan({
      ...plan,
      totals: { calories: cal, protein: prot, carbs: carb, fat: fat }
    });
  };

  // One click remove from canvas
  const handleRemoveItem = (slot, itemId) => {
    if (!plan) return;
    const updated = { ...plan };
    const dayObj = updated.days.find(d => d.day === activeDay);
    if (!dayObj) return;

    dayObj.meals[slot] = dayObj.meals[slot].filter(i => i.id !== itemId);
    setPlan(updated);
    recalculateClientTotals();
  };

  // Submit customization changes (authoritative sync)
  const handleSavePlan = async () => {
    if (!plan) return;
    setSaving(true);
    setError('');
    setSuccess('');

    const res = await apiClient.updateNutritionPlan(clientId, plan);
    if (res.success) {
      setPlan(res.data);
      setSuccess('Nutrition plan saved successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } else if (res.status === 409) {
      // 409 VERSION_CONFLICT
      setConflictData(res.error.currentPlan);
      setShowConflictDialog(true);
    } else {
      setError(res.error.message || 'Failed to save plan');
    }
    setSaving(false);
  };

  // Resolve conflict by pulling server data
  const handleResolveConflict = () => {
    if (conflictData) {
      setPlan(conflictData);
      setShowConflictDialog(false);
      setError('Pulled latest plan version from server. Please reapply changes and save.');
      setTimeout(() => setError(''), 5000);
    }
  };

  // Custom Item Popup Form Submit
  const handlePopupSubmit = async (e) => {
    e.preventDefault();
    if (!plan) return;
    
    const customFood = {
      name: formName,
      imageUrl: formImage || 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=150',
      calories: Number(formCalories) || 0,
      protein: Number(formProtein) || 0,
      carbs: Number(formCarbs) || 0,
      fat: Number(formFat) || 0,
      referenceLink: formLink
    };

    if (popupMode === 'add') {
      const res = await apiClient.addNutritionItem(clientId, {
        day: activeDay,
        mealSlot: formTargetSlot,
        quantity: Number(formQuantity) || 1,
        unit: formUnit || 'g',
        customItem: customFood
      });
      
      if (res.success) {
        const planRes = await apiClient.getNutritionClientPlan(clientId);
        if (planRes.success) {
          setPlan(planRes.data);
        }
      }
    } else {
      // Edit existing canvas item
      const updated = { ...plan };
      const dayObj = updated.days.find(d => d.day === activeDay);
      if (dayObj) {
        const slotItems = dayObj.meals[formTargetSlot] || [];
        const idx = slotItems.findIndex(i => i.id === editingItem.id);
        if (idx !== -1) {
          slotItems[idx] = {
            ...slotItems[idx],
            name: formName,
            imageUrl: formImage || slotItems[idx].imageUrl,
            quantity: Number(formQuantity),
            unit: formUnit,
            calories: Number(formCalories),
            protein: Number(formProtein),
            carbs: Number(formCarbs),
            fat: Number(formFat),
            referenceLink: formLink
          };
        }
      }
      setPlan(updated);
      recalculateClientTotals();
    }

    setShowPopup(false);
    resetForm();
  };

  const handleLibraryAddSubmit = async (e) => {
    e.preventDefault();
    const newFood = {
      id: `food_${Date.now()}`,
      name: libName,
      imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=150',
      defaultUnit: libUnit,
      defaultQuantity: Number(libQty) || 100,
      calories: Number(libCalories) || 0,
      protein: Number(libProtein) || 0,
      carbs: Number(libCarbs) || 0,
      fat: Number(libFat) || 0
    };

    const saved = localStorage.getItem('foodLibrary');
    const list = saved ? JSON.parse(saved) : [];
    list.push(newFood);
    localStorage.setItem('foodLibrary', JSON.stringify(list));

    setLibName('');
    setLibCalories('');
    setLibProtein('');
    setLibCarbs('');
    setLibFat('');
    setLibUnit('g');
    setLibQty('100');

    setShowLibraryAddModal(false);
    fetchLibrary();
  };

  const openAddPopup = (slot = 'breakfast') => {
    setPopupMode('add');
    setFormTargetSlot(slot);
    resetForm();
    setShowPopup(true);
  };

  const openEditPopup = (slot, item) => {
    setPopupMode('edit');
    setEditingItem(item);
    setFormTargetSlot(slot);
    setFormName(item.name);
    setFormCalories(item.calories);
    setFormQuantity(item.quantity);
    setFormUnit(item.unit || 'g');
    setFormProtein(item.protein || 0);
    setFormCarbs(item.carbs || 0);
    setFormFat(item.fat || 0);
    setFormLink(item.referenceLink || '');
    setFormImage(item.imageUrl || '');
    setShowPopup(true);
  };

  const resetForm = () => {
    setFormName('');
    setFormCalories('');
    setFormQuantity('');
    setFormUnit('g');
    setFormProtein('');
    setFormCarbs('');
    setFormFat('');
    setFormLink('');
    setFormImage('');
  };

  const handleSimulateImageUpload = () => {
    // Generate a random Unsplash food image
    const imgs = [
      'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=150',
      'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=150',
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=150',
      'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?auto=format&fit=crop&q=80&w=150'
    ];
    const rand = imgs[Math.floor(Math.random() * imgs.length)];
    setFormImage(rand);
  };

  // --- NATIVE HTML5 DRAG & DROP LOGIC ---
  const handleDragStartSidebar = (food) => {
    setDraggedSidebarItem(food);
    setDraggedCanvasItem(null);
  };

  const handleDragStartCanvas = (slot, item) => {
    setDraggedCanvasItem(item);
    setDraggedSourceSlot(slot);
    setDraggedSidebarItem(null);
  };

  const handleDragOver = (e, slot) => {
    e.preventDefault();
    setActiveDragSlot(slot);
  };

  const handleDragLeave = () => {
    setActiveDragSlot(null);
  };

  const handleDrop = async (e, destSlot) => {
    e.preventDefault();
    setActiveDragSlot(null);

    // Case 1: Dragging from Sidebar Library to Canvas slot
    if (draggedSidebarItem) {
      await handleAddFoodToSlot(draggedSidebarItem.id, destSlot);
      setDraggedSidebarItem(null);
    } 
    // Case 2: Dragging canvas item across slots or reordering within a slot
    else if (draggedCanvasItem && draggedSourceSlot) {
      if (!plan) return;
      const updated = { ...plan };
      const dayObj = updated.days.find(d => d.day === activeDay);
      if (!dayObj) return;

      // Remove from source slot
      dayObj.meals[draggedSourceSlot] = dayObj.meals[draggedSourceSlot].filter(i => i.id !== draggedCanvasItem.id);
      
      // Add to destination slot
      if (!dayObj.meals[destSlot]) dayObj.meals[destSlot] = [];
      
      // Insert at the end of the slot
      const newItem = { ...draggedCanvasItem, orderIndex: dayObj.meals[destSlot].length };
      dayObj.meals[destSlot].push(newItem);

      setPlan(updated);
      recalculateClientTotals();
      setDraggedCanvasItem(null);
      setDraggedSourceSlot(null);
    }
  };

  return (
    <div className="main-content" style={{ padding: '2rem 1.5rem', display: 'flex', flexDirection: 'column', height: 'calc(100vh - 70px)' }}>
      {/* Top Banner Row */}
      <div className="page-header" style={{ flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <button className="btn btn-secondary" onClick={() => navigate('/nutrition')} style={{ padding: '0.5rem' }}>
            <ArrowLeft size={16} />
          </button>
          <div>
            <h2 className="page-title">{client ? `${client.name}'s Meal Plan` : 'Meal Plan Canvas'}</h2>
            <p className="page-subtitle">Configure days, drag foods, and review macro targets live.</p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', position: 'relative' }}>
          {/* Apply Defaults Dropdown */}
          <div style={{ position: 'relative' }}>
            <button className="btn btn-secondary" onClick={() => setShowApplyDefaultDropdown(!showApplyDefaultDropdown)}>
              <Sparkles size={16} />
              <span>Apply Default</span>
            </button>
            {showApplyDefaultDropdown && (
              <div style={{
                position: 'absolute', top: '100%', right: 0, marginTop: '0.5rem',
                backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-lg)', zIndex: 100, width: '180px',
                display: 'flex', flexDirection: 'column', overflow: 'hidden'
              }}>
                <button 
                  onClick={() => handleApplyDefault('fat_loss')}
                  style={{ border: 'none', background: 'none', padding: '0.75rem 1rem', textAlign: 'left', cursor: 'pointer', fontFamily: 'var(--font-heading)', textTransform: 'uppercase', fontWeight: 700 }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = 'var(--bg-page)'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
                >
                  Fat Loss Plan
                </button>
                <button 
                  onClick={() => handleApplyDefault('weight_gain')}
                  style={{ border: 'none', background: 'none', padding: '0.75rem 1rem', textAlign: 'left', cursor: 'pointer', fontFamily: 'var(--font-heading)', textTransform: 'uppercase', fontWeight: 700 }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = 'var(--bg-page)'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
                >
                  Weight Gain Plan
                </button>
              </div>
            )}
          </div>

          <button className="btn btn-secondary" onClick={() => openAddPopup('breakfast')}>
            <Plus size={16} />
            <span>Add Custom</span>
          </button>

          <button className="btn btn-primary" onClick={handleSavePlan} disabled={saving}>
            <Save size={16} />
            <span>{saving ? 'Saving...' : 'Save Plan'}</span>
          </button>
        </div>
      </div>

      {/* Messages */}
      {error && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)', color: 'var(--accent-red)', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {error}
        </div>
      )}
      {success && (
        <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)', color: '#10B981', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {success}
        </div>
      )}

      {/* Day Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0, overflowX: 'auto', paddingBottom: '0.25rem', borderBottom: '1px solid var(--border-color)', marginBottom: '1rem' }}>
        {[1, 2, 3, 4, 5, 6, 7].map(d => (
          <button
            key={d}
            onClick={() => setActiveDay(d)}
            style={{
              padding: '0.5rem 1.25rem', border: 'none', background: activeDay === d ? 'var(--bg-dark)' : 'transparent',
              color: activeDay === d ? 'var(--accent-lime-vivid)' : 'var(--text-muted)',
              fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: '1rem', textTransform: 'uppercase',
              borderRadius: 'var(--radius-md)', cursor: 'pointer', transition: 'all 0.15s'
            }}
          >
            Day {d}
          </button>
        ))}
      </div>

      {/* Main Canvas Body Grid */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-dim)', flex: 1 }}>Loading Client Plan...</div>
      ) : (
        <div style={{ display: 'flex', gap: '1.5rem', flex: 1, minHeight: 0 }}>
          {/* Left Panel: Searchable Food Library */}
          <div style={{ width: '320px', display: 'flex', flexDirection: 'column', gap: '1rem', flexShrink: 0, height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)' }}>Food Library</h3>
              <button 
                className="btn btn-secondary" 
                onClick={() => setShowLibraryAddModal(true)}
                style={{ padding: '0.25rem 0.5rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
              >
                <Plus size={12} />
                <span>New Food</span>
              </button>
            </div>
            <div style={{ position: 'relative' }}>
              <Search size={16} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
              <input 
                type="text" 
                placeholder="Search food library..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ paddingLeft: '2.25rem', fontSize: '0.85rem' }}
              />
            </div>
            
            <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.75rem', paddingRight: '0.25rem' }}>
              {library.map(food => (
                <div
                  key={food.id}
                  draggable
                  onDragStart={() => handleDragStartSidebar(food)}
                  style={{
                    backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)',
                    padding: '0.75rem', borderRadius: 'var(--radius-md)', display: 'flex', gap: '0.75rem',
                    cursor: 'grab', transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--text-dim)'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border-color)'}
                >
                  <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden', position: 'relative' }}>
                    {food.imageUrl ? (
                      <img 
                        src={food.imageUrl} 
                        alt="" 
                        onError={(e) => { e.target.style.display = 'none'; }}
                        style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0, zIndex: 2 }} 
                      />
                    ) : null}
                    <span style={{ fontSize: '1.5rem', zIndex: 1 }}>{getFoodEmoji(food.name)}</span>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      {food.name}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.15rem' }}>
                      {food.calories} kcal | P: {food.protein}g | C: {food.carbs}g | F: {food.fat}g
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel: Day/Meal-slot Canvas */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '1.25rem', height: '100%', minWidth: 0 }}>
            {/* Macro Summary Totals Bar */}
            {plan && plan.totals && (
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                backgroundColor: 'var(--bg-dark)', color: 'var(--text-light)', padding: '1rem 1.5rem',
                borderRadius: 'var(--radius-lg)', flexShrink: 0
              }}>
                <div>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Authoritative Total</span>
                  <div style={{ fontSize: '1.75rem', fontFamily: 'var(--font-heading)', color: 'var(--accent-lime-vivid)', display: 'flex', alignItems: 'baseline', gap: '0.25rem' }}>
                    {plan.totals.calories} <span style={{ fontSize: '0.8rem', color: 'var(--text-light)' }}>kcal</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '2rem' }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Protein</div>
                    <div style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', fontWeight: 700 }}>{plan.totals.protein}g</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Carbs</div>
                    <div style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', fontWeight: 700 }}>{plan.totals.carbs}g</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Fat</div>
                    <div style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', fontWeight: 700 }}>{plan.totals.fat}g</div>
                  </div>
                </div>
              </div>
            )}

            {/* Drag slots */}
            <div style={{
              flex: 1, overflowY: 'auto', display: 'grid', gridTemplateColumns: '1fr 1fr',
              gap: '1.25rem', contentVisibility: 'auto', paddingRight: '0.25rem'
            }}>
              {['breakfast', 'lunch', 'dinner', 'snacks'].map(slot => {
                const dayObj = plan?.days.find(d => d.day === activeDay);
                const slotItems = dayObj?.meals[slot] || [];
                const isOver = activeDragSlot === slot;

                // Emojis / Icons mapping for slots
                const slotIcons = {
                  breakfast: '☕ BREAKFAST',
                  lunch: '☀️ LUNCH',
                  dinner: '🌙 DINNER',
                  snacks: '🍎 SNACKS'
                };

                return (
                  <div
                    key={slot}
                    onDragOver={(e) => handleDragOver(e, slot)}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, slot)}
                    style={{
                      backgroundColor: 'var(--bg-card)', border: isOver ? '2px dashed var(--accent-blue)' : '1px solid var(--border-color)',
                      borderRadius: 'var(--radius-lg)', padding: '1.25rem', display: 'flex', flexDirection: 'column',
                      gap: '0.75rem', position: 'relative', minHeight: '190px', transition: 'all 0.15s',
                      boxShadow: isOver ? 'var(--shadow-lg)' : 'none'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem' }}>
                      <h4 style={{ fontSize: '1.1rem', color: 'var(--text-main)', fontFamily: 'var(--font-heading)', letterSpacing: '0.03em' }}>
                        <span>{slotIcons[slot]}</span>
                      </h4>
                      <button 
                        onClick={() => openAddPopup(slot)}
                        style={{ border: 'none', background: 'none', display: 'flex', cursor: 'pointer', color: 'var(--text-dim)' }}
                        onMouseEnter={(e) => e.currentTarget.style.color = 'var(--text-main)'}
                        onMouseLeave={(e) => e.currentTarget.style.color = 'var(--text-dim)'}
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    {/* Canvas slot items list */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', flex: 1 }}>
                      {slotItems.length === 0 ? (
                        <div style={{ margin: 'auto', fontSize: '0.8rem', color: 'var(--text-dim)', textAlign: 'center' }}>
                          Drag foods here or click +
                        </div>
                      ) : (
                        slotItems.map(item => (
                          <div
                            key={item.id}
                            draggable
                            onDragStart={() => handleDragStartCanvas(slot, item)}
                            style={{
                              display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem',
                              border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                              backgroundColor: 'var(--bg-page)', fontSize: '0.85rem'
                            }}
                          >
                            {/* Drag handle */}
                            <div style={{ color: 'var(--text-dim)', cursor: 'grab', display: 'flex' }}>
                              <GripVertical size={16} />
                            </div>
                            
                            <div style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden', position: 'relative' }}>
                              {item.imageUrl ? (
                                <img 
                                  src={item.imageUrl} 
                                  alt="" 
                                  onError={(e) => { e.target.style.display = 'none'; }}
                                  style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0, zIndex: 2 }} 
                                />
                              ) : null}
                              <span style={{ fontSize: '1rem', zIndex: 1 }}>{getFoodEmoji(item.name)}</span>
                            </div>
                            
                            {/* Name Edit field */}
                            <input 
                              type="text" 
                              value={item.name} 
                              onChange={(e) => handleInlineEdit(slot, item.id, 'name', e.target.value)}
                              style={{ border: 'none', background: 'transparent', padding: '0.25rem 0.5rem', fontWeight: 700, width: '110px', fontSize: '0.85rem' }}
                            />

                            {/* Qty Edit field */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.15rem', marginLeft: 'auto', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-sm)', padding: '0.2rem 0.4rem' }}>
                              <input 
                                type="number" 
                                value={item.quantity} 
                                onChange={(e) => handleInlineEdit(slot, item.id, 'quantity', e.target.value)}
                                style={{ border: 'none', background: 'transparent', padding: 0, width: '35px', textAlign: 'right', fontWeight: 800, fontSize: '0.8rem' }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontSize: '0.65rem', fontWeight: 700 }}>{item.unit}</span>
                            </div>

                            {/* Calorie Edit field */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.15rem', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-sm)', padding: '0.2rem 0.4rem' }}>
                              <span style={{ fontSize: '0.7rem' }}>🔥</span>
                              <input 
                                type="number" 
                                value={item.calories} 
                                onChange={(e) => handleInlineEdit(slot, item.id, 'calories', e.target.value)}
                                style={{ border: 'none', background: 'transparent', padding: 0, width: '40px', textAlign: 'right', color: 'var(--text-main)', fontWeight: 800, fontSize: '0.8rem' }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontSize: '0.65rem', fontWeight: 700 }}>kcal</span>
                            </div>

                            {/* Reference Link if available */}
                            {item.referenceLink && (
                              <a href={item.referenceLink} target="_blank" rel="noreferrer" style={{ color: 'var(--accent-blue)', display: 'flex', padding: '0.25rem' }}>
                                <ExternalLink size={12} />
                              </a>
                            )}

                            {/* Edit Popup Link */}
                            <button 
                              onClick={() => openEditPopup(slot, item)}
                              style={{ border: 'none', background: 'none', color: 'var(--text-dim)', cursor: 'pointer', padding: '0.25rem', fontSize: '0.75rem' }}
                            >
                              Edit
                            </button>

                            {/* Remove button */}
                            <button 
                              onClick={() => handleRemoveItem(slot, item.id)}
                              style={{ border: 'none', background: 'none', color: 'var(--accent-red)', cursor: 'pointer', display: 'flex', padding: '0.25rem' }}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* --- ADD / EDIT FOOD POPUP --- */}
      {showPopup && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '480px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>
                {popupMode === 'add' ? `Add meal to ${formTargetSlot}` : 'Edit meal properties'}
              </h3>
              <button onClick={() => setShowPopup(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handlePopupSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label>Meal Name</label>
                <input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} required placeholder="e.g. Avocado Toast with Egg" style={{ marginTop: '0.25rem' }} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Quantity</label>
                  <input type="number" value={formQuantity} onChange={(e) => setFormQuantity(e.target.value)} required placeholder="150" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Unit</label>
                  <input type="text" value={formUnit} onChange={(e) => setFormUnit(e.target.value)} required placeholder="g, pcs, scoop" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Calories (kcal)</label>
                  <input type="number" value={formCalories} onChange={(e) => setFormCalories(e.target.value)} required placeholder="250" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Protein (g)</label>
                  <input type="number" value={formProtein} onChange={(e) => setFormProtein(e.target.value)} placeholder="15" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Carbs (g)</label>
                  <input type="number" value={formCarbs} onChange={(e) => setFormCarbs(e.target.value)} placeholder="30" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Fat (g)</label>
                  <input type="number" value={formFat} onChange={(e) => setFormFat(e.target.value)} placeholder="8" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div>
                <label>Reference Link (Recipe / Details)</label>
                <input type="url" value={formLink} onChange={(e) => setFormLink(e.target.value)} placeholder="https://example.com/recipe" style={{ marginTop: '0.25rem' }} />
              </div>

              <div>
                <label>Meal Image (Simulated upload)</label>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.25rem' }}>
                  <button type="button" className="btn btn-secondary" onClick={handleSimulateImageUpload} style={{ display: 'flex', gap: '0.25rem', fontSize: '0.85rem', flex: 1 }}>
                    <FileImage size={14} />
                    <span>Upload Image</span>
                  </button>
                  {formImage && <span style={{ fontSize: '0.75rem', color: '#10B981', alignSelf: 'center' }}>Uploaded ✔</span>}
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                {popupMode === 'add' ? 'Add Item to Slot' : 'Update Item'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- VERSION CONFLICT DIALOG --- */}
      {showConflictDialog && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '400px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)', textAlign: 'center'
          }}>
            <div style={{ color: 'var(--accent-red)', display: 'flex', justifyContent: 'center' }}>
              <AlertTriangle size={48} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>Version Conflict</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.5rem', lineHeight: 1.4 }}>
                This client's meal plan was updated on another device while you were editing. Overwriting now would lose their updates.
              </p>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', width: '100%' }}>
              <button className="btn btn-primary" onClick={handleResolveConflict} style={{ width: '100%' }}>
                <RefreshCw size={16} />
                <span>Pull Server Version</span>
              </button>
              <button className="btn btn-secondary" onClick={() => setShowConflictDialog(false)} style={{ width: '100%' }}>
                <span>Cancel</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- ADD TO GLOBAL FOOD LIBRARY MODAL --- */}
      {showLibraryAddModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '440px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>Create Library Food</h3>
              <button onClick={() => setShowLibraryAddModal(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleLibraryAddSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label>Food Item Name</label>
                <input type="text" value={libName} onChange={(e) => setLibName(e.target.value)} required placeholder="e.g. Avocado Toast" style={{ marginTop: '0.25rem' }} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Default Quantity</label>
                  <input type="number" value={libQty} onChange={(e) => setLibQty(e.target.value)} required placeholder="100" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Measuring Unit</label>
                  <input type="text" value={libUnit} onChange={(e) => setLibUnit(e.target.value)} required placeholder="g, ml, piece" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Calories (kcal)</label>
                  <input type="number" value={libCalories} onChange={(e) => setLibCalories(e.target.value)} required placeholder="160" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Protein (g)</label>
                  <input type="number" value={libProtein} onChange={(e) => setLibProtein(e.target.value)} required placeholder="2" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Carbohydrates (g)</label>
                  <input type="number" value={libCarbs} onChange={(e) => setLibCarbs(e.target.value)} required placeholder="9" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Fats (g)</label>
                  <input type="number" value={libFat} onChange={(e) => setLibFat(e.target.value)} required placeholder="15" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                Save to Library Database
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default MealAssign;
