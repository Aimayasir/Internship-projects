// Clients.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/apiClient';
import { 
  Search, 
  Plus, 
  Trash2, 
  Edit, 
  UserCheck, 
  Calendar, 
  LayoutGrid, 
  List, 
  X, 
  User, 
  Phone, 
  Mail, 
  Activity, 
  ChevronRight,
  TrendingDown
} from 'lucide-react';

export const Clients = () => {
  const navigate = useNavigate();

  const [clients, setClients] = useState([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [planTypeFilter, setPlanTypeFilter] = useState('all');
  const [view, setView] = useState('grid');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Selected Clients for Bulk Actions
  const [selectedClients, setSelectedClients] = useState([]);

  // Detail Modal / Sidebar drawer
  const [selectedClientDetail, setSelectedClientDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Manual Add Form Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');

  // Edit fields inside detail drawer
  const [editMode, setEditMode] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editStatus, setEditStatus] = useState('active');

  useEffect(() => {
    fetchClients();
  }, [search, planTypeFilter]);

  const fetchClients = async () => {
    setLoading(true);
    // GET /clients
    const res = await apiClient.getClients({ 
      search, 
      planType: planTypeFilter,
      limit: 100 // fetch all for manual display
    });
    if (res.success) {
      let filtered = res.data.clients;
      if (statusFilter !== 'all') {
        filtered = filtered.filter(c => c.status === statusFilter);
      }
      setClients(filtered);
    } else {
      setError(res.error.message);
    }
    setLoading(false);
  };

  const handleStatusFilterChange = (e) => {
    setStatusFilter(e.target.value);
    // Re-trigger clients filter local
    setSelectedClients([]);
  };

  useEffect(() => {
    fetchClients();
  }, [statusFilter]);

  // Click Client -> Drawer detail view
  const handleClientClick = async (clientId) => {
    setDetailLoading(true);
    // GET /clients/:clientId
    const res = await apiClient.getClientById(clientId);
    if (res.success) {
      setSelectedClientDetail(res.data);
      setEditName(res.data.name);
      setEditPhone(res.data.phone);
      setEditStatus(res.data.status);
    } else {
      setError(res.error.message);
    }
    setDetailLoading(false);
  };

  // Submit Manual Add
  const handleManualAddSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    // POST /clients/manual
    const res = await apiClient.addClientManual({ name: newName, email: newEmail, phone: newPhone });
    
    if (res.success) {
      setSuccess(`Client "${newName}" added as pending onboarding.`);
      setShowAddModal(false);
      setNewName('');
      setNewEmail('');
      setNewPhone('');
      fetchClients();
      setTimeout(() => setSuccess(''), 3000);
    } else {
      setError(res.error.message);
    }
  };

  // Edit details handler
  const handleEditDetailsSubmit = async (e) => {
    e.preventDefault();
    if (!selectedClientDetail) return;
    
    // PATCH /clients/:clientId
    const res = await apiClient.updateClient(selectedClientDetail.id, { name: editName, phone: editPhone, status: editStatus });

    if (res.success) {
      setSelectedClientDetail(res.data);
      setEditMode(false);
      setSuccess('Client profile updated successfully.');
      fetchClients();
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Delete client
  const handleDeleteClient = async (clientId) => {
    if (!window.confirm('Are you sure you want to remove this client? This cannot be undone.')) return;
    
    // DELETE /clients/:clientId
    const res = await apiClient.deleteClient(clientId);

    if (res.success) {
      setSuccess('Client removed successfully.');
      setSelectedClientDetail(null);
      fetchClients();
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Bulk Actions
  const handleToggleSelectClient = (e, id) => {
    e.stopPropagation();
    if (selectedClients.includes(id)) {
      setSelectedClients(selectedClients.filter(cid => cid !== id));
    } else {
      setSelectedClients([...selectedClients, id]);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedClients.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete the ${selectedClients.length} selected clients?`)) return;

    await Promise.all(selectedClients.map(cid => apiClient.deleteClient(cid)));

    setSuccess(`Successfully removed ${selectedClients.length} clients.`);
    setSelectedClients([]);
    fetchClients();
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleBulkStatusChange = async (status) => {
    if (selectedClients.length === 0) return;
    
    await Promise.all(selectedClients.map(cid => apiClient.updateClient(cid, { status })));

    setSuccess(`Bulk updated ${selectedClients.length} clients to status: ${status}.`);
    setSelectedClients([]);
    fetchClients();
    setTimeout(() => setSuccess(''), 3000);
  };

  const getStatusColor = (status) => {
    if (status === 'active') return '#10B981';
    if (status === 'at_risk') return '#EF4444';
    return '#6B7280';
  };

  return (
    <div className="main-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', height: 'calc(100vh - 70px)' }}>
      {/* Header section */}
      <div className="page-header" style={{ flexShrink: 0 }}>
        <div>
          <h2 className="page-title">Client Management</h2>
          <p className="page-subtitle">Filter, audit compliance, or bulk manage client profiles.</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/group-link')}>
          <Plus size={16} />
          <span>Get Invite Link</span>
        </button>
      </div>

      {/* Messages */}
      {error && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)', color: 'var(--accent-red)', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {error}
        </div>
      )}
      {success && (
        <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)', color: '#10B981', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {success}
        </div>
      )}

      {/* Bulk action toolbar & Filters */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '1rem',
        flexWrap: 'wrap',
        backgroundColor: 'var(--bg-card)',
        padding: '1rem',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        flexShrink: 0
      }}>
        <div style={{ display: 'flex', gap: '0.75rem', flex: 1, minWidth: '320px', alignItems: 'center' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
            <input 
              type="text" 
              placeholder="Search by client name..." 
              value={search} 
              onChange={(e) => setSearch(e.target.value)}
              style={{ paddingLeft: '2.5rem', width: '100%' }}
            />
          </div>
          
          <select value={statusFilter} onChange={handleStatusFilterChange} style={{ width: '140px' }}>
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="at_risk">At Risk</option>
            <option value="pending">Pending</option>
          </select>

          <select value={planTypeFilter} onChange={(e) => setPlanTypeFilter(e.target.value)} style={{ width: '150px' }}>
            <option value="all">All Plan Types</option>
            <option value="fat_loss">Fat Loss</option>
            <option value="weight_gain">Weight Gain</option>
            <option value="custom">Custom</option>
            <option value="unassigned">Unassigned</option>
          </select>
        </div>

        {/* Layout list selectors */}
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          {selectedClients.length > 0 && (
            <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', borderRight: '1px solid var(--border-color)', paddingRight: '1rem', marginRight: '0.5rem' }}>
              <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-muted)' }}>{selectedClients.length} Selected:</span>
              <button onClick={() => handleBulkStatusChange('active')} className="btn btn-secondary" style={{ padding: '0.35rem 0.65rem', fontSize: '0.75rem' }}>Set Active</button>
              <button onClick={() => handleBulkStatusChange('at_risk')} className="btn btn-secondary" style={{ padding: '0.35rem 0.65rem', fontSize: '0.75rem' }}>Set At Risk</button>
              <button onClick={handleBulkDelete} className="btn btn-danger" style={{ padding: '0.35rem 0.65rem', fontSize: '0.75rem' }}>
                <Trash2 size={12} />
              </button>
            </div>
          )}

          <div style={{ display: 'flex', gap: '0.25rem', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '0.25rem' }}>
            <button onClick={() => setView('grid')} style={{ background: view === 'grid' ? 'var(--bg-dark)' : 'transparent', color: view === 'grid' ? 'var(--accent-lime-vivid)' : 'var(--text-main)', border: 'none', padding: '0.4rem', borderRadius: 'var(--radius-sm)', cursor: 'pointer', display: 'flex' }}><LayoutGrid size={16} /></button>
            <button onClick={() => setView('list')} style={{ background: view === 'list' ? 'var(--bg-dark)' : 'transparent', color: view === 'list' ? 'var(--accent-lime-vivid)' : 'var(--text-main)', border: 'none', padding: '0.4rem', borderRadius: 'var(--radius-sm)', cursor: 'pointer', display: 'flex' }}><List size={16} /></button>
          </div>
        </div>
      </div>

      {/* Main client grid layout */}
      <div style={{ display: 'flex', gap: '1.5rem', flex: 1, minHeight: 0 }}>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-dim)' }}>Loading clients list...</div>
          ) : clients.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-dim)' }}>
              <h3>No Clients Registered</h3>
              <p style={{ marginTop: '0.5rem', fontSize: '0.9rem' }}>Use the "Manual Add Client" button above to register your first client.</p>
            </div>
          ) : view === 'list' ? (
            /* List Layout view */
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.95rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                    <th style={{ padding: '1rem', width: '40px' }}>
                      <input 
                        type="checkbox" 
                        checked={selectedClients.length === clients.length} 
                        onChange={() => {
                          if (selectedClients.length === clients.length) setSelectedClients([]);
                          else setSelectedClients(clients.map(c => c.id));
                        }}
                      />
                    </th>
                    <th style={{ padding: '1rem' }}>Client</th>
                    <th style={{ padding: '1rem' }}>Status</th>
                    <th style={{ padding: '1rem' }}>Plan type</th>
                    <th style={{ padding: '1rem' }}>Compliance</th>
                    <th style={{ padding: '1rem' }}>Joined Date</th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map(client => (
                    <tr 
                      key={client.id} 
                      style={{ borderBottom: '1px solid var(--border-color)', cursor: 'pointer', backgroundColor: selectedClients.includes(client.id) ? 'rgba(37, 99, 235, 0.02)' : 'transparent' }}
                      onClick={() => handleClientClick(client.id)}
                    >
                      <td style={{ padding: '1rem' }} onClick={(e) => e.stopPropagation()}>
                        <input 
                          type="checkbox" 
                          checked={selectedClients.includes(client.id)} 
                          onChange={(e) => handleToggleSelectClient(e, client.id)}
                        />
                      </td>
                      <td style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        {client.photoUrl ? (
                          <div style={{ position: 'relative', width: '36px', height: '36px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, overflow: 'hidden' }}>
                            <img 
                              src={client.photoUrl} 
                              alt="" 
                              onError={(e) => { e.target.style.display = 'none'; }}
                              style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0 }} 
                            />
                            <span>{client.name.charAt(0)}</span>
                          </div>
                        ) : (
                          <div style={{ width: '36px', height: '36px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
                            {client.name.charAt(0)}
                          </div>
                        )}
                        <div>
                          <div style={{ fontWeight: 700 }}>{client.name}</div>
                          <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{client.email}</div>
                        </div>
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontWeight: 700, fontSize: '0.85rem', color: getStatusColor(client.status) }}>
                          <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: getStatusColor(client.status) }} />
                          {client.status.toUpperCase()}
                        </span>
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span className={`badge ${client.planType === 'custom' ? 'badge-blue' : client.planType === 'unassigned' ? 'badge-gray' : 'badge-lime'}`}>
                          {client.planType.replace('_', ' ')}
                        </span>
                      </td>
                      <td style={{ padding: '1rem', fontWeight: 800, color: client.adherence > 0.8 ? '#10B981' : client.adherence > 0.5 ? '#F59E0B' : '#EF4444' }}>
                        {Math.round(client.adherence * 100)}%
                      </td>
                      <td style={{ padding: '1rem', color: 'var(--text-muted)' }}>
                        {new Date(client.joinedAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            /* Grid Layout view */
            <div className="client-grid">
              {clients.map(client => {
                const isSelected = selectedClients.includes(client.id);
                return (
                  <div 
                    key={client.id} 
                    className="card drag-item" 
                    style={{ 
                      display: 'flex', 
                      flexDirection: 'column', 
                      gap: '1.25rem', 
                      position: 'relative',
                      border: isSelected ? '2px solid var(--accent-blue)' : '1px solid var(--border-color)',
                      backgroundColor: isSelected ? 'rgba(37, 99, 235, 0.01)' : 'var(--bg-card)'
                    }} 
                    onClick={() => handleClientClick(client.id)}
                  >
                    {/* Selection Checkbox */}
                    <div style={{ position: 'absolute', top: '1rem', right: '1rem' }} onClick={(e) => e.stopPropagation()}>
                      <input 
                        type="checkbox" 
                        checked={isSelected} 
                        onChange={(e) => handleToggleSelectClient(e, client.id)}
                      />
                    </div>

                    <div style={{ display: 'flex', gap: '0.75rem' }}>
                      {client.photoUrl ? (
                        <div style={{ position: 'relative', width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.25rem', fontWeight: 700, overflow: 'hidden' }}>
                          <img 
                            src={client.photoUrl} 
                            alt="" 
                            onError={(e) => { e.target.style.display = 'none'; }}
                            style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0 }} 
                          />
                          <span>{client.name.charAt(0)}</span>
                        </div>
                      ) : (
                        <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.25rem', fontWeight: 700 }}>
                          {client.name.charAt(0)}
                        </div>
                      )}
                      <div>
                        <h3 style={{ fontSize: '1.2rem', fontFamily: 'var(--font-heading)' }}>{client.name}</h3>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>{client.email}</span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: 700, fontSize: '0.75rem', color: getStatusColor(client.status) }}>
                        <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: getStatusColor(client.status) }} />
                        {client.status.toUpperCase()}
                      </span>
                      <span className={`badge ${client.planType === 'custom' ? 'badge-blue' : client.planType === 'unassigned' ? 'badge-gray' : 'badge-lime'}`} style={{ padding: '0.15rem 0.4rem', fontSize: '0.7rem' }}>
                        {client.planType.replace('_', ' ')}
                      </span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border-color)', paddingTop: '0.75rem', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      <span>Adherence: <strong style={{ color: client.adherence > 0.8 ? '#10B981' : client.adherence > 0.5 ? '#F59E0B' : '#EF4444' }}>{Math.round(client.adherence * 100)}%</strong></span>
                      <span>Joined {new Date(client.joinedAt).toLocaleDateString([], { month: 'short', year: 'numeric' })}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Drawer Panel: Client detail profile view */}
        {selectedClientDetail && (
          <aside style={{
            width: '380px',
            backgroundColor: 'var(--bg-card)',
            borderLeft: '1px solid var(--border-color)',
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            overflowY: 'auto',
            padding: '1.5rem',
            gap: '1.5rem',
            flexShrink: 0
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)' }}>Client Audit</h3>
              <button onClick={() => setSelectedClientDetail(null)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            {/* Profile Header */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem', textAlign: 'center' }}>
              {selectedClientDetail.photoUrl ? (
                <img src={selectedClientDetail.photoUrl} alt={selectedClientDetail.name} style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', border: '2px solid var(--border-color)' }} />
              ) : (
                <div style={{ width: '80px', height: '80px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', fontWeight: 700 }}>
                  {selectedClientDetail.name.charAt(0)}
                </div>
              )}

              {!editMode ? (
                <div>
                  <h4 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>{selectedClientDetail.name}</h4>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{selectedClientDetail.email}</p>
                </div>
              ) : (
                <form onSubmit={handleEditDetailsSubmit} style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <input type="text" value={editName} onChange={(e) => setEditName(e.target.value)} required style={{ fontSize: '0.9rem', padding: '0.5rem' }} />
                  <select value={editStatus} onChange={(e) => setEditStatus(e.target.value)} style={{ padding: '0.5rem' }}>
                    <option value="active">Active</option>
                    <option value="at_risk">At Risk</option>
                    <option value="pending">Pending</option>
                  </select>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button type="submit" className="btn btn-accent" style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem', flex: 1 }}>Save</button>
                    <button type="button" className="btn btn-secondary" onClick={() => setEditMode(false)} style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem', flex: 1 }}>Cancel</button>
                  </div>
                </form>
              )}
            </div>

            {/* Metrics */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div style={{ backgroundColor: 'var(--bg-page)', padding: '0.75rem', borderRadius: 'var(--radius-md)', textAlign: 'center' }}>
                <div style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Weight Log</div>
                <div style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', color: 'var(--text-main)' }}>{selectedClientDetail.stats.currentWeight} kg</div>
                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Start: {selectedClientDetail.stats.startingWeight} kg</span>
              </div>
              <div style={{ backgroundColor: 'var(--bg-page)', padding: '0.75rem', borderRadius: 'var(--radius-md)', textAlign: 'center' }}>
                <div style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Workouts Completed</div>
                <div style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', color: '#10B981' }}>{selectedClientDetail.stats.workoutsCompleted}</div>
                <span style={{ fontSize: '0.7rem', color: '#EF4444' }}>Missed: {selectedClientDetail.stats.workoutsMissed}</span>
              </div>
            </div>

            {/* Quick Navigation redirects */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <button className="btn btn-secondary" onClick={() => navigate(`/nutrition/assign/${selectedClientDetail.id}`)} style={{ justifyContent: 'space-between', padding: '0.75rem 1rem' }}>
                <span>Build Meal Plan</span>
                <ChevronRight size={16} />
              </button>
              <button className="btn btn-secondary" onClick={() => navigate(`/workouts/assign/${selectedClientDetail.id}`)} style={{ justifyContent: 'space-between', padding: '0.75rem 1rem' }}>
                <span>Build Workout Plan</span>
                <ChevronRight size={16} />
              </button>
            </div>

            {/* Danger Zone */}
            <div style={{ marginTop: 'auto', borderTop: '1px solid var(--border-color)', paddingTop: '1rem', display: 'flex', gap: '0.5rem' }}>
              {!editMode && (
                <button className="btn btn-secondary" onClick={() => setEditMode(true)} style={{ flex: 1, padding: '0.5rem' }}>
                  <Edit size={14} />
                  <span>Edit</span>
                </button>
              )}
              <button className="btn btn-danger" onClick={() => handleDeleteClient(selectedClientDetail.id)} style={{ flex: 1, padding: '0.5rem' }}>
                <Trash2 size={14} />
                <span>Remove Client</span>
              </button>
            </div>
          </aside>
        )}
      </div>

      {/* Removed Manual Add Client Modal as clients must join via invite link */}
    </div>
  );
};
export default Clients;
