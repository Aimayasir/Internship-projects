// Chat.jsx
import React, { useState, useEffect, useRef } from 'react';
import { apiClient } from '../api/apiClient';
import { MessageSquare, Users, Send, Image, Mic, Radio, Check, CheckCheck } from 'lucide-react';

export const Chat = () => {
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  
  // Tabs: 'direct' or 'broadcast'
  const [activeTab, setActiveTab] = useState('direct');
  
  // Broadcast Composer State
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcasts, setBroadcasts] = useState([]);
  const [allowReplies, setAllowReplies] = useState(false);

  // Broadcast Groups State
  const [broadcastGroups, setBroadcastGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupModalMode, setGroupModalMode] = useState('create'); // 'create' or 'edit'
  
  // Group Form Fields
  const [groupName, setGroupName] = useState('');
  const [groupSelectedClients, setGroupSelectedClients] = useState([]);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    fetchClients();
    fetchBroadcasts();
    fetchBroadcastGroups();
  }, []);

  const fetchBroadcastGroups = () => {
    const saved = localStorage.getItem('broadcastGroups');
    const defaultGroup = { id: 'all', name: 'All Clients', clientIds: [] };
    if (saved) {
      const groups = JSON.parse(saved);
      setBroadcastGroups([defaultGroup, ...groups]);
      // Keep selected group matched if it exists
      setSelectedGroup(prev => {
        if (!prev) return defaultGroup;
        if (prev.id === 'all') return defaultGroup;
        const matched = groups.find(g => g.id === prev.id);
        return matched || defaultGroup;
      });
    } else {
      setBroadcastGroups([defaultGroup]);
      setSelectedGroup(defaultGroup);
    }
  };

  useEffect(() => {
    if (clients.length > 0 && !selectedClient) {
      handleSelectClient(clients[0]);
    }
  }, [clients]);

  useEffect(() => {
    // Scroll chat to bottom on new messages
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchClients = async () => {
    const res = await apiClient.getClients({ limit: 50 });
    if (res.success) {
      setClients(res.data.clients);
    }
  };

  const fetchBroadcasts = async () => {
    const res = await apiClient.getBroadcasts();
    if (res.success) {
      setBroadcasts(res.data.data || res.data.broadcasts || res.data || []);
    }
  };

  const handleSelectClient = (client) => {
    setSelectedClient(client);
    
    // Load direct thread messages from localStorage or use defaults
    const key = `chat_messages_${client.id}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      setMessages(JSON.parse(saved));
    } else {
      const defaults = [
        { id: 'msg_1', senderRole: 'trainer', type: 'text', content: 'Great job today!', mediaUrl: null, duration: null, status: 'read', createdAt: new Date(Date.now() - 3600000).toISOString() },
        { id: 'msg_2', senderRole: 'client', type: 'voice', content: null, mediaUrl: 'https://cdn.fittrack.app/chat/voice_88.m4a', duration: 14, status: 'read', createdAt: new Date(Date.now() - 3500000).toISOString() }
      ];
      localStorage.setItem(key, JSON.stringify(defaults));
      setMessages(defaults);
    }
  };

  // Send Direct Message
  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputValue.trim() || !selectedClient) return;

    const key = `chat_messages_${selectedClient.id}`;
    const newMsg = {
      id: `msg_${Date.now()}`,
      senderRole: 'trainer',
      type: 'text',
      content: inputValue.trim(),
      mediaUrl: null,
      duration: null,
      status: 'sent',
      createdAt: new Date().toISOString()
    };

    const updatedMsgs = [...messages, newMsg];
    setMessages(updatedMsgs);
    localStorage.setItem(key, JSON.stringify(updatedMsgs));
    setInputValue('');

    // Simulate double blue check delivery check after 500ms
    setTimeout(() => {
      newMsg.status = 'read';
      const deliveredMsgs = updatedMsgs.map(m => m.id === newMsg.id ? { ...m, status: 'read' } : m);
      setMessages(deliveredMsgs);
      localStorage.setItem(key, JSON.stringify(deliveredMsgs));
    }, 1000);

    // Simulate Automated Client Reply after 2 seconds
    setTimeout(() => {
      const clientReply = {
        id: `msg_${Date.now() + 1}`,
        senderRole: 'client',
        type: 'text',
        content: `Got it, coach! Let me double check that on my app.`,
        mediaUrl: null,
        duration: null,
        status: 'read',
        createdAt: new Date().toISOString()
      };
      
      const replyList = [...updatedMsgs, clientReply];
      setMessages(replyList);
      localStorage.setItem(key, JSON.stringify(replyList));
    }, 2500);
  };

  // Send Broadcast to Selected Group
  const handleSendBroadcast = async (e) => {
    e.preventDefault();
    if (!broadcastMessage.trim() || !selectedGroup) return;

    const res = await apiClient.sendBroadcast({
      message: broadcastMessage.trim(),
      groupName: selectedGroup.name,
      allowReplies,
      recipientIds: selectedGroup.id === 'all' ? 'all' : selectedGroup.clientIds
    });

    if (res.success) {
      setBroadcasts([...broadcasts, res.data]);
      setBroadcastMessage('');
      alert(`Broadcast successfully dispatched to "${selectedGroup.name}"!`);
    }
  };

  const handleSaveGroup = (e) => {
    e.preventDefault();
    if (!groupName.trim()) return;

    const saved = localStorage.getItem('broadcastGroups');
    let list = saved ? JSON.parse(saved) : [];

    if (groupModalMode === 'create') {
      const newGroup = {
        id: `g_${Date.now()}`,
        name: groupName.trim(),
        clientIds: groupSelectedClients,
        createdAt: new Date().toISOString()
      };
      list.push(newGroup);
      localStorage.setItem('broadcastGroups', JSON.stringify(list));
      setSelectedGroup(newGroup);
    } else {
      list = list.map(g => g.id === selectedGroup.id ? { ...g, name: groupName.trim(), clientIds: groupSelectedClients } : g);
      localStorage.setItem('broadcastGroups', JSON.stringify(list));
      setSelectedGroup({ ...selectedGroup, name: groupName.trim(), clientIds: groupSelectedClients });
    }

    setShowGroupModal(false);
    fetchBroadcastGroups();
  };

  const openCreateGroupModal = () => {
    setGroupModalMode('create');
    setGroupName('');
    setGroupSelectedClients([]);
    setShowGroupModal(true);
  };

  const openEditGroupModal = () => {
    if (!selectedGroup || selectedGroup.id === 'all') return;
    setGroupModalMode('edit');
    setGroupName(selectedGroup.name);
    setGroupSelectedClients(selectedGroup.clientIds || []);
    setShowGroupModal(true);
  };

  const handleToggleGroupClient = (clientId) => {
    if (groupSelectedClients.includes(clientId)) {
      setGroupSelectedClients(groupSelectedClients.filter(id => id !== clientId));
    } else {
      setGroupSelectedClients([...groupSelectedClients, clientId]);
    }
  };

  return (
    <div className="main-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', height: 'calc(100vh - 70px)' }}>
      <div className="page-header" style={{ flexShrink: 0 }}>
        <div>
          <h2 className="page-title">Chat & Broadcasts</h2>
          <p className="page-subtitle">Send real-time messages to individual clients or broadcast notices.</p>
        </div>
      </div>

      <div className="card" style={{ padding: 0, display: 'flex', flex: 1, overflow: 'hidden', minHeight: 0 }}>
        {/* Left Side: Threads Panel */}
        <div style={{ width: '320px', borderRight: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
          <div style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)', display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
            <button 
              className={`btn ${activeTab === 'direct' ? 'btn-primary' : 'btn-secondary'}`} 
              onClick={() => setActiveTab('direct')}
              style={{ flex: 1, padding: '0.5rem', fontSize: '0.85rem' }}
            >
              1:1 Chats
            </button>
            <button 
              className={`btn ${activeTab === 'broadcast' ? 'btn-primary' : 'btn-secondary'}`} 
              onClick={() => setActiveTab('broadcast')}
              style={{ flex: 1, padding: '0.5rem', fontSize: '0.85rem' }}
            >
              Broadcasts
            </button>
          </div>
          
          <div style={{ flex: 1, overflowY: 'auto', padding: '0.5rem' }}>
            {activeTab === 'direct' ? (
              clients.map(c => {
                const isSelected = selectedClient?.id === c.id;
                return (
                  <div 
                    key={c.id} 
                    onClick={() => handleSelectClient(c)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem',
                      borderRadius: 'var(--radius-md)', background: isSelected ? 'var(--bg-page)' : 'transparent',
                      cursor: 'pointer', marginBottom: '0.25rem', border: isSelected ? '1px solid var(--border-color)' : '1px solid transparent'
                    }}
                  >
                    {c.photoUrl ? (
                      <div style={{ position: 'relative', width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, overflow: 'hidden' }}>
                        <img 
                          src={c.photoUrl} 
                          alt="" 
                          onError={(e) => { e.target.style.display = 'none'; }}
                          style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', top: 0, left: 0 }} 
                        />
                        <span>{c.name.charAt(0)}</span>
                      </div>
                    ) : (
                      <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
                        {c.name.charAt(0)}
                      </div>
                    )}
                    <div style={{ flex: 1, overflow: 'hidden' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                        <span style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-main)' }}>{c.name}</span>
                        <span style={{ fontSize: '0.65rem', color: 'var(--text-dim)' }}>
                          {c.lastActive ? new Date(c.lastActive).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'offline'}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', marginTop: '0.15rem' }}>
                        {c.planType.replace('_', ' ')} split active
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              /* Broadcast groups and log list */
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', color: 'var(--text-dim)' }}>Select Target Group</span>
                    <button 
                      className="btn btn-secondary" 
                      onClick={openCreateGroupModal}
                      style={{ padding: '0.25rem 0.5rem', fontSize: '0.75rem' }}
                    >
                      + Create Group
                    </button>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                    {broadcastGroups.map(g => {
                      const isSel = selectedGroup?.id === g.id;
                      return (
                        <div 
                          key={g.id}
                          onClick={() => setSelectedGroup(g)}
                          style={{
                            padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                            backgroundColor: isSel ? 'var(--bg-page)' : 'transparent',
                            border: isSel ? '1px solid var(--border-color)' : '1px solid transparent',
                            fontSize: '0.85rem', fontWeight: isSel ? 700 : 500, color: isSel ? 'var(--accent-blue)' : 'var(--text-main)'
                          }}
                        >
                          📢 {g.name} {g.id !== 'all' && `(${g.clientIds?.length || 0})`}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '0 0.5rem' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 900, textTransform: 'uppercase', color: 'var(--text-dim)' }}>Broadcast Log</span>
                  {broadcasts.map(bc => (
                    <div key={bc.id} style={{ border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '0.75rem', backgroundColor: 'var(--bg-page)', fontSize: '0.85rem' }}>
                      <div style={{ color: 'var(--text-dim)', fontSize: '0.7rem', display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontWeight: 800 }}>To: {bc.groupName || 'All Clients'}</span>
                        <span>{new Date(bc.sentAt).toLocaleDateString()}</span>
                      </div>
                      <p style={{ marginTop: '0.25rem', color: 'var(--text-main)', fontWeight: 600 }}>{bc.message}</p>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '0.5rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        <span>Read: {bc.readCount}</span>
                        <span>Delivered: {bc.deliveredCount}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Active Chat Area */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', backgroundColor: 'var(--bg-page)' }}>
          {activeTab === 'direct' ? (
            /* Direct Chat flow UI */
            <>
              {selectedClient && (
                <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
                  <div>
                    <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)' }}>{selectedClient.name}</h3>
                    <span style={{ fontSize: '0.75rem', color: selectedClient.status === 'active' ? '#10B981' : '#EF4444', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: selectedClient.status === 'active' ? '#10B981' : '#EF4444' }} />
                      {selectedClient.status === 'active' ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <span className="badge badge-lime">Replies Allowed</span>
                </div>
              )}

              {/* Message History bubble wrapper */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {messages.map(msg => {
                  const isTrainer = msg.senderRole === 'trainer';
                  return (
                    <div 
                      key={msg.id} 
                      style={{
                        alignSelf: isTrainer ? 'flex-end' : 'flex-start',
                        maxWidth: '70%',
                        padding: '0.75rem 1rem',
                        borderRadius: 'var(--radius-lg)',
                        backgroundColor: isTrainer ? 'var(--bg-dark)' : 'var(--bg-card)',
                        color: isTrainer ? 'var(--text-light)' : 'var(--text-main)',
                        border: isTrainer ? 'none' : '1px solid var(--border-color)',
                        fontSize: '0.95rem',
                        boxShadow: 'var(--shadow-sm)'
                      }}
                    >
                      {msg.type === 'text' ? (
                        <span>{msg.content}</span>
                      ) : (
                        <div style={{ fontStyle: 'italic', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <span>🎙 Voice note ({msg.duration}s)</span>
                          <button style={{ border: 'none', background: 'none', color: 'var(--accent-blue)', cursor: 'pointer', fontWeight: 700 }}>Play</button>
                        </div>
                      )}
                      
                      <div style={{
                        fontSize: '0.65rem',
                        color: isTrainer ? 'var(--text-dim)' : 'var(--text-muted)',
                        textAlign: 'right',
                        marginTop: '0.35rem',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        gap: '0.25rem'
                      }}>
                        <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {isTrainer && (
                          msg.status === 'read' ? <CheckCheck size={12} style={{ color: 'var(--accent-lime-vivid)' }} /> : <Check size={12} />
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Text Input Footer Box */}
              <form onSubmit={handleSendMessage} style={{ padding: '1rem 1.5rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', display: 'flex', gap: '0.75rem', alignItems: 'center', flexShrink: 0 }}>
                <button type="button" className="btn btn-secondary" style={{ padding: '0.5rem', borderRadius: 'var(--radius-md)' }} onClick={() => alert('Simulating image attachments selection')}><Image size={18} /></button>
                <button type="button" className="btn btn-secondary" style={{ padding: '0.5rem', borderRadius: 'var(--radius-md)' }} onClick={() => alert('Simulating mic recording voice note')}><Mic size={18} /></button>
                <input 
                  type="text" 
                  placeholder="Type a message to client..." 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  style={{ flex: 1 }} 
                />
                <button type="submit" className="btn btn-primary" style={{ padding: '0.5rem 1.25rem', height: '42px' }} disabled={!inputValue.trim()}>
                  <Send size={16} />
                </button>
              </form>
            </>
          ) : (
            /* Broadcast Composer UI */
            <div style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem', height: '100%', overflowY: 'auto' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.5rem', fontFamily: 'var(--font-heading)' }}>Send Broadcast to: {selectedGroup?.name}</h3>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', marginTop: '0.25rem' }}>
                    {selectedGroup?.id === 'all' 
                      ? `Targeting all ${clients.length} clients.` 
                      : `Targeting subset of ${(selectedGroup?.clientIds || []).length} clients.`}
                  </p>
                </div>
                {selectedGroup && selectedGroup.id !== 'all' && (
                  <button className="btn btn-secondary" onClick={openEditGroupModal}>
                    Manage Members
                  </button>
                )}
              </div>

              <form onSubmit={handleSendBroadcast} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', maxWidth: '600px' }}>
                <div>
                  <label>Broadcast Message</label>
                  <textarea 
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    rows={6}
                    placeholder={`Type broadcast message to ${selectedGroup?.name}...`}
                    required
                    style={{ marginTop: '0.5rem', width: '100%', resize: 'none' }}
                  />
                </div>

                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', textTransform: 'none', fontSize: '0.9rem', fontWeight: 600 }}>
                    <input 
                      type="checkbox" 
                      checked={allowReplies}
                      onChange={(e) => setAllowReplies(e.target.checked)}
                      style={{ width: 'auto' }}
                    />
                    <span>Allow clients to reply directly to this broadcast (WhatsApp style)</span>
                  </label>
                </div>

                <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-start', display: 'flex', gap: '0.5rem' }}>
                  <Send size={16} />
                  <span>Send Broadcast</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* --- CREATE / EDIT BROADCAST GROUP MODAL --- */}
      {showGroupModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '440px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>
                {groupModalMode === 'create' ? 'Create Broadcast Group' : 'Manage Group Members'}
              </h3>
              <button onClick={() => setShowGroupModal(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveGroup} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div>
                <label>Group Name</label>
                <input 
                  type="text" 
                  value={groupName} 
                  onChange={(e) => setGroupName(e.target.value)} 
                  required 
                  placeholder="e.g. Morning Split" 
                  style={{ marginTop: '0.25rem' }} 
                />
              </div>

              <div>
                <label>Select Members</label>
                <div style={{
                  maxHeight: '160px', overflowY: 'auto', border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)', padding: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.25rem', marginTop: '0.25rem'
                }}>
                  {clients.map(c => {
                    const isChecked = groupSelectedClients.includes(c.id);
                    return (
                      <label 
                        key={c.id} 
                        style={{ 
                          display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.35rem 0.5rem',
                          borderRadius: 'var(--radius-sm)', cursor: 'pointer', textTransform: 'none', fontWeight: 500, fontSize: '0.85rem'
                        }}
                      >
                        <input 
                          type="checkbox" 
                          checked={isChecked} 
                          onChange={() => handleToggleGroupClient(c.id)} 
                          style={{ width: 'auto' }}
                        />
                        <span>{c.name} ({c.email})</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                {groupModalMode === 'create' ? 'Create Group' : 'Save Members'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default Chat;
