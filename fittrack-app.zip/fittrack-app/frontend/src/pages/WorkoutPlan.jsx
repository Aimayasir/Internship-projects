// WorkoutPlan.jsx
import React, { useState, useEffect } from 'react';
import { apiClient } from '../api/apiClient';
import { Search, Filter, LayoutGrid, List } from 'lucide-react';
import { ClientList } from '../components/ClientList';

export const WorkoutPlan = () => {
  const [clients, setClients] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [view, setView] = useState('grid');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchClients();
  }, [search, filter]);

  const fetchClients = async () => {
    setLoading(true);
    const res = await apiClient.getClients({ search, planType: filter });
    if (res.success) {
      setClients(res.data.clients);
    }
    setLoading(false);
  };

  return (
    <div className="main-content">
      <div className="page-header">
        <div>
          <h2 className="page-title">Workout Plans</h2>
          <p className="page-subtitle">Select a client below to build or modify their custom workout program.</p>
        </div>
      </div>

      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '1rem',
        flexWrap: 'wrap',
        backgroundColor: 'var(--bg-card)',
        padding: '1rem',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)'
      }}>
        <div style={{ display: 'flex', gap: '0.75rem', flex: 1, minWidth: '280px' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
            <input 
              type="text" 
              placeholder="Search clients by name..." 
              value={search} 
              onChange={(e) => setSearch(e.target.value)}
              style={{ paddingLeft: '2.5rem', width: '100%' }}
            />
          </div>
          
          <select 
            value={filter} 
            onChange={(e) => setFilter(e.target.value)}
            style={{ width: '180px' }}
          >
            <option value="all">All Plans</option>
            <option value="fat_loss">Fat Loss</option>
            <option value="weight_gain">Weight Gain</option>
            <option value="custom">Custom</option>
            <option value="unassigned">Unassigned</option>
          </select>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '0.25rem' }}>
          <button 
            onClick={() => setView('grid')}
            style={{
              background: view === 'grid' ? 'var(--bg-dark)' : 'transparent',
              color: view === 'grid' ? 'var(--accent-lime-vivid)' : 'var(--text-main)',
              border: 'none', padding: '0.5rem', borderRadius: 'var(--radius-sm)', cursor: 'pointer', display: 'flex'
            }}
          >
            <LayoutGrid size={16} />
          </button>
          <button 
            onClick={() => setView('list')}
            style={{
              background: view === 'list' ? 'var(--bg-dark)' : 'transparent',
              color: view === 'list' ? 'var(--accent-lime-vivid)' : 'var(--text-main)',
              border: 'none', padding: '0.5rem', borderRadius: 'var(--radius-sm)', cursor: 'pointer', display: 'flex'
            }}
          >
            <List size={16} />
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-dim)' }}>Loading clients...</div>
      ) : (
        <ClientList clients={clients} view={view} pathType="workouts" />
      )}
    </div>
  );
};
export default WorkoutPlan;
