// Profile.jsx
import React, { useState, useEffect } from 'react';
import { apiClient } from '../api/apiClient';
import { User, Phone, MapPin, Save, Lock, Bell, Check, AlertCircle, FileImage, Trash2 } from 'lucide-react';

export const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Form Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [bio, setBio] = useState('');
  const [addressLine, setAddressLine] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [country, setCountry] = useState('');
  const [zip, setZip] = useState('');

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');
  const [pwdError, setPwdError] = useState('');

  // Notification Preference settings
  const [notifSettings, setNotifSettings] = useState(null);

  useEffect(() => {
    fetchProfile();
    fetchNotificationSettings();
  }, []);

  const fetchProfile = async () => {
    setLoading(true);
    const res = await apiClient.getProfile();
    if (res.success) {
      const data = res.data;
      setProfile(data);
      setName(data.name);
      setPhone(data.phone);
      setBio(data.bio);
      setAddressLine(data.address.line1);
      setCity(data.address.city);
      setState(data.address.state);
      setCountry(data.address.country);
      setZip(data.address.zip);
    }
    setLoading(false);
  };

  const fetchNotificationSettings = async () => {
    const res = await apiClient.getNotificationSettings();
    if (res.success) {
      setNotifSettings(res.data);
    }
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg('');
    setErrorMsg('');

    // PATCH /trainer/profile
    const payload = {
      name,
      phone,
      bio,
      address: { line1: addressLine, city, state, country, zip }
    };

    const res = await apiClient.updateProfile(payload);

    if (res.success) {
      setProfile(res.data);
      setSuccessMsg('Profile settings saved successfully.');
      setTimeout(() => setSuccessMsg(''), 3000);
    } else {
      setErrorMsg(res.error.message);
    }
    setSaving(false);
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setPwdSuccess('');
    setPwdError('');

    if (newPassword !== confirmPassword) {
      setPwdError('New passwords do not match.');
      return;
    }

    setSaving(true);
    // POST /trainer/profile/change-password
    const res = await apiClient.changePassword({ currentPassword, newPassword });

    if (res.success) {
      setPwdSuccess('Password changed successfully.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPwdSuccess(''), 3000);
    } else {
      setPwdError(res.error.message);
    }
    setSaving(false);
  };

  const handlePhotoUpload = async () => {
    // For file selection we can create dynamic input and post as FormData
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append('photo', file);
      
      const res = await apiClient.uploadProfilePhoto(formData);
      if (res.success) {
        setProfile({ ...profile, photoUrl: res.data.photoUrl });
        setSuccessMsg('Photo uploaded successfully.');
        setTimeout(() => setSuccessMsg(''), 3000);
      }
    };
    input.click();
  };

  const handlePhotoDelete = async () => {
    // DELETE /trainer/profile/photo
    const res = await apiClient.deleteProfilePhoto();

    if (res.success) {
      setProfile({ ...profile, photoUrl: res.data.photoUrl || 'https://cdn.fittrack.app/defaults/trainer-avatar.png' });
      setSuccessMsg('Photo removed successfully.');
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  const handleToggleNotif = async (key) => {
    if (!notifSettings) return;
    const updated = { ...notifSettings, [key]: !notifSettings[key] };
    
    // PATCH /trainer/notification-settings
    const res = await apiClient.updateNotificationSettings(updated);

    if (res.success) {
      setNotifSettings(res.data);
    }
  };

  return (
    <div className="main-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div className="page-header">
        <div>
          <h2 className="page-title">Profile Settings</h2>
          <p className="page-subtitle">Manage trainer profile identity, billing credentials, and notifications.</p>
        </div>
      </div>

      {successMsg && (
        <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)', color: '#10B981', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', fontWeight: 600 }}>
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)', color: 'var(--accent-red)', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)' }}>
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-dim)' }}>Loading profile...</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 2fr', gap: '2rem', alignItems: 'flex-start' }}>
          
          {/* Left Panel: Photo, Tags, Bio & Alerts config */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Photo & Tags */}
            <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1.25rem', textAlign: 'center' }}>
              <div style={{ position: 'relative' }}>
                <img 
                  src={profile?.photoUrl} 
                  alt={profile?.name} 
                  style={{ width: '120px', height: '120px', borderRadius: 'var(--radius-lg)', objectFit: 'cover', border: '1px solid var(--border-color)' }} 
                />
                <div style={{ display: 'flex', gap: '0.25rem', position: 'absolute', bottom: '-0.5rem', right: '-0.5rem' }}>
                  <button onClick={handlePhotoUpload} className="btn btn-secondary" style={{ padding: '0.35rem', borderRadius: 'var(--radius-sm)' }}>
                    <FileImage size={14} />
                  </button>
                  <button onClick={handlePhotoDelete} className="btn btn-secondary" style={{ padding: '0.35rem', borderRadius: 'var(--radius-sm)', color: 'var(--accent-red)' }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              <div>
                <h3 style={{ fontSize: '1.5rem', fontFamily: 'var(--font-heading)' }}>{profile?.name}</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{profile?.email}</span>
              </div>

              <div style={{ display: 'flex', gap: '0.25rem', justifyContent: 'center', flexWrap: 'wrap' }}>
                {profile?.specialtyTags.map(tag => (
                  <span key={tag} className="badge badge-lime">{tag}</span>
                ))}
              </div>
            </div>

            {/* Notification settings panel */}
            {notifSettings && (
              <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Bell size={18} style={{ color: 'var(--accent-blue)' }} />
                  <span>Notification Preferences</span>
                </h3>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', textTransform: 'none', fontWeight: 500, fontSize: '0.9rem' }}>
                    <input type="checkbox" checked={notifSettings.newClientJoined} onChange={() => handleToggleNotif('newClientJoined')} style={{ width: 'auto' }} />
                    <span>New client joined alerts</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', textTransform: 'none', fontWeight: 500, fontSize: '0.9rem' }}>
                    <input type="checkbox" checked={notifSettings.newMessage} onChange={() => handleToggleNotif('newMessage')} style={{ width: 'auto' }} />
                    <span>New message in-app logs</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', textTransform: 'none', fontWeight: 500, fontSize: '0.9rem' }}>
                    <input type="checkbox" checked={notifSettings.missedWorkoutAlert} onChange={() => handleToggleNotif('missedWorkoutAlert')} style={{ width: 'auto' }} />
                    <span>Missed workout triggers</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', textTransform: 'none', fontWeight: 500, fontSize: '0.9rem' }}>
                    <input type="checkbox" checked={notifSettings.missedMealAlert} onChange={() => handleToggleNotif('missedMealAlert')} style={{ width: 'auto' }} />
                    <span>Missed meal plan logs</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* Right Panel: Fields form & change password */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="card">
              <form onSubmit={handleProfileSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <User size={18} style={{ color: 'var(--accent-blue)' }} />
                  <span>General Profile Data</span>
                </h3>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label>Full Name</label>
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                  <div>
                    <label>Trainer Phone</label>
                    <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                </div>

                <div>
                  <label>Professional Bio</label>
                  <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} style={{ width: '100%', resize: 'none', marginTop: '0.25rem' }} />
                </div>

                <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.5rem' }}>
                  <MapPin size={18} style={{ color: 'var(--accent-blue)' }} />
                  <span>Office Address</span>
                </h3>

                <div>
                  <label>Street Line 1</label>
                  <input type="text" value={addressLine} onChange={(e) => setAddressLine(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label>City</label>
                    <input type="text" value={city} onChange={(e) => setCity(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                  <div>
                    <label>State / Province</label>
                    <input type="text" value={state} onChange={(e) => setState(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label>Country</label>
                    <input type="text" value={country} onChange={(e) => setCountry(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                  <div>
                    <label>Postal ZIP Code</label>
                    <input type="text" value={zip} onChange={(e) => setZip(e.target.value)} required style={{ marginTop: '0.25rem' }} />
                  </div>
                </div>

                <button type="submit" className="btn btn-primary" disabled={saving} style={{ alignSelf: 'flex-start', marginTop: '0.5rem' }}>
                  <Save size={16} />
                  <span>{saving ? 'Saving...' : 'Save General profile'}</span>
                </button>
              </form>
            </div>

            {/* Change Password Card */}
            <div className="card">
              <form onSubmit={handlePasswordSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Lock size={18} style={{ color: 'var(--accent-blue)' }} />
                  <span>Update Account Password</span>
                </h3>

                {pwdSuccess && (
                  <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', color: '#10B981', border: '1px solid rgba(16, 185, 129, 0.2)', padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', fontSize: '0.85rem', fontWeight: 600 }}>
                    {pwdSuccess}
                  </div>
                )}

                {pwdError && (
                  <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.08)', color: 'var(--accent-red)', border: '1px solid rgba(239, 68, 68, 0.2)', padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', fontSize: '0.85rem', display: 'flex', gap: '0.25rem' }}>
                    <AlertCircle size={16} />
                    <span>{pwdError}</span>
                  </div>
                )}

                <div>
                  <label htmlFor="curr-pass">Current Password</label>
                  <input id="curr-pass" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required placeholder="••••••••" style={{ marginTop: '0.25rem' }} />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label htmlFor="new-pass">New Password</label>
                    <input id="new-pass" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required placeholder="••••••••" style={{ marginTop: '0.25rem' }} />
                  </div>
                  <div>
                    <label htmlFor="conf-pass">Confirm New Password</label>
                    <input id="conf-pass" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required placeholder="••••••••" style={{ marginTop: '0.25rem' }} />
                  </div>
                </div>

                <button type="submit" className="btn btn-primary" disabled={saving} style={{ alignSelf: 'flex-start', marginTop: '0.5rem' }}>
                  <Lock size={16} />
                  <span>Update Password</span>
                </button>
              </form>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
export default Profile;
