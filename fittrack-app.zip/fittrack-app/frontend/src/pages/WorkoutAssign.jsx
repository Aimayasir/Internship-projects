// WorkoutAssign.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { apiClient } from '../api/apiClient';
import { 
  Plus, 
  Trash2, 
  Save, 
  Dumbbell, 
  Search, 
  Sparkles, 
  AlertTriangle,
  RefreshCw,
  ArrowLeft,
  X,
  FileImage,
  ExternalLink,
  ChevronRight,
  GripVertical
} from 'lucide-react';

export const WorkoutAssign = () => {
  const { clientId } = useParams();
  const navigate = useNavigate();

  const [client, setClient] = useState(null);
  const [plan, setPlan] = useState(null);
  const [library, setLibrary] = useState([]);
  const [search, setSearch] = useState('');
  const [muscleGroupFilter, setMuscleGroupFilter] = useState('');
  const [activeDay, setActiveDay] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Dialogs
  const [showPopup, setShowPopup] = useState(false);
  const [popupMode, setPopupMode] = useState('add'); // 'add' or 'edit'
  const [editingItem, setEditingItem] = useState(null);
  const [showConflictDialog, setShowConflictDialog] = useState(false);
  const [conflictData, setConflictData] = useState(null);
  const [showApplyDefaultDropdown, setShowApplyDefaultDropdown] = useState(false);

  // Global Exercise Library Add Modal State
  const [showLibraryAddModal, setShowLibraryAddModal] = useState(false);
  const [libName, setLibName] = useState('');
  const [libMuscleGroup, setLibMuscleGroup] = useState('legs');
  const [libEquipment, setLibEquipment] = useState('none');
  const [libVideoUrl, setLibVideoUrl] = useState('');

  // Popup Form Fields
  const [formName, setFormName] = useState('');
  const [formMuscleGroup, setFormMuscleGroup] = useState('legs');
  const [formEquipment, setFormEquipment] = useState('none');
  const [formSets, setFormSets] = useState('');
  const [formReps, setFormReps] = useState('');
  const [formWeight, setFormWeight] = useState('');
  const [formRestSeconds, setFormRestSeconds] = useState('60');
  const [formLink, setFormLink] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formTargetDay, setFormTargetDay] = useState(1);

  // Drag and Drop State
  const [draggedSidebarItem, setDraggedSidebarItem] = useState(null);
  const [draggedCanvasItem, setDraggedCanvasItem] = useState(null);
  const [draggedSourceDay, setDraggedSourceDay] = useState(null);
  const [activeDragDay, setActiveDragDay] = useState(null);

  useEffect(() => {
    fetchClientAndPlan();
    fetchLibrary();
  }, [clientId, search, muscleGroupFilter]);

  const fetchClientAndPlan = async () => {
    setLoading(true);
    const clientRes = await apiClient.getClientById(clientId);
    if (clientRes.success) {
      setClient(clientRes.data);
    } else {
      setError(clientRes.error.message);
    }

    const planRes = await apiClient.getWorkoutClientPlan(clientId);
    if (planRes.success) {
      setPlan(planRes.data);
    } else {
      const custRes = await apiClient.customizeWorkout(clientId);
      if (custRes.success) {
        setPlan(custRes.data);
      }
    }
    setLoading(false);
  };

  const fetchLibrary = async () => {
    const res = await apiClient.getExercises({ search, muscleGroup: muscleGroupFilter });
    if (res.success) {
      setLibrary(res.data.exercises);
    }
  };

  const handleAddExerciseToDay = async (exerciseId, dayNum) => {
    const res = await apiClient.addWorkoutExercise(clientId, {
      day: dayNum,
      exerciseId,
      sets: 3,
      reps: 10,
      weight: 15,
      restSeconds: 60
    });
    if (res.success) {
      const planRes = await apiClient.getWorkoutClientPlan(clientId);
      if (planRes.success) {
        setPlan(planRes.data);
      }
    }
  };

  const handleApplyDefault = async (type) => {
    setLoading(true);
    setShowApplyDefaultDropdown(false);
    const res = await apiClient.applyDefaultWorkout(clientId, type);
    if (res.success) {
      setPlan(res.data);
      setSuccess(`Applied default ${type} program!`);
      setTimeout(() => setSuccess(''), 3000);
    } else {
      setError(res.error.message);
    }
    setLoading(false);
  };

  const handleInlineEdit = (dayNum, itemId, field, value) => {
    if (!plan) return;
    const updated = { ...plan };
    const dayObj = updated.days.find(d => d.day === dayNum);
    if (!dayObj) return;

    const item = dayObj.exercises.find(i => i.id === itemId);
    if (item) {
      item[field] = field === 'name' ? value : Number(value) || 0;
    }
    setPlan(updated);
  };

  const handleRemoveItem = (dayNum, itemId) => {
    if (!plan) return;
    const updated = { ...plan };
    const dayObj = updated.days.find(d => d.day === dayNum);
    if (!dayObj) return;

    dayObj.exercises = dayObj.exercises.filter(i => i.id !== itemId);
    setPlan(updated);
  };

  const handleSavePlan = async () => {
    if (!plan) return;
    setSaving(true);
    setError('');
    setSuccess('');

    const res = await apiClient.updateWorkoutPlan(clientId, plan);
    if (res.success) {
      setPlan(res.data);
      setSuccess('Workout program saved successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } else if (res.status === 409) {
      setConflictData(res.error.currentPlan);
      setShowConflictDialog(true);
    } else {
      setError(res.error.message || 'Failed to save program');
    }
    setSaving(false);
  };

  const handleResolveConflict = () => {
    if (conflictData) {
      setPlan(conflictData);
      setShowConflictDialog(false);
      setError('Pulled latest program version from server. Please reapply changes and save.');
      setTimeout(() => setError(''), 5000);
    }
  };

  const handlePopupSubmit = async (e) => {
    e.preventDefault();
    if (!plan) return;

    const customExercise = {
      name: formName,
      muscleGroup: formMuscleGroup,
      equipment: formEquipment,
      videoUrl: formLink,
      imageUrl: formImage
    };

    if (popupMode === 'add') {
      const res = await apiClient.addWorkoutExercise(clientId, {
        day: activeDay,
        sets: Number(formSets) || 3,
        reps: Number(formReps) || 10,
        weight: Number(formWeight) || 0,
        restSeconds: Number(formRestSeconds) || 60,
        customItem: customExercise
      });

      if (res.success) {
        const planRes = await apiClient.getWorkoutClientPlan(clientId);
        if (planRes.success) {
          setPlan(planRes.data);
        }
      }
    } else {
      const updated = { ...plan };
      const dayObj = updated.days.find(d => d.day === activeDay);
      if (dayObj) {
        const idx = dayObj.exercises.findIndex(i => i.id === editingItem.id);
        if (idx !== -1) {
          dayObj.exercises[idx] = {
            ...dayObj.exercises[idx],
            name: formName,
            sets: Number(formSets),
            reps: Number(formReps),
            weight: Number(formWeight),
            restSeconds: Number(formRestSeconds),
            videoUrl: formLink
          };
        }
      }
      setPlan(updated);
    }

    setShowPopup(false);
    resetForm();
  };

  const handleLibraryAddSubmit = async (e) => {
    e.preventDefault();
    const newEx = {
      id: `ex_${Date.now()}`,
      name: libName,
      muscleGroup: libMuscleGroup,
      equipment: libEquipment,
      videoUrl: libVideoUrl || ''
    };

    const saved = localStorage.getItem('exercises');
    const list = saved ? JSON.parse(saved) : [];
    list.push(newEx);
    localStorage.setItem('exercises', JSON.stringify(list));

    setLibName('');
    setLibMuscleGroup('legs');
    setLibEquipment('none');
    setLibVideoUrl('');

    setShowLibraryAddModal(false);
    fetchLibrary();
  };

  const openAddPopup = () => {
    setPopupMode('add');
    resetForm();
    setShowPopup(true);
  };

  const openEditPopup = (item) => {
    setPopupMode('edit');
    setEditingItem(item);
    setFormName(item.name);
    setFormSets(item.sets);
    setFormReps(item.reps);
    setFormWeight(item.weight);
    setFormRestSeconds(item.restSeconds);
    setFormLink(item.videoUrl || '');
    setShowPopup(true);
  };

  const resetForm = () => {
    setFormName('');
    setFormMuscleGroup('legs');
    setFormEquipment('none');
    setFormSets('');
    setFormReps('');
    setFormWeight('');
    setFormRestSeconds('60');
    setFormLink('');
    setFormImage('');
  };

  const handleSimulateUpload = () => {
    setFormImage('https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=150');
  };

  // --- HTML5 DRAG & DROP ---
  const handleDragStartSidebar = (ex) => {
    setDraggedSidebarItem(ex);
    setDraggedCanvasItem(null);
  };

  const handleDragStartCanvas = (dayNum, item) => {
    setDraggedCanvasItem(item);
    setDraggedSourceDay(dayNum);
    setDraggedSidebarItem(null);
  };

  const handleDragOver = (e, dayNum) => {
    e.preventDefault();
    setActiveDragDay(dayNum);
  };

  const handleDragLeave = () => {
    setActiveDragDay(null);
  };

  const handleDrop = async (e, destDay) => {
    e.preventDefault();
    setActiveDragDay(null);

    if (draggedSidebarItem) {
      await handleAddExerciseToDay(draggedSidebarItem.id, destDay);
      setDraggedSidebarItem(null);
    } else if (draggedCanvasItem && draggedSourceDay) {
      if (!plan) return;
      const updated = { ...plan };
      
      // Remove from source day
      const srcDayObj = updated.days.find(d => d.day === draggedSourceDay);
      if (srcDayObj) {
        srcDayObj.exercises = srcDayObj.exercises.filter(i => i.id !== draggedCanvasItem.id);
      }

      // Add to dest day
      let destDayObj = updated.days.find(d => d.day === destDay);
      if (!destDayObj) {
        destDayObj = { day: destDay, exercises: [] };
        updated.days.push(destDayObj);
      }

      const newItem = { ...draggedCanvasItem, orderIndex: destDayObj.exercises.length };
      destDayObj.exercises.push(newItem);

      setPlan(updated);
      setDraggedCanvasItem(null);
      setDraggedSourceDay(null);
    }
  };

  return (
    <div className="main-content" style={{ padding: '2rem 1.5rem', display: 'flex', flexDirection: 'column', height: 'calc(100vh - 70px)' }}>
      {/* Top Banner Row */}
      <div className="page-header" style={{ flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <button className="btn btn-secondary" onClick={() => navigate('/workouts')} style={{ padding: '0.5rem' }}>
            <ArrowLeft size={16} />
          </button>
          <div>
            <h2 className="page-title">{client ? `${client.name}'s Workout Plan` : 'Workout Plan Canvas'}</h2>
            <p className="page-subtitle">Design multi-day splits, configure sets/reps, and assign programs.</p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', position: 'relative' }}>
          <div style={{ position: 'relative' }}>
            <button className="btn btn-secondary" onClick={() => setShowApplyDefaultDropdown(!showApplyDefaultDropdown)}>
              <Sparkles size={16} />
              <span>Apply Program</span>
            </button>
            {showApplyDefaultDropdown && (
              <div style={{
                position: 'absolute', top: '100%', right: 0, marginTop: '0.5rem',
                backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-lg)', zIndex: 100, width: '180px',
                display: 'flex', flexDirection: 'column', overflow: 'hidden'
              }}>
                <button 
                  onClick={() => handleApplyDefault('fat_loss')}
                  style={{ border: 'none', background: 'none', padding: '0.75rem 1rem', textAlign: 'left', cursor: 'pointer', fontFamily: 'var(--font-heading)', textTransform: 'uppercase', fontWeight: 700 }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = 'var(--bg-page)'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
                >
                  Fat Loss / Cardio
                </button>
                <button 
                  onClick={() => handleApplyDefault('strength')}
                  style={{ border: 'none', background: 'none', padding: '0.75rem 1rem', textAlign: 'left', cursor: 'pointer', fontFamily: 'var(--font-heading)', textTransform: 'uppercase', fontWeight: 700 }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = 'var(--bg-page)'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
                >
                  Strength Program
                </button>
              </div>
            )}
          </div>

          <button className="btn btn-secondary" onClick={openAddPopup}>
            <Plus size={16} />
            <span>Add Custom</span>
          </button>

          <button className="btn btn-primary" onClick={handleSavePlan} disabled={saving}>
            <Save size={16} />
            <span>{saving ? 'Saving...' : 'Save Program'}</span>
          </button>
        </div>
      </div>

      {/* Messages */}
      {error && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)', color: 'var(--accent-red)', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {error}
        </div>
      )}
      {success && (
        <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)', color: '#10B981', padding: '0.75rem 1.25rem', borderRadius: 'var(--radius-md)', flexShrink: 0 }}>
          {success}
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0, paddingBottom: '0.5rem', borderBottom: '1px solid var(--border-color)', marginBottom: '1rem' }}>
        <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)', fontWeight: 600 }}>
          💡 TIP: Drag and drop exercises from the library into any day column, or drag exercises across day columns to reorder.
        </span>
      </div>

      {/* Main Canvas splits */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-dim)', flex: 1 }}>Loading Workout splits...</div>
      ) : (
        <div style={{ display: 'flex', gap: '1.5rem', flex: 1, minHeight: 0 }}>
          {/* Left Panel: Exercise library */}
          <div style={{ width: '320px', display: 'flex', flexDirection: 'column', gap: '1rem', flexShrink: 0, height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)' }}>Exercise Library</h3>
              <button 
                className="btn btn-secondary" 
                onClick={() => setShowLibraryAddModal(true)}
                style={{ padding: '0.25rem 0.5rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
              >
                <Plus size={12} />
                <span>New Ex</span>
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <div style={{ position: 'relative' }}>
                <Search size={16} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
                <input 
                  type="text" 
                  placeholder="Search exercises..." 
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  style={{ paddingLeft: '2.25rem', fontSize: '0.85rem' }}
                />
              </div>

              <select 
                value={muscleGroupFilter} 
                onChange={(e) => setMuscleGroupFilter(e.target.value)}
                style={{ fontSize: '0.85rem', padding: '0.5rem' }}
              >
                <option value="">All Muscle Groups</option>
                <option value="legs">Legs</option>
                <option value="chest">Chest</option>
                <option value="back">Back</option>
                <option value="shoulders">Shoulders</option>
                <option value="arms">Arms</option>
                <option value="core">Core</option>
              </select>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.75rem', paddingRight: '0.25rem' }}>
              {library.map(ex => (
                <div
                  key={ex.id}
                  draggable
                  onDragStart={() => handleDragStartSidebar(ex)}
                  style={{
                    backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)',
                    padding: '0.75rem', borderRadius: 'var(--radius-md)', display: 'flex', gap: '0.75rem',
                    cursor: 'grab', transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--text-dim)'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border-color)'}
                >
                  <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
                    <Dumbbell size={20} />
                  </div>
                  <div>
                    <div style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-main)' }}>{ex.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.15rem', textTransform: 'uppercase', fontWeight: 600 }}>
                      {ex.muscleGroup} • {ex.equipment}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel: Day columns canvas */}
          <div style={{ flex: 1, display: 'flex', gap: '1.25rem', overflowX: 'auto', paddingBottom: '1rem', height: '100%', minWidth: 0 }}>
            {[1, 2, 3, 4, 5, 6, 7].map(dayNum => {
              const dayObj = plan?.days.find(d => d.day === dayNum);
              const dayExercises = dayObj?.exercises || [];
              const isOver = activeDragDay === dayNum;

              return (
                <div
                  key={dayNum}
                  onDragOver={(e) => handleDragOver(e, dayNum)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, dayNum)}
                  style={{
                    width: '320px', flexShrink: 0, display: 'flex', flexDirection: 'column',
                    backgroundColor: 'var(--bg-card)', border: isOver ? '2px dashed var(--accent-blue)' : '1px solid var(--border-color)',
                    borderRadius: 'var(--radius-lg)', padding: '1.25rem',
                    gap: '1rem', overflowY: 'auto', minHeight: 0, position: 'relative', transition: 'all 0.15s'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem', flexShrink: 0 }}>
                    <h3 style={{ fontSize: '1.15rem', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.35rem', fontFamily: 'var(--font-heading)' }}>
                      <Dumbbell size={16} style={{ color: 'var(--accent-blue)' }} />
                      <span>DAY {dayNum} SPLIT</span>
                    </h3>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span className="badge badge-gray" style={{ fontSize: '0.7rem' }}>{dayExercises.length} Ex</span>
                      <button 
                        onClick={() => { setActiveDay(dayNum); openAddPopup(); }}
                        style={{ border: 'none', background: 'none', display: 'flex', cursor: 'pointer', color: 'var(--text-dim)' }}
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', flex: 1, overflowY: 'auto' }}>
                    {dayExercises.length === 0 ? (
                      <div style={{ margin: 'auto', fontSize: '0.8rem', color: 'var(--text-dim)', textAlign: 'center', padding: '1.5rem 0' }}>
                        Drag exercises here or click +
                      </div>
                    ) : (
                      dayExercises.map(item => (
                        <div
                          key={item.id}
                          draggable
                          onDragStart={() => handleDragStartCanvas(dayNum, item)}
                          style={{
                            display: 'flex', flexDirection: 'column', gap: '0.75rem', padding: '0.75rem',
                            border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                            backgroundColor: 'var(--bg-page)', fontSize: '0.85rem', boxShadow: 'var(--shadow-sm)',
                            position: 'relative'
                          }}
                        >
                          {/* Top part: Drag handle and Name */}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <div style={{ color: 'var(--text-dim)', cursor: 'grab', display: 'flex', alignItems: 'center' }}>
                              <GripVertical size={16} />
                            </div>
                            <input 
                              type="text" 
                              value={item.name} 
                              onChange={(e) => handleInlineEdit(dayNum, item.id, 'name', e.target.value)}
                              style={{ border: 'none', background: 'transparent', fontWeight: 700, fontSize: '0.85rem', padding: 0, width: '100%' }}
                            />
                          </div>

                          {/* Middle part: Parameters */}
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', fontSize: '0.75rem' }}>
                            {/* Sets */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '0.15rem 0.35rem', borderRadius: 'var(--radius-sm)' }}>
                              <input 
                                type="number" 
                                value={item.sets} 
                                onChange={(e) => handleInlineEdit(dayNum, item.id, 'sets', e.target.value)}
                                style={{ border: 'none', background: 'transparent', width: '18px', textAlign: 'center', fontWeight: 800, fontSize: '0.75rem', padding: 0 }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>S</span>
                            </div>

                            {/* Reps */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '0.15rem 0.35rem', borderRadius: 'var(--radius-sm)' }}>
                              <input 
                                type="number" 
                                value={item.reps} 
                                onChange={(e) => handleInlineEdit(dayNum, item.id, 'reps', e.target.value)}
                                style={{ border: 'none', background: 'transparent', width: '18px', textAlign: 'center', fontWeight: 800, fontSize: '0.75rem', padding: 0 }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>R</span>
                            </div>

                            {/* Weight */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '0.15rem 0.35rem', borderRadius: 'var(--radius-sm)' }}>
                              <input 
                                type="number" 
                                value={item.weight} 
                                onChange={(e) => handleInlineEdit(dayNum, item.id, 'weight', e.target.value)}
                                style={{ border: 'none', background: 'transparent', width: '26px', textAlign: 'center', fontWeight: 800, fontSize: '0.75rem', padding: 0 }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>KG</span>
                            </div>

                            {/* Rest */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '0.15rem 0.35rem', borderRadius: 'var(--radius-sm)' }}>
                              <input 
                                type="number" 
                                value={item.restSeconds} 
                                onChange={(e) => handleInlineEdit(dayNum, item.id, 'restSeconds', e.target.value)}
                                style={{ border: 'none', background: 'transparent', width: '22px', textAlign: 'center', fontWeight: 800, fontSize: '0.75rem', padding: 0 }}
                              />
                              <span style={{ color: 'var(--text-dim)', fontWeight: 700 }}>SEC</span>
                            </div>
                          </div>

                          {/* Actions toolbar */}
                          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.25rem', alignItems: 'center', borderTop: '1px solid var(--border-color)', paddingTop: '0.35rem' }}>
                            {item.videoUrl && (
                              <a href={item.videoUrl} target="_blank" rel="noreferrer" style={{ color: 'var(--accent-blue)', display: 'flex', padding: '0.15rem' }}>
                                <ExternalLink size={12} />
                              </a>
                            )}
                            <button 
                              onClick={() => { setActiveDay(dayNum); openEditPopup(item); }}
                              style={{ border: 'none', background: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '0.75rem', padding: '0.15rem' }}
                            >
                              Edit
                            </button>
                            <button 
                              onClick={() => handleRemoveItem(dayNum, item.id)}
                              style={{ border: 'none', background: 'none', color: 'var(--accent-red)', cursor: 'pointer', display: 'flex', padding: '0.15rem' }}
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* --- ADD / EDIT EXERCISE POPUP --- */}
      {showPopup && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '480px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>
                {popupMode === 'add' ? `Add Exercise to Day ${activeDay}` : 'Edit Exercise'}
              </h3>
              <button onClick={() => setShowPopup(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handlePopupSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label>Exercise Name</label>
                <input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} required placeholder="e.g. Dumbbell Incline Fly" style={{ marginTop: '0.25rem' }} />
              </div>

              {popupMode === 'add' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label>Muscle Group</label>
                    <select value={formMuscleGroup} onChange={(e) => setFormMuscleGroup(e.target.value)} style={{ marginTop: '0.25rem' }}>
                      <option value="legs">Legs</option>
                      <option value="chest">Chest</option>
                      <option value="back">Back</option>
                      <option value="shoulders">Shoulders</option>
                      <option value="arms">Arms</option>
                      <option value="core">Core</option>
                    </select>
                  </div>
                  <div>
                    <label>Equipment</label>
                    <input type="text" value={formEquipment} onChange={(e) => setFormEquipment(e.target.value)} required placeholder="barbell, dumbbells, bodyweight" style={{ marginTop: '0.25rem' }} />
                  </div>
                </div>
              )}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Sets</label>
                  <input type="number" value={formSets} onChange={(e) => setFormSets(e.target.value)} required placeholder="4" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Reps</label>
                  <input type="number" value={formReps} onChange={(e) => setFormReps(e.target.value)} required placeholder="10" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Weight (kg)</label>
                  <input type="number" value={formWeight} onChange={(e) => setFormWeight(e.target.value)} required placeholder="25" style={{ marginTop: '0.25rem' }} />
                </div>
                <div>
                  <label>Rest Interval (sec)</label>
                  <input type="number" value={formRestSeconds} onChange={(e) => setFormRestSeconds(e.target.value)} required placeholder="60" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div>
                <label>Video Reference Link (YouTube/Vimeo)</label>
                <input type="url" value={formLink} onChange={(e) => setFormLink(e.target.value)} placeholder="https://youtube.com/watch?v=..." style={{ marginTop: '0.25rem' }} />
              </div>

              <div>
                <label>Or Upload Video File (.mp4, .mov)</label>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.25rem' }}>
                  <input 
                    type="file" 
                    accept="video/*" 
                    onChange={(e) => {
                      if (e.target.files[0]) {
                        setFormLink('https://assets.mixkit.co/videos/preview/mixkit-man-performing-dumbbell-curls-40546-large.mp4');
                        alert('Video uploaded successfully!');
                      }
                    }} 
                    style={{ display: 'none' }}
                    id="video-upload-input"
                  />
                  <label htmlFor="video-upload-input" className="btn btn-secondary" style={{ flex: 1, display: 'flex', gap: '0.5rem', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', margin: 0, padding: '0.5rem 1rem' }}>
                    <Plus size={16} />
                    <span>Upload Video File</span>
                  </label>
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                {popupMode === 'add' ? 'Assign Exercise' : 'Save Details'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- VERSION CONFLICT DIALOG --- */}
      {showConflictDialog && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '400px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)', textAlign: 'center'
          }}>
            <div style={{ color: 'var(--accent-red)', display: 'flex', justifyContent: 'center' }}>
              <AlertTriangle size={48} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>Version Conflict</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.5rem', lineHeight: 1.4 }}>
                This client's workout program was updated elsewhere. Overwriting now would lose their modifications.
              </p>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', width: '100%' }}>
              <button className="btn btn-primary" onClick={handleResolveConflict} style={{ width: '100%' }}>
                <RefreshCw size={16} />
                <span>Pull Server Version</span>
              </button>
              <button className="btn btn-secondary" onClick={() => setShowConflictDialog(false)} style={{ width: '100%' }}>
                <span>Cancel</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- ADD TO GLOBAL EXERCISE LIBRARY MODAL --- */}
      {showLibraryAddModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(2px)'
        }}>
          <div className="card" style={{
            width: '100%', maxWidth: '440px', padding: '2rem', display: 'flex',
            flexDirection: 'column', gap: '1.25rem', boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <h3 style={{ fontSize: '1.35rem', fontFamily: 'var(--font-heading)' }}>Create Library Exercise</h3>
              <button onClick={() => setShowLibraryAddModal(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--text-dim)' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleLibraryAddSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label>Exercise Name</label>
                <input type="text" value={libName} onChange={(e) => setLibName(e.target.value)} required placeholder="e.g. Leg Press" style={{ marginTop: '0.25rem' }} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label>Muscle Group</label>
                  <select value={libMuscleGroup} onChange={(e) => setLibMuscleGroup(e.target.value)} style={{ marginTop: '0.25rem' }}>
                    <option value="legs">Legs</option>
                    <option value="chest">Chest</option>
                    <option value="back">Back</option>
                    <option value="shoulders">Shoulders</option>
                    <option value="arms">Arms</option>
                    <option value="core">Core</option>
                  </select>
                </div>
                <div>
                  <label>Equipment</label>
                  <input type="text" value={libEquipment} onChange={(e) => setLibEquipment(e.target.value)} required placeholder="machine, dumbbells, barbell" style={{ marginTop: '0.25rem' }} />
                </div>
              </div>

              <div>
                <label>Reference Video Link</label>
                <input type="url" value={libVideoUrl} onChange={(e) => setLibVideoUrl(e.target.value)} placeholder="https://youtube.com/watch?v=..." style={{ marginTop: '0.25rem' }} />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                Save to Exercise Database
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default WorkoutAssign;
