// Login.jsx
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, AlertCircle, ArrowRight } from 'lucide-react';

export const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('bilal@example.com');
  const [password, setPassword] = useState('Str0ngPass!');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Forgot password views
  const [forgotMode, setForgotMode] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = await login(email, password);
      if (result.success) {
        navigate('/clients');
      } else {
        setError(result.error.message || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSubmit = async (e) => {
    e.preventDefault();
    setForgotSuccess('');
    if (!forgotEmail) return;
    
    setLoading(true);
    // Simulate forgotPassword API
    setTimeout(() => {
      setForgotSuccess('If this email exists, a reset link has been sent.');
      setLoading(false);
    }, 500);
  };

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'var(--bg-page)',
      padding: '1.5rem'
    }}>
      <div className="card" style={{
        width: '100%',
        maxWidth: '440px',
        padding: '2.5rem',
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
      }}>
        {/* Brand Header */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '0.5rem',
          textAlign: 'center',
          marginBottom: '2rem'
        }}>
          <div style={{
            backgroundColor: 'var(--bg-dark)',
            color: 'var(--accent-lime-vivid)',
            padding: '0.75rem',
            borderRadius: 'var(--radius-lg)',
            display: 'inline-flex'
          }}>
            <TrendingUp size={32} />
          </div>
          <h2 style={{ fontSize: '2.25rem', color: 'var(--text-main)', marginTop: '0.5rem' }}>FitTrack</h2>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 700 }}>Trainer Portal Access</span>
        </div>

        {/* Error Dialog */}
        {error && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            backgroundColor: 'rgba(239, 68, 68, 0.08)',
            border: '1px solid rgba(239, 68, 68, 0.2)',
            color: 'var(--accent-red)',
            padding: '0.75rem 1rem',
            borderRadius: 'var(--radius-md)',
            marginBottom: '1.5rem',
            fontSize: '0.9rem'
          }}>
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>{error}</span>
          </div>
        )}

        {!forgotMode ? (
          /* Login Form */
          <form onSubmit={handleLoginSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div>
              <label htmlFor="email-input">Email Address</label>
              <input 
                id="email-input"
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                placeholder="trainer@fittrack.com"
                required
                style={{ marginTop: '0.5rem' }}
              />
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label htmlFor="password-input">Password</label>
                <button 
                  type="button" 
                  onClick={() => setForgotMode(true)}
                  style={{
                    border: 'none',
                    background: 'none',
                    color: 'var(--accent-blue)',
                    fontSize: '0.8rem',
                    cursor: 'pointer',
                    fontWeight: 600
                  }}
                >
                  Forgot Password?
                </button>
              </div>
              <input 
                id="password-input"
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                style={{ marginTop: '0.5rem' }}
              />
            </div>

            <button 
              type="submit" 
              className="btn btn-primary" 
              disabled={loading}
              style={{ width: '100%', marginTop: '0.75rem', height: '48px' }}
            >
              <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
              <ArrowRight size={18} />
            </button>
            
            <div style={{ textAlign: 'center', marginTop: '0.5rem' }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                Demo Credentials: <strong style={{ color: 'var(--text-muted)' }}>bilal@example.com</strong> / <strong style={{ color: 'var(--text-muted)' }}>Str0ngPass!</strong>
              </span>
            </div>
          </form>
        ) : (
          /* Forgot Password Form */
          <form onSubmit={handleForgotSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
              Enter your trainer email below. If the account exists, we will simulate dispatching a reset password link.
            </p>

            {forgotSuccess && (
              <div style={{
                backgroundColor: 'rgba(16, 185, 129, 0.08)',
                border: '1px solid rgba(16, 185, 129, 0.2)',
                color: '#10B981',
                padding: '0.75rem 1rem',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.9rem',
                fontWeight: 600
              }}>
                {forgotSuccess}
              </div>
            )}

            <div>
              <label htmlFor="forgot-email">Account Email</label>
              <input 
                id="forgot-email"
                type="email" 
                value={forgotEmail} 
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="trainer@fittrack.com"
                required
                style={{ marginTop: '0.5rem' }}
              />
            </div>

            <button 
              type="submit" 
              className="btn btn-primary" 
              disabled={loading}
              style={{ width: '100%', marginTop: '0.5rem' }}
            >
              <span>{loading ? 'Processing...' : 'Send Reset Link'}</span>
            </button>

            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => {
                setForgotMode(false);
                setForgotSuccess('');
                setError('');
              }}
              style={{ width: '100%' }}
            >
              <span>Back to Login</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
export default Login;
