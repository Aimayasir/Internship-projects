// Analytics.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/apiClient';
import { BarChart2, TrendingUp, AlertCircle, CheckCircle, ChevronLeft, ChevronRight, User } from 'lucide-react';

export const Analytics = () => {
  const navigate = useNavigate();

  // Dashboard Overview state
  const [overview, setOverview] = useState(null);
  const [loadingOverview, setLoadingOverview] = useState(true);

  // At risk list state
  const [atRisk, setAtRisk] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loadingAtRisk, setLoadingAtRisk] = useState(true);

  useEffect(() => {
    fetchOverview();
    fetchAtRiskClients(1);
  }, []);

  const fetchOverview = async () => {
    setLoadingOverview(true);
    const res = await apiClient.getDashboardOverview();
    if (res.success) {
      setOverview(res.data);
    }
    setLoadingOverview(false);
  };

  const fetchAtRiskClients = async (pageNum) => {
    setLoadingAtRisk(true);
    const res = await apiClient.getAtRiskClients({ page: pageNum, limit: 2 });
    if (res.success) {
      setAtRisk(res.data.clients);
      setPage(res.data.pagination.page);
      setTotalPages(res.data.pagination.totalPages);
    }
    setLoadingAtRisk(false);
  };

  const handleClientClick = (clientId) => {
    navigate(`/clients`);
  };

  return (
    <div className="main-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
      <div className="page-header">
        <div>
          <h2 className="page-title">Compliance Analytics</h2>
          <p className="page-subtitle">Monitor client compliance, activity logs, and isolate at-risk profiles.</p>
        </div>
      </div>

      {loadingOverview ? (
        <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-dim)' }}>Loading compliance indicators...</div>
      ) : (
        /* Widget Stats Counters Grid */
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem' }}>
          <div className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Active Members</span>
              <h3 style={{ fontSize: '2.5rem', fontFamily: 'var(--font-heading)', color: 'var(--text-main)', marginTop: '0.25rem' }}>
                {overview?.activeClients}
              </h3>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Scoped trainer ID</span>
            </div>
            <div style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#10B981' }}>
              <CheckCircle size={22} />
            </div>
          </div>

          <div className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Avg Adherence</span>
              <h3 style={{ fontSize: '2.5rem', fontFamily: 'var(--font-heading)', color: 'var(--accent-blue)', marginTop: '0.25rem' }}>
                {Math.round(overview?.adherenceRate * 100)}%
              </h3>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Calculated adherence</span>
            </div>
            <div style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(37, 99, 235, 0.1)', color: 'var(--accent-blue)' }}>
              <TrendingUp size={22} />
            </div>
          </div>

          <div className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Missed Workouts</span>
              <h3 style={{ fontSize: '2.5rem', fontFamily: 'var(--font-heading)', color: 'var(--accent-red)', marginTop: '0.25rem' }}>
                {overview?.missedWorkoutsThisWeek}
              </h3>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Missed workouts total</span>
            </div>
            <div style={{ padding: '0.75rem', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--accent-red)' }}>
              <AlertCircle size={22} />
            </div>
          </div>
        </div>
      )}

      {/* Analytics Chart & At-Risk Split grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '2rem', alignItems: 'flex-start' }}>
        
        {/* Compliance trends logs */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', height: '400px' }}>
          <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)' }}>Compliance Charts</h3>
          <div style={{ display: 'flex', flex: 1, backgroundColor: 'var(--bg-page)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-lg)', alignItems: 'center', justifyContent: 'center', color: 'var(--text-dim)' }}>
            <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}>
              <BarChart2 size={40} />
              <span>Trainer compliance graph rendering stub</span>
            </div>
          </div>
        </div>

        {/* At risk list cards */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', minHeight: '400px' }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontFamily: 'var(--font-heading)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <AlertCircle size={18} style={{ color: 'var(--accent-red)' }} />
              <span>At-Risk Members</span>
            </h3>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: '0.25rem' }}>
              List of clients whose program compliance rates have dropped below 60%.
            </p>
          </div>

          {loadingAtRisk ? (
            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-dim)' }}>Loading risk list...</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', flex: 1 }}>
              {atRisk.length === 0 ? (
                <div style={{ margin: 'auto', color: 'var(--text-dim)', fontSize: '0.9rem' }}>No clients at risk! Excellent adherence.</div>
              ) : (
                atRisk.map(c => (
                  <div 
                    key={c.id}
                    onClick={() => handleClientClick(c.id)}
                    style={{
                      border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '1rem',
                      backgroundColor: 'var(--bg-page)', display: 'flex', flexDirection: 'column', gap: '0.5rem',
                      cursor: 'pointer', transition: 'border 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--accent-red)'}
                    onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border-color)'}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-main)' }}>{c.name}</span>
                      <span style={{ color: 'var(--accent-red)', fontWeight: 800, fontSize: '0.9rem' }}>{Math.round(c.adherence * 100)}%</span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      <span>Missed: {c.workoutsMissed} workouts • {c.mealsMissed} meals</span>
                      <span>Last Seen: {new Date(c.lastActive).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))
              )}

              {/* Pagination controls */}
              {totalPages > 1 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                    Page {page} of {totalPages}
                  </span>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="btn btn-secondary" disabled={page === 1} onClick={() => fetchAtRiskClients(page - 1)} style={{ padding: '0.35rem 0.75rem' }}>
                      <ChevronLeft size={16} />
                    </button>
                    <button className="btn btn-secondary" disabled={page === totalPages} onClick={() => fetchAtRiskClients(page + 1)} style={{ padding: '0.35rem 0.75rem' }}>
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
export default Analytics;
