// Notifications.jsx
import React, { useState, useEffect } from 'react';
import { apiClient } from '../api/apiClient';
import { Bell, Send, CheckSquare, Square, AlertCircle, Eye, EyeOff, ChevronLeft, ChevronRight, Check } from 'lucide-react';

export const Notifications = () => {
  // Composer state
  const [clients, setClients] = useState([]);
  const [selectedClients, setSelectedClients] = useState([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [composerError, setComposerError] = useState('');
  const [composerSuccess, setComposerSuccess] = useState('');
  const [composerLoading, setComposerLoading] = useState(false);

  // Log state
  const [log, setLog] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [logLoading, setLogLoading] = useState(true);
  const [logError, setLogError] = useState('');

  useEffect(() => {
    fetchClients();
    fetchNotifications(1);
  }, []);

  const fetchClients = async () => {
    const res = await apiClient.getClients({ limit: 100 }); // get all for selection
    if (res.success) {
      setClients(res.data.clients);
    }
  };

  const fetchNotifications = async (page) => {
    setLogLoading(true);
    setLogError('');
    const res = await apiClient.getNotifications({ page, limit: 5 });
    if (res.success) {
      setLog(res.data.notifications);
      setCurrentPage(res.data.pagination.page);
      setTotalPages(res.data.pagination.totalPages);
    } else {
      setLogError(res.error.message);
    }
    setLogLoading(false);
  };

  // Toggle single client selection
  const handleToggleClient = (clientId) => {
    if (selectedClients.includes(clientId)) {
      setSelectedClients(selectedClients.filter(id => id !== clientId));
    } else {
      setSelectedClients([...selectedClients, clientId]);
    }
  };

  // Select all checkbox
  const handleToggleAllClients = () => {
    if (selectedClients.length === clients.length) {
      setSelectedClients([]);
    } else {
      setSelectedClients(clients.map(c => c.id));
    }
  };

  // Send Custom Notification
  const handleSendNotification = async (e) => {
    e.preventDefault();
    setComposerError('');
    setComposerSuccess('');
    setComposerLoading(true);

    const recipientIds = selectedClients.length === clients.length ? 'all' : selectedClients;

    const res = await apiClient.sendCustomNotification({
      recipientIds,
      title,
      body
    });

    if (res.success) {
      setComposerSuccess(`Alert dispatched successfully to ${res.data.sentCount} client(s)!`);
      setTitle('');
      setBody('');
      setSelectedClients([]);
      // Refresh the log
      fetchNotifications(1);
    } else if (res.status === 422) {
      // 422 EMPTY_RECIPIENT_LIST
      setComposerError(res.error.message);
    } else {
      setComposerError(res.error.message || 'Failed to dispatch notification');
    }
    setComposerLoading(false);
  };

  // Mark single as read
  const handleMarkRead = async (id) => {
    const res = await apiClient.markNotificationRead(id);
    if (res.success) {
      fetchNotifications(currentPage);
    }
  };

  // Mark all as read
  const handleMarkAllRead = async () => {
    const res = await apiClient.markAllNotificationsRead();
    if (res.success) {
      fetchNotifications(1);
    }
  };

  const getNotifBadgeColor = (type) => {
    switch (type) {
      case 'missed_workout': return 'badge-red';
      case 'missed_meal': return 'badge-orange';
      case 'session_reminder': return 'badge-blue';
      case 'new_message': return 'badge-lime';
      default: return 'badge-gray';
    }
  };

  return (
    <div className="main-content" style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '2rem', alignItems: 'flex-start' }}>
      
      {/* Left Card: Custom Notification Composer */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <div>
          <h2 className="page-title" style={{ fontSize: '1.8rem' }}>Notification Composer</h2>
          <p className="page-subtitle">Send instant push alerts directly to your clients' mobile apps.</p>
        </div>

        {composerError && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            backgroundColor: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)',
            color: 'var(--accent-red)', padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', fontSize: '0.9rem'
          }}>
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>{composerError}</span>
          </div>
        )}

        {composerSuccess && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)',
            color: '#10B981', padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)', fontSize: '0.9rem', fontWeight: 600
          }}>
            <Check size={18} style={{ flexShrink: 0 }} />
            <span>{composerSuccess}</span>
          </div>
        )}

        <form onSubmit={handleSendNotification} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {/* Recipient Selection block */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <label>Select Recipients</label>
              <button 
                type="button" 
                onClick={handleToggleAllClients}
                style={{
                  border: 'none', background: 'none', color: 'var(--accent-blue)',
                  fontWeight: 700, cursor: 'pointer', fontSize: '0.8rem', textTransform: 'uppercase'
                }}
              >
                {selectedClients.length === clients.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>
            
            <div style={{
              maxHeight: '160px', overflowY: 'auto', border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)', padding: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.25rem'
            }}>
              {clients.map(c => {
                const isSelected = selectedClients.includes(c.id);
                return (
                  <div 
                    key={c.id} 
                    onClick={() => handleToggleClient(c.id)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.4rem 0.5rem',
                      borderRadius: 'var(--radius-sm)', cursor: 'pointer', backgroundColor: isSelected ? 'rgba(37, 99, 235, 0.05)' : 'transparent'
                    }}
                  >
                    {isSelected ? (
                      <CheckSquare size={16} style={{ color: 'var(--accent-blue)' }} />
                    ) : (
                      <Square size={16} style={{ color: 'var(--text-dim)' }} />
                    )}
                    <span style={{ fontSize: '0.9rem', fontWeight: isSelected ? 600 : 400 }}>{c.name}</span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginLeft: 'auto' }}>{c.email}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '0.25rem', textAlign: 'right' }}>
              {selectedClients.length} of {clients.length} selected
            </div>
          </div>

          <div>
            <label htmlFor="notif-title">Alert Title</label>
            <input 
              id="notif-title"
              type="text" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              required 
              placeholder="e.g. Schedule Change" 
              style={{ marginTop: '0.25rem' }} 
            />
          </div>

          <div>
            <label htmlFor="notif-body">Alert Message Body</label>
            <textarea 
              id="notif-body"
              value={body} 
              onChange={(e) => setBody(e.target.value)} 
              required 
              rows={4} 
              placeholder="e.g. Tomorrow's 9:00 AM class has been shifted to 10:30 AM." 
              style={{ marginTop: '0.25rem', width: '100%', resize: 'none' }} 
            />
          </div>

          <button 
            type="submit" 
            className="btn btn-primary" 
            disabled={composerLoading}
            style={{ display: 'flex', gap: '0.5rem', width: '100%', height: '44px', marginTop: '0.5rem' }}
          >
            <Send size={16} />
            <span>{composerLoading ? 'Dispatching Push...' : 'Broadcast Push Notification'}</span>
          </button>
        </form>
      </div>

      {/* Right Card: Read-only System Notifications Log */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h2 className="page-title" style={{ fontSize: '1.8rem' }}>System Log</h2>
            <p className="page-subtitle">Read-only history of auto-alerts and custom notifications.</p>
          </div>
          <button className="btn btn-secondary" onClick={handleMarkAllRead} style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem' }}>
            Mark All Read
          </button>
        </div>

        {logError && (
          <div style={{ color: 'var(--accent-red)', fontSize: '0.9rem' }}>{logError}</div>
        )}

        {logLoading ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-dim)' }}>Loading log entries...</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', flex: 1 }}>
            {log.length === 0 ? (
              <div style={{ margin: 'auto', color: 'var(--text-dim)', fontSize: '0.9rem' }}>No notifications in log</div>
            ) : (
              log.map(item => (
                <div 
                  key={item.id} 
                  style={{
                    border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '1rem',
                    backgroundColor: item.readAt ? 'var(--bg-card)' : 'rgba(37, 99, 235, 0.02)',
                    borderLeft: item.readAt ? '1px solid var(--border-color)' : '4px solid var(--accent-blue)',
                    position: 'relative', transition: 'all 0.2s'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.35rem' }}>
                    <span 
                      style={{ fontSize: '0.7rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.05em' }}
                      className={item.type === 'missed_workout' ? 'badge-red' : item.type === 'missed_meal' ? 'badge-orange' : item.type === 'session_reminder' ? 'badge-blue' : 'badge-lime'}
                    >
                      {item.type.replace('_', ' ')}
                    </span>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-dim)' }}>
                      {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <h4 style={{ fontSize: '1rem', fontFamily: 'var(--font-body)', fontWeight: 700, color: 'var(--text-main)' }}>{item.title}</h4>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem', lineHeight: 1.4 }}>{item.body}</p>
                  
                  {/* Mark single as read */}
                  {!item.readAt && (
                    <button 
                      onClick={() => handleMarkRead(item.id)}
                      style={{
                        position: 'absolute', bottom: '0.75rem', right: '1rem', border: 'none', background: 'none',
                        color: 'var(--accent-blue)', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 600
                      }}
                    >
                      Mark read
                    </button>
                  )}
                </div>
              ))
            )}

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                  Page {currentPage} of {totalPages}
                </span>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button 
                    className="btn btn-secondary" 
                    disabled={currentPage === 1}
                    onClick={() => fetchNotifications(currentPage - 1)}
                    style={{ padding: '0.4rem 0.8rem' }}
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <button 
                    className="btn btn-secondary" 
                    disabled={currentPage === totalPages}
                    onClick={() => fetchNotifications(currentPage + 1)}
                    style={{ padding: '0.4rem 0.8rem' }}
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
export default Notifications;
