// AuthContext.jsx
import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../api/apiClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check initial auth state
    const savedToken = localStorage.getItem('authToken');
    const savedProfile = localStorage.getItem('trainerProfile');
    
    if (savedToken && savedProfile) {
      setToken(savedToken);
      setUser(JSON.parse(savedProfile));
    }
    setLoading(false);

    // Global listener for API 401/403 errors
    const handleAuthFailure = () => {
      setToken(null);
      setUser(null);
    };

    window.addEventListener('auth-failure', handleAuthFailure);
    return () => window.removeEventListener('auth-failure', handleAuthFailure);
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    const result = await apiClient.login(email, password);
    if (result.success) {
      localStorage.setItem('authToken', result.data.token);
      localStorage.setItem('trainerProfile', JSON.stringify(result.data.trainer));
      setToken(result.data.token);
      setUser(result.data.trainer);
    }
    setLoading(false);
    return result;
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('trainerProfile');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
