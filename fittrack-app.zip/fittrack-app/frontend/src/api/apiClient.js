// apiClient.js
// API Client wrapper that injects Authorization headers, handles redirects on 401/403,
// supports query parameters, file uploads (FormData), and switches between mock and real APIs.

import { mockApi } from './mockApi';

// Set to false to switch to real REST endpoints
const USE_MOCK = false;
const BASE_URL = 'http://localhost:5000/api';

// Helper to simulate latency
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Intercept responses for auth failures
function checkAuth(response) {
  if (!response.success && response.error) {
    if (response.error.code === 'UNAUTHORIZED' || response.error.code === 'ACCOUNT_DISABLED') {
      localStorage.removeItem('authToken');
      localStorage.removeItem('trainerProfile');
      // Trigger a custom event to force a redirect in UI
      window.dispatchEvent(new Event('auth-failure'));
    }
  }
  return response;
}

export const apiClient = {
  // Generic request handler
  request: async (endpoint, options = {}) => {
    // 1. JWT Injection Check
    const token = localStorage.getItem('authToken');
    const isPublic = options.isPublic || false;
    
    await delay(100); // Simulate light network latency

    if (!token && !isPublic) {
      return checkAuth({
        success: false,
        error: { code: 'UNAUTHORIZED', message: 'Missing or invalid token' }
      });
    }

    if (USE_MOCK) {
      try {
        const result = await endpoint();
        // Simulate disabled account randomly or on trigger
        if (localStorage.getItem('simulate_account_disabled') === 'true') {
          return checkAuth({
            success: false,
            error: { code: 'ACCOUNT_DISABLED', message: 'This account has been suspended or removed' }
          });
        }
        return checkAuth(result);
      } catch (err) {
        return { success: false, error: { code: 'SERVER_ERROR', message: err.message } };
      }
    } else {
      // Build real target URL with optional query parameters
      let url = `${BASE_URL}${options.path}`;
      if (options.query) {
        const cleanQuery = {};
        Object.keys(options.query).forEach(k => {
          if (options.query[k] !== undefined && options.query[k] !== null) {
            cleanQuery[k] = options.query[k];
          }
        });
        const qs = new URLSearchParams(cleanQuery).toString();
        if (qs) {
          url += `?${qs}`;
        }
      }

      // Handle FormData vs JSON content type
      const isFormData = options.body instanceof FormData;
      const headers = {
        ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      };
      
      try {
        const response = await fetch(url, {
          method: options.method || 'GET',
          headers,
          body: isFormData ? options.body : (options.body ? JSON.stringify(options.body) : undefined)
        });
        
        if (response.status === 401) {
          return checkAuth({ success: false, error: { code: 'UNAUTHORIZED', message: 'Unauthorized' } });
        }
        if (response.status === 403) {
          return checkAuth({ success: false, error: { code: 'ACCOUNT_DISABLED', message: 'Account disabled' } });
        }
        if (response.status === 409) {
          const currentPlan = await response.json();
          return { success: false, status: 409, error: { code: 'VERSION_CONFLICT', message: 'Conflict', currentPlan } };
        }
        
        const data = await response.json();
        return checkAuth(data);
      } catch (err) {
        return { success: false, error: { code: 'NETWORK_ERROR', message: 'Failed to connect to server' } };
      }
    }
  },

  // Auth Methods
  login: (email, password) => 
    apiClient.request(() => mockApi.login(email, password), { 
      isPublic: true, 
      path: '/auth/trainer/login', 
      method: 'POST', 
      body: { email, password } 
    }),
    
  forgotPassword: (email) => 
    apiClient.request(() => mockApi.forgotPassword(email), { 
      isPublic: true, 
      path: '/auth/trainer/forgot-password', 
      method: 'POST', 
      body: { email } 
    }),
    
  resetPassword: (token, newPassword) => 
    apiClient.request(() => mockApi.resetPassword(token, newPassword), { 
      isPublic: true, 
      path: '/auth/trainer/reset-password', 
      method: 'POST', 
      body: { token, newPassword } 
    }),

  // Trainer Profile Methods
  getProfile: () =>
    apiClient.request(() => mockApi.getProfile(), { 
      path: '/trainer/profile', 
      method: 'GET' 
    }),

  updateProfile: (payload) =>
    apiClient.request(() => {
      const current = localStorage.getItem('trainerProfile') ? JSON.parse(localStorage.getItem('trainerProfile')) : {};
      const updated = { ...current, ...payload };
      localStorage.setItem('trainerProfile', JSON.stringify(updated));
      return Promise.resolve({ success: true, data: updated });
    }, { 
      path: '/trainer/profile', 
      method: 'PATCH', 
      body: payload 
    }),

  uploadProfilePhoto: (formData) =>
    apiClient.request(() => Promise.resolve({ success: true, data: { photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb' } }), { 
      path: '/trainer/profile/photo', 
      method: 'POST', 
      body: formData 
    }),

  deleteProfilePhoto: () =>
    apiClient.request(() => Promise.resolve({ success: true }), { 
      path: '/trainer/profile/photo', 
      method: 'DELETE' 
    }),

  changePassword: (payload) =>
    apiClient.request(() => Promise.resolve({ success: true }), { 
      path: '/trainer/profile/change-password', 
      method: 'POST', 
      body: payload 
    }),

  getNotificationSettings: () =>
    apiClient.request(() => {
      const saved = localStorage.getItem('trainer_notif_settings');
      const data = saved ? JSON.parse(saved) : { newClientJoined: true, newMessage: true, missedWorkoutAlert: true, missedMealAlert: false };
      return Promise.resolve({ success: true, data });
    }, { 
      path: '/trainer/notification-settings', 
      method: 'GET' 
    }),

  updateNotificationSettings: (settings) =>
    apiClient.request(() => {
      localStorage.setItem('trainer_notif_settings', JSON.stringify(settings));
      return Promise.resolve({ success: true, data: settings });
    }, { 
      path: '/trainer/notification-settings', 
      method: 'PATCH', 
      body: settings 
    }),

  getDashboardOverview: () =>
    apiClient.request(() => Promise.resolve({
      success: true,
      data: {
        activeClients: 24,
        programsLive: 18,
        missedWorkoutsThisWeek: 6,
        adherenceRate: 0.86,
        recentActivity: [
          { clientId: 'c_501', clientName: 'Sara Khan', type: 'workout_completed', at: '2026-07-21T18:32:00Z' },
          { clientId: 'c_502', clientName: 'Ali Raza', type: 'message', at: '2026-07-21T17:10:00Z' },
          { clientId: 'c_503', clientName: 'Ayesha Noor', type: 'joined', at: '2026-07-21T09:00:00Z' }
        ]
      }
    }), { 
      path: '/trainer/dashboard', 
      method: 'GET' 
    }),

  // Client Management
  getClients: (params) => 
    apiClient.request(() => mockApi.getClients(params), { 
      path: '/clients', 
      method: 'GET', 
      query: params 
    }),

  getClientById: (clientId) => 
    apiClient.request(() => mockApi.getClientById(clientId), { 
      path: `/clients/${clientId}`, 
      method: 'GET' 
    }),

  updateClient: (clientId, payload) =>
    apiClient.request(() => {
      const localClients = JSON.parse(localStorage.getItem('clients')) || [];
      const idx = localClients.findIndex(c => c.id === clientId);
      if (idx !== -1) {
        localClients[idx] = { ...localClients[idx], ...payload };
        localStorage.setItem('clients', JSON.stringify(localClients));
      }
      return Promise.resolve({ success: true, data: { id: clientId, ...payload } });
    }, { 
      path: `/clients/${clientId}`, 
      method: 'PATCH', 
      body: payload 
    }),

  deleteClient: (clientId) =>
    apiClient.request(() => {
      const localClients = JSON.parse(localStorage.getItem('clients')) || [];
      const updated = localClients.filter(c => c.id !== clientId);
      localStorage.setItem('clients', JSON.stringify(updated));
      return Promise.resolve({ success: true });
    }, { 
      path: `/clients/${clientId}`, 
      method: 'DELETE' 
    }),

  addClientManual: (payload) =>
    apiClient.request(() => {
      const localClients = JSON.parse(localStorage.getItem('clients')) || [];
      const newClient = { id: `c_${Date.now()}`, ...payload, status: 'pending', planType: 'unassigned', adherence: 0.00, joinedAt: new Date().toISOString(), lastActive: null };
      localClients.push(newClient);
      localStorage.setItem('clients', JSON.stringify(localClients));
      return Promise.resolve({ success: true, data: newClient });
    }, { 
      path: '/clients/manual', 
      method: 'POST', 
      body: payload 
    }),

  // Invite Links
  getInviteCurrent: () =>
    apiClient.request(() => {
      const savedCode = localStorage.getItem('invite_code') || 'BILAL2026';
      return Promise.resolve({
        success: true,
        data: { code: savedCode, link: `https://fittrack.app/join/${savedCode}`, createdAt: '2026-07-01T08:00:00Z' }
      });
    }, { 
      path: '/invite/current', 
      method: 'GET' 
    }),

  getInviteLog: (params) =>
    apiClient.request(() => {
      const allJoins = [
        { clientId: 'c_501', clientName: 'Sara Khan', joinedAt: '2026-06-01T10:00:00Z' },
        { clientId: 'c_502', clientName: 'Ali Raza', joinedAt: '2026-06-05T14:20:00Z' },
        { clientId: 'c_503', clientName: 'Ayesha Noor', joinedAt: '2026-07-21T09:00:00Z' },
        { clientId: 'c_504', clientName: 'Zain Malik', joinedAt: '2026-07-22T08:30:00Z' },
        { clientId: 'c_505', clientName: 'Fatima Shah', joinedAt: '2026-07-22T10:00:00Z' }
      ];
      const pageNum = params?.page || 1;
      const limit = params?.limit || 3;
      const total = allJoins.length;
      const totalPages = Math.ceil(total / limit);
      const start = (pageNum - 1) * limit;
      const paginated = allJoins.slice(start, start + limit);
      return Promise.resolve({
        success: true,
        data: {
          joins: paginated,
          pagination: { page: pageNum, limit, total, totalPages }
        }
      });
    }, { 
      path: '/invite/log', 
      method: 'GET', 
      query: params 
    }),

  regenerateInviteCode: () =>
    apiClient.request(() => {
      const randomId = Math.floor(1000 + Math.random() * 9000);
      const newCode = `BILAL${randomId}`;
      localStorage.setItem('invite_code', newCode);
      return Promise.resolve({
        success: true,
        data: { code: newCode, link: `https://fittrack.app/join/${newCode}` }
      });
    }, { 
      path: '/invite/generate', 
      method: 'POST' 
    }),

  // Analytics
  getAtRiskClients: (params) =>
    apiClient.request(() => {
      const allAtRisk = [
        { id: 'c_504', name: 'Zain Malik', lastActive: '2026-07-18T12:00:00Z', mealsMissed: 4, workoutsMissed: 5, adherence: 0.42, status: 'at_risk' },
        { id: 'c_507', name: 'Zeeshan Jamil', lastActive: '2026-07-15T09:00:00Z', mealsMissed: 8, workoutsMissed: 6, adherence: 0.31, status: 'at_risk' },
        { id: 'c_508', name: 'Fahad Mustafa', lastActive: '2026-07-14T11:00:00Z', mealsMissed: 5, workoutsMissed: 7, adherence: 0.48, status: 'at_risk' }
      ];
      const pageNum = params?.page || 1;
      const limit = params?.limit || 2;
      const total = allAtRisk.length;
      const totalPages = Math.ceil(total / limit);
      const start = (pageNum - 1) * limit;
      const paginated = allAtRisk.slice(start, start + limit);
      return Promise.resolve({
        success: true,
        data: {
          clients: paginated,
          pagination: { page: pageNum, limit, total, totalPages }
        }
      });
    }, { 
      path: '/analytics/clients', 
      method: 'GET', 
      query: params 
    }),

  // Chat Broadcasts
  getBroadcasts: () =>
    apiClient.request(() => {
      const saved = localStorage.getItem('broadcasts');
      return Promise.resolve({
        success: true,
        data: saved ? JSON.parse(saved) : [
          { id: 'bc_15', groupName: 'All Clients', message: 'Reminder: no group class this Friday.', sentAt: '2026-07-20T08:00:00Z', deliveredCount: 24, readCount: 18 }
        ]
      });
    }, { 
      path: '/chat/broadcasts', 
      method: 'GET' 
    }),

  sendBroadcast: (payload) =>
    apiClient.request(() => {
      const newBc = {
        id: `bc_${Date.now()}`,
        groupName: payload.groupName || 'Group',
        message: payload.message,
        sentAt: new Date().toISOString(),
        deliveredCount: 10,
        readCount: 7,
        allowReplies: payload.allowReplies
      };
      const bcs = JSON.parse(localStorage.getItem('broadcasts')) || [];
      bcs.push(newBc);
      localStorage.setItem('broadcasts', JSON.stringify(bcs));
      return Promise.resolve({ success: true, data: newBc });
    }, { 
      path: '/chat/broadcast', 
      method: 'POST', 
      body: payload 
    }),

  // Nutrition Plan
  getNutritionLibrary: (params) => 
    apiClient.request(() => mockApi.getNutritionLibrary(params), { 
      path: '/nutrition/library', 
      method: 'GET', 
      query: params 
    }),
    
  getNutritionDefaults: (type) => 
    apiClient.request(() => mockApi.getNutritionDefaults(type), { 
      path: '/nutrition/defaults', 
      method: 'GET', 
      query: { type } 
    }),

  getNutritionClientPlan: (clientId) => 
    apiClient.request(() => mockApi.getNutritionClientPlan(clientId), { 
      path: `/nutrition/clients/${clientId}/plan`, 
      method: 'GET' 
    }),

  applyDefaultNutrition: (clientId, type) => 
    apiClient.request(() => mockApi.applyDefaultNutrition(clientId, type), { 
      path: `/nutrition/clients/${clientId}/apply-default`, 
      method: 'POST', 
      body: { type } 
    }),

  customizeNutrition: (clientId) => 
    apiClient.request(() => mockApi.customizeNutrition(clientId), { 
      path: `/nutrition/clients/${clientId}/customize`, 
      method: 'POST' 
    }),

  updateNutritionPlan: (clientId, plan) => 
    apiClient.request(() => mockApi.updateNutritionPlan(clientId, plan), { 
      path: `/nutrition/clients/${clientId}/plan`, 
      method: 'PUT', 
      body: plan 
    }),

  addNutritionItem: (clientId, payload) => 
    apiClient.request(() => mockApi.addNutritionItem(clientId, payload), { 
      path: `/nutrition/clients/${clientId}/items`, 
      method: 'POST', 
      body: payload 
    }),

  // Exercises & Workout Programs
  getExercises: (params) => 
    apiClient.request(() => mockApi.getExercises(params), { 
      path: '/exercises', 
      method: 'GET', 
      query: params 
    }),

  addExerciseToLibrary: (payload) => 
    apiClient.request(() => mockApi.addExerciseToLibrary(payload), { 
      path: '/exercises', 
      method: 'POST', 
      body: payload 
    }),

  getProgramDefaults: (type) => 
    apiClient.request(() => mockApi.getProgramDefaults(type), { 
      path: '/programs/defaults', 
      method: 'GET', 
      query: { type } 
    }),

  getWorkoutClientPlan: (clientId) => 
    apiClient.request(() => mockApi.getWorkoutClientPlan(clientId), { 
      path: `/programs/clients/${clientId}/plan`, 
      method: 'GET' 
    }),

  applyDefaultWorkout: (clientId, type) => 
    apiClient.request(() => mockApi.applyDefaultWorkout(clientId, type), { 
      path: `/programs/clients/${clientId}/apply-default`, 
      method: 'POST', 
      body: { type } 
    }),

  customizeWorkout: (clientId) => 
    apiClient.request(() => mockApi.customizeWorkout(clientId), { 
      path: `/programs/clients/${clientId}/customize`, 
      method: 'POST' 
    }),

  updateWorkoutPlan: (clientId, plan) => 
    apiClient.request(() => mockApi.updateWorkoutPlan(clientId, plan), { 
      path: `/programs/clients/${clientId}/plan`, 
      method: 'PUT', 
      body: plan 
    }),

  addWorkoutExercise: (clientId, payload) => 
    apiClient.request(() => mockApi.addWorkoutExercise(clientId, payload), { 
      path: `/programs/clients/${clientId}/exercises`, 
      method: 'POST', 
      body: payload 
    }),

  // Notifications
  getNotifications: (params) => 
    apiClient.request(() => mockApi.getNotifications(params), { 
      path: '/notifications', 
      method: 'GET', 
      query: params 
    }),

  sendCustomNotification: (payload) => 
    apiClient.request(() => mockApi.sendCustomNotification(payload), { 
      path: '/notifications/custom', 
      method: 'POST', 
      body: payload 
    }),

  markNotificationRead: (id) => 
    apiClient.request(() => mockApi.markNotificationRead(id), { 
      path: `/notifications/${id}/read`, 
      method: 'PATCH' 
    }),

  markAllNotificationsRead: () => 
    apiClient.request(() => mockApi.markAllNotificationsRead(), { 
      path: '/notifications/read-all', 
      method: 'PATCH' 
    })
};
