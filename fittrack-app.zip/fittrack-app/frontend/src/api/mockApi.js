// mockApi.js
// Stateful mock API layer that persists in localStorage

const DEFAULT_TRAINER = {
  id: "t_101",
  name: "Bilal Ahmed",
  email: "bilal@example.com",
  phone: "+923001112222",
  photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
  bio: "Certified strength coach, 8 years experience.",
  specialtyTags: ["strength", "weight-loss"],
  address: { line1: "123 Model Town", city: "Lahore", state: "Punjab", country: "Pakistan", zip: "54000" },
  createdAt: "2026-01-10T09:00:00Z"
};

const INITIAL_CLIENTS = [
  { id: "c_501", name: "Sara Khan", email: "sara@example.com", photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150", status: "active", planType: "fat_loss", adherence: 0.82, joinedAt: "2026-06-01T10:00:00Z", lastActive: "2026-07-21T18:32:00Z" },
  { id: "c_502", name: "Ali Raza", email: "ali@example.com", photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150", status: "active", planType: "weight_gain", adherence: 0.95, joinedAt: "2026-06-05T14:20:00Z", lastActive: "2026-07-22T09:00:00Z" },
  { id: "c_503", name: "Ayesha Noor", email: "ayesha@example.com", photoUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150", status: "active", planType: "custom", adherence: 0.74, joinedAt: "2026-07-21T09:00:00Z", lastActive: "2026-07-23T12:00:00Z" },
  { id: "c_504", name: "Zain Malik", email: "zain@example.com", photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150", status: "at_risk", planType: "fat_loss", adherence: 0.42, joinedAt: "2026-05-15T09:00:00Z", lastActive: "2026-07-18T12:00:00Z" },
  { id: "c_505", name: "Fatima Shah", email: "fatima@example.com", photoUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=150", status: "active", planType: "unassigned", adherence: 0.00, joinedAt: "2026-07-22T10:00:00Z", lastActive: "2026-07-22T10:00:00Z" },
  { id: "c_506", name: "Hamza Tariq", email: "hamza@example.com", photoUrl: "", status: "pending", planType: "unassigned", adherence: 0.00, joinedAt: "2026-07-23T09:00:00Z", lastActive: null }
];

const INITIAL_FOOD_LIBRARY = [
  { id: "food_1", name: "Grilled Chicken Breast", imageUrl: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&q=80&w=150", calories: 165, protein: 31, carbs: 0, fat: 3.6, defaultUnit: "g" },
  { id: "food_2", name: "Brown Rice (Cooked)", imageUrl: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&q=80&w=150", calories: 110, protein: 2.6, carbs: 23, fat: 0.9, defaultUnit: "g" },
  { id: "food_3", name: "Whole Eggs (Boiled)", imageUrl: "https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&q=80&w=150", calories: 155, protein: 13, carbs: 1.1, fat: 11, defaultUnit: "pcs" },
  { id: "food_4", name: "Oatmeal (Raw)", imageUrl: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?auto=format&fit=crop&q=80&w=150", calories: 389, protein: 16.9, carbs: 66, fat: 6.9, defaultUnit: "g" },
  { id: "food_5", name: "Whey Protein Shake", imageUrl: "https://images.unsplash.com/photo-1593095948071-474c5cc2989d?auto=format&fit=crop&q=80&w=150", calories: 120, protein: 24, carbs: 3, fat: 1.5, defaultUnit: "scoop" },
  { id: "food_6", name: "Avocado", imageUrl: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=150", calories: 160, protein: 2, carbs: 9, fat: 15, defaultUnit: "g" },
  { id: "food_7", name: "Salmon Fillet", imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80&w=150", calories: 206, protein: 22, carbs: 0, fat: 13, defaultUnit: "g" },
  { id: "food_8", name: "Sweet Potato (Baked)", imageUrl: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&q=80&w=150", calories: 90, protein: 2, carbs: 21, fat: 0.2, defaultUnit: "g" }
];

const INITIAL_EXERCISE_LIBRARY = [
  { id: "ex_1", name: "Barbell Back Squat", muscleGroup: "legs", equipment: "barbell", videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-man-performing-barbell-squats-in-gym-40545-large.mp4", instructions: "Keep chest up, drive through heels." },
  { id: "ex_2", name: "Dumbbell Bench Press", muscleGroup: "chest", equipment: "dumbbells", videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-man-working-out-with-dumbbells-41618-large.mp4", instructions: "Lower dumbbells to chest level, press up strongly." },
  { id: "ex_3", name: "Lat Pulldown", muscleGroup: "back", equipment: "cable", videoUrl: "", instructions: "Pull bar to upper chest, squeeze shoulder blades." },
  { id: "ex_4", name: "Dumbbell Lateral Raise", muscleGroup: "shoulders", equipment: "dumbbells", videoUrl: "", instructions: "Raise dumbbells to side until arms are parallel to floor." },
  { id: "ex_5", name: "Barbell Bicep Curl", muscleGroup: "arms", equipment: "barbell", videoUrl: "", instructions: "Keep elbows tucked, curl bar up toward shoulders." },
  { id: "ex_6", name: "Tricep Pushdown", muscleGroup: "arms", equipment: "cable", videoUrl: "", instructions: "Extend arms fully downward, flexing triceps." },
  { id: "ex_7", name: "Romanian Deadlift", muscleGroup: "legs", equipment: "barbell", videoUrl: "", instructions: "Hinge at hips, keep back straight, feel stretch in hamstrings." },
  { id: "ex_8", name: "Plank Hold", muscleGroup: "core", equipment: "bodyweight", videoUrl: "", instructions: "Maintain straight line from head to heels, engage core." }
];

const DEFAULT_NUTRITION_PLANS = {
  fat_loss: {
    planId: "default_nut_fatloss",
    type: "fat_loss",
    version: 1,
    days: [
      {
        day: 1,
        meals: {
          breakfast: [
            { id: "ni_default_1", foodId: "food_4", name: "Oatmeal (Raw)", quantity: 60, unit: "g", calories: 233, protein: 10, carbs: 39, fat: 4, orderIndex: 0 },
            { id: "ni_default_2", foodId: "food_3", name: "Whole Eggs (Boiled)", quantity: 2, unit: "pcs", calories: 155, protein: 13, carbs: 1, fat: 11, orderIndex: 1 }
          ],
          lunch: [
            { id: "ni_default_3", foodId: "food_1", name: "Grilled Chicken Breast", quantity: 150, unit: "g", calories: 248, protein: 46, carbs: 0, fat: 5, orderIndex: 0 },
            { id: "ni_default_4", foodId: "food_2", name: "Brown Rice (Cooked)", quantity: 100, unit: "g", calories: 110, protein: 3, carbs: 23, fat: 1, orderIndex: 1 }
          ],
          dinner: [
            { id: "ni_default_5", foodId: "food_7", name: "Salmon Fillet", quantity: 150, unit: "g", calories: 309, protein: 33, carbs: 0, fat: 19, orderIndex: 0 },
            { id: "ni_default_6", foodId: "food_6", name: "Avocado", quantity: 50, unit: "g", calories: 80, protein: 1, carbs: 4, fat: 7, orderIndex: 1 }
          ],
          snacks: [
            { id: "ni_default_7", foodId: "food_5", name: "Whey Protein Shake", quantity: 1, unit: "scoop", calories: 120, protein: 24, carbs: 3, fat: 1, orderIndex: 0 }
          ]
        }
      }
    ],
    totals: { calories: 1255, protein: 130, carbs: 71, fat: 48 }
  },
  weight_gain: {
    planId: "default_nut_weightgain",
    type: "weight_gain",
    version: 1,
    days: [
      {
        day: 1,
        meals: {
          breakfast: [
            { id: "ni_default_wg1", foodId: "food_4", name: "Oatmeal (Raw)", quantity: 100, unit: "g", calories: 389, protein: 17, carbs: 66, fat: 7, orderIndex: 0 },
            { id: "ni_default_wg2", foodId: "food_3", name: "Whole Eggs (Boiled)", quantity: 3, unit: "pcs", calories: 232, protein: 19, carbs: 2, fat: 16, orderIndex: 1 }
          ],
          lunch: [
            { id: "ni_default_wg3", foodId: "food_1", name: "Grilled Chicken Breast", quantity: 200, unit: "g", calories: 330, protein: 62, carbs: 0, fat: 7, orderIndex: 0 },
            { id: "ni_default_wg4", foodId: "food_2", name: "Brown Rice (Cooked)", quantity: 200, unit: "g", calories: 220, protein: 5, carbs: 46, fat: 2, orderIndex: 1 }
          ],
          dinner: [
            { id: "ni_default_wg5", foodId: "food_7", name: "Salmon Fillet", quantity: 200, unit: "g", calories: 412, protein: 44, carbs: 0, fat: 26, orderIndex: 0 },
            { id: "ni_default_wg6", foodId: "food_8", name: "Sweet Potato (Baked)", quantity: 200, unit: "g", calories: 180, protein: 4, carbs: 42, fat: 0, orderIndex: 1 }
          ],
          snacks: [
            { id: "ni_default_wg7", foodId: "food_5", name: "Whey Protein Shake", quantity: 2, unit: "scoop", calories: 240, protein: 48, carbs: 6, fat: 3, orderIndex: 0 }
          ]
        }
      }
    ],
    totals: { calories: 2003, protein: 199, carbs: 162, fat: 61 }
  }
};

const DEFAULT_PROGRAMS = {
  fat_loss: {
    planId: "default_prog_fatloss",
    type: "fat_loss",
    version: 1,
    days: [
      {
        day: 1,
        exercises: [
          { id: "pi_def_1", exerciseId: "ex_1", name: "Barbell Back Squat", sets: 3, reps: 12, weight: 40, restSeconds: 60, orderIndex: 0 },
          { id: "pi_def_2", exerciseId: "ex_2", name: "Dumbbell Bench Press", sets: 3, reps: 12, weight: 15, restSeconds: 60, orderIndex: 1 },
          { id: "pi_def_3", exerciseId: "ex_3", name: "Lat Pulldown", sets: 3, reps: 12, weight: 35, restSeconds: 60, orderIndex: 2 }
        ]
      },
      {
        day: 2,
        exercises: [
          { id: "pi_def_4", exerciseId: "ex_7", name: "Romanian Deadlift", sets: 3, reps: 12, weight: 30, restSeconds: 60, orderIndex: 0 },
          { id: "pi_def_5", exerciseId: "ex_4", name: "Dumbbell Lateral Raise", sets: 3, reps: 15, weight: 5, restSeconds: 45, orderIndex: 1 },
          { id: "pi_def_6", exerciseId: "ex_8", name: "Plank Hold", sets: 3, reps: 60, weight: 0, restSeconds: 45, orderIndex: 2 }
        ]
      }
    ]
  },
  strength: {
    planId: "default_prog_strength",
    type: "strength",
    version: 1,
    days: [
      {
        day: 1,
        exercises: [
          { id: "pi_def_s1", exerciseId: "ex_1", name: "Barbell Back Squat", sets: 5, reps: 5, weight: 70, restSeconds: 120, orderIndex: 0 },
          { id: "pi_def_s2", exerciseId: "ex_2", name: "Dumbbell Bench Press", sets: 5, reps: 5, weight: 25, restSeconds: 120, orderIndex: 1 }
        ]
      },
      {
        day: 2,
        exercises: [
          { id: "pi_def_s3", exerciseId: "ex_7", name: "Romanian Deadlift", sets: 4, reps: 8, weight: 60, restSeconds: 90, orderIndex: 0 },
          { id: "pi_def_s4", exerciseId: "ex_3", name: "Lat Pulldown", sets: 4, reps: 8, weight: 50, restSeconds: 90, orderIndex: 1 }
        ]
      }
    ]
  }
};

const INITIAL_NOTIFICATIONS = [
  { id: "notif_1", type: "missed_workout", title: "Missed workout", body: "Sara Khan missed yesterday's Leg Day workout.", readAt: null, createdAt: "2026-07-22T07:00:00Z" },
  { id: "notif_2", type: "missed_meal", title: "Missed meal plan", body: "Zain Malik did not log breakfast adherence.", readAt: "2026-07-22T19:00:00Z", createdAt: "2026-07-22T09:30:00Z" },
  { id: "notif_3", type: "session_reminder", title: "Upcoming Session", body: "Reminder: 1:1 Strength Session with Ali Raza in 1 hour.", readAt: null, createdAt: "2026-07-23T08:00:00Z" },
  { id: "notif_4", type: "new_message", title: "New Message", body: "Sara Khan sent you a voice note.", readAt: null, createdAt: "2026-07-23T14:41:00Z" }
];

// Helper to initialize local storage
function initDB() {
  if (!localStorage.getItem("clients")) localStorage.setItem("clients", JSON.stringify(INITIAL_CLIENTS));
  if (!localStorage.getItem("foodLibrary")) localStorage.setItem("foodLibrary", JSON.stringify(INITIAL_FOOD_LIBRARY));
  if (!localStorage.getItem("exerciseLibrary")) localStorage.setItem("exerciseLibrary", JSON.stringify(INITIAL_EXERCISE_LIBRARY));
  if (!localStorage.getItem("notifications")) localStorage.setItem("notifications", JSON.stringify(INITIAL_NOTIFICATIONS));
  
  // Scoped client plans
  INITIAL_CLIENTS.forEach(client => {
    const nutKey = `nutrition_plan_${client.id}`;
    const progKey = `workout_plan_${client.id}`;
    
    // Auto-apply default plans if not custom
    if (!localStorage.getItem(nutKey)) {
      if (client.planType === "fat_loss" || client.planType === "weight_gain") {
        const copy = JSON.parse(JSON.stringify(DEFAULT_NUTRITION_PLANS[client.planType]));
        copy.planId = `nut_${client.id}`;
        localStorage.setItem(nutKey, JSON.stringify(copy));
      } else if (client.planType === "custom") {
        localStorage.setItem(nutKey, JSON.stringify({ planId: `nut_${client.id}`, type: "custom", version: 1, days: [], totals: { calories: 0, protein: 0, carbs: 0, fat: 0 } }));
      } else {
        localStorage.setItem(nutKey, JSON.stringify({ planId: `nut_${client.id}`, type: "unassigned", version: 1, days: [], totals: { calories: 0, protein: 0, carbs: 0, fat: 0 } }));
      }
    }
    
    if (!localStorage.getItem(progKey)) {
      if (client.planType === "fat_loss") {
        const copy = JSON.parse(JSON.stringify(DEFAULT_PROGRAMS.fat_loss));
        copy.planId = `prog_${client.id}`;
        localStorage.setItem(progKey, JSON.stringify(copy));
      } else if (client.planType === "weight_gain" || client.planType === "custom") {
        const copy = JSON.parse(JSON.stringify(DEFAULT_PROGRAMS.strength));
        copy.planId = `prog_${client.id}`;
        localStorage.setItem(progKey, JSON.stringify(copy));
      } else {
        localStorage.setItem(progKey, JSON.stringify({ planId: `prog_${client.id}`, type: "unassigned", version: 1, days: [] }));
      }
    }
  });
}

initDB();

// Mock REST endpoints
export const mockApi = {
  // Authentication
  login: async (email, password) => {
    if (email === "bilal@example.com" && password === "Str0ngPass!") {
      const token = "mock_jwt_token_bilal_101";
      localStorage.setItem("authToken", token);
      localStorage.setItem("trainerProfile", JSON.stringify(DEFAULT_TRAINER));
      return { success: true, data: { trainer: DEFAULT_TRAINER, token } };
    }
    return { success: false, error: { code: "INVALID_CREDENTIALS", message: "Email or password is incorrect" } };
  },
  
  forgotPassword: async (email) => {
    return { success: true, data: { message: "If this email exists, a reset link has been sent" } };
  },
  
  resetPassword: async (resetToken, newPassword) => {
    return { success: true, data: { message: "Password has been reset" } };
  },

  getProfile: async () => {
    const prof = localStorage.getItem("trainerProfile") ? JSON.parse(localStorage.getItem("trainerProfile")) : DEFAULT_TRAINER;
    return { success: true, data: prof };
  },

  // Clients
  getClients: async (params = {}) => {
    const clients = JSON.parse(localStorage.getItem("clients"));
    const { search = "", planType = "all", page = 1, limit = 20 } = params;
    
    let filtered = clients;
    
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(c => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q));
    }
    
    if (planType && planType !== "all") {
      filtered = filtered.filter(c => c.planType === planType);
    }
    
    const total = filtered.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const paginated = filtered.slice(start, start + limit);
    
    return {
      success: true,
      data: {
        clients: paginated,
        pagination: { page: Number(page), limit: Number(limit), total, totalPages }
      }
    };
  },

  getClientById: async (clientId) => {
    const clients = JSON.parse(localStorage.getItem("clients"));
    const client = clients.find(c => c.id === clientId);
    if (!client) {
      return { success: false, error: { code: "CLIENT_NOT_FOUND", message: "Client not found" } };
    }
    
    // Attach details
    return {
      success: true,
      data: {
        ...client,
        phone: "+923009876543",
        dob: "1998-03-12",
        address: { line1: "12 Gulberg", city: "Lahore", state: "Punjab", country: "Pakistan", zip: "54660" },
        assignedProgramId: `prog_${client.id}`,
        assignedNutritionPlanId: `nut_${client.id}`,
        stats: { currentWeight: 63.2, startingWeight: 68.5, workoutsCompleted: 40, workoutsMissed: 6 }
      }
    };
  },

  // Nutrition Library
  getNutritionLibrary: async (params = {}) => {
    const foods = JSON.parse(localStorage.getItem("foodLibrary"));
    const { search = "", page = 1, limit = 20 } = params;
    
    let filtered = foods;
    if (search) {
      filtered = filtered.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));
    }
    
    const total = filtered.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    
    return {
      success: true,
      data: {
        foods: filtered.slice(start, start + limit),
        pagination: { page, limit, total, totalPages }
      }
    };
  },

  getNutritionDefaults: async (type = "fat_loss") => {
    const plan = DEFAULT_NUTRITION_PLANS[type] || DEFAULT_NUTRITION_PLANS.fat_loss;
    return { success: true, data: plan };
  },

  // Nutrition Client Plan
  getNutritionClientPlan: async (clientId) => {
    const plan = localStorage.getItem(`nutrition_plan_${clientId}`);
    if (!plan) return { success: false, error: { code: "NOT_FOUND", message: "No nutrition plan for client" } };
    return { success: true, data: JSON.parse(plan) };
  },

  applyDefaultNutrition: async (clientId, type) => {
    const defPlan = DEFAULT_NUTRITION_PLANS[type];
    if (!defPlan) return { success: false, error: { code: "INVALID_TYPE", message: "Plan type not supported" } };
    
    const newPlan = JSON.parse(JSON.stringify(defPlan));
    newPlan.planId = `nut_${clientId}`;
    newPlan.type = "custom";
    newPlan.version = 1;
    
    // Update Client's planType
    const clients = JSON.parse(localStorage.getItem("clients"));
    const idx = clients.findIndex(c => c.id === clientId);
    if (idx !== -1) {
      clients[idx].planType = "custom";
      localStorage.setItem("clients", JSON.stringify(clients));
    }
    
    localStorage.setItem(`nutrition_plan_${clientId}`, JSON.stringify(newPlan));
    return { success: true, data: newPlan };
  },

  customizeNutrition: async (clientId) => {
    const plan = { planId: `nut_${clientId}`, type: "custom", version: 1, days: [{ day: 1, meals: { breakfast: [], lunch: [], dinner: [], snacks: [] } }], totals: { calories: 0, protein: 0, carbs: 0, fat: 0 } };
    
    const clients = JSON.parse(localStorage.getItem("clients"));
    const idx = clients.findIndex(c => c.id === clientId);
    if (idx !== -1) {
      clients[idx].planType = "custom";
      localStorage.setItem("clients", JSON.stringify(clients));
    }
    
    localStorage.setItem(`nutrition_plan_${clientId}`, JSON.stringify(plan));
    return { success: true, data: plan };
  },

  updateNutritionPlan: async (clientId, payload) => {
    const key = `nutrition_plan_${clientId}`;
    const planRaw = localStorage.getItem(key);
    if (!planRaw) return { success: false, error: { code: "NOT_FOUND", message: "Plan not found" } };
    
    const plan = JSON.parse(planRaw);
    
    // Optimistic Concurrency Check
    if (payload.version !== plan.version) {
      return {
        success: false,
        status: 409,
        error: {
          code: "VERSION_CONFLICT",
          message: "This plan was updated elsewhere, please refresh",
          currentPlan: plan
        }
      };
    }
    
    // Save new days layout
    plan.days = payload.days;
    plan.version += 1;
    
    // Authoritative Server-side recalculation of totals
    let cal = 0, prot = 0, carb = 0, fat = 0;
    plan.days.forEach(day => {
      Object.keys(day.meals).forEach(slot => {
        day.meals[slot].forEach(item => {
          cal += Number(item.calories || 0);
          prot += Number(item.protein || 0);
          carb += Number(item.carbs || 0);
          fat += Number(item.fat || 0);
        });
      });
    });
    
    plan.totals = { calories: Math.round(cal), protein: Math.round(prot), carbs: Math.round(carb), fat: Math.round(fat) };
    
    localStorage.setItem(key, JSON.stringify(plan));
    return { success: true, data: plan };
  },

  addNutritionItem: async (clientId, payload) => {
    const { day, mealSlot, foodId, quantity, unit, customItem } = payload;
    const key = `nutrition_plan_${clientId}`;
    const planRaw = localStorage.getItem(key);
    if (!planRaw) return { success: false, error: { code: "NOT_FOUND", message: "Plan not found" } };
    
    const plan = JSON.parse(planRaw);
    
    // Find food template
    let food;
    if (customItem) {
      food = customItem; // custom fields directly submitted
    } else {
      const foodLibrary = JSON.parse(localStorage.getItem("foodLibrary"));
      food = foodLibrary.find(f => f.id === foodId);
    }
    
    if (!food) return { success: false, error: { code: "FOOD_NOT_FOUND", message: "Food template not found" } };
    
    // Recalculate macro values based on quantity if it's a library food
    let scalar = 1;
    if (!customItem && food.defaultUnit === "g") {
      scalar = quantity / 100; // calories per 100g in database
    }
    
    const calories = Math.round((customItem ? food.calories : food.calories * scalar));
    const protein = Math.round((customItem ? food.protein : food.protein * scalar));
    const carbs = Math.round((customItem ? food.carbs : food.carbs * scalar));
    const fat = Math.round((customItem ? food.fat : food.fat * scalar));
    
    const newItem = {
      id: `ni_${Date.now()}`,
      foodId: customItem ? null : foodId,
      name: food.name,
      imageUrl: food.imageUrl || "https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=150",
      quantity,
      unit: unit || food.defaultUnit || "g",
      calories,
      protein,
      carbs,
      fat,
      orderIndex: 0
    };
    
    // Add to plan
    let dayObj = plan.days.find(d => d.day === day);
    if (!dayObj) {
      dayObj = { day, meals: { breakfast: [], lunch: [], dinner: [], snacks: [] } };
      plan.days.push(dayObj);
    }
    
    if (!dayObj.meals[mealSlot]) dayObj.meals[mealSlot] = [];
    newItem.orderIndex = dayObj.meals[mealSlot].length;
    dayObj.meals[mealSlot].push(newItem);
    
    // Increment version
    plan.version += 1;
    
    // Recalculate plan totals
    let totalCal = 0, totalProt = 0, totalCarb = 0, totalFat = 0;
    plan.days.forEach(d => {
      Object.keys(d.meals).forEach(slot => {
        d.meals[slot].forEach(item => {
          totalCal += item.calories;
          totalProt += item.protein;
          totalCarb += item.carbs;
          totalFat += item.fat;
        });
      });
    });
    plan.totals = { calories: Math.round(totalCal), protein: Math.round(totalProt), carbs: Math.round(totalCarb), fat: Math.round(totalFat) };
    
    localStorage.setItem(key, JSON.stringify(plan));
    return { success: true, data: newItem };
  },

  // Exercise Library
  getExercises: async (params = {}) => {
    const exercises = JSON.parse(localStorage.getItem("exerciseLibrary"));
    const { search = "", muscleGroup = "", page = 1, limit = 20 } = params;
    
    let filtered = exercises;
    if (search) {
      filtered = filtered.filter(e => e.name.toLowerCase().includes(search.toLowerCase()));
    }
    if (muscleGroup) {
      filtered = filtered.filter(e => e.muscleGroup === muscleGroup);
    }
    
    const total = filtered.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    
    return {
      success: true,
      data: {
        exercises: filtered.slice(start, start + limit),
        pagination: { page, limit, total, totalPages }
      }
    };
  },

  addExerciseToLibrary: async (payload) => {
    const lib = JSON.parse(localStorage.getItem("exerciseLibrary"));
    const newEx = {
      id: `ex_${Date.now()}`,
      name: payload.name,
      muscleGroup: payload.muscleGroup,
      equipment: payload.equipment || "none",
      videoUrl: payload.videoUrl || "",
      instructions: payload.instructions || ""
    };
    lib.push(newEx);
    localStorage.setItem("exerciseLibrary", JSON.stringify(lib));
    return { success: true, data: newEx };
  },

  // Program / Workout Plan endpoints
  getProgramDefaults: async (type = "fat_loss") => {
    return { success: true, data: DEFAULT_PROGRAMS[type] || DEFAULT_PROGRAMS.fat_loss };
  },

  getWorkoutClientPlan: async (clientId) => {
    const plan = localStorage.getItem(`workout_plan_${clientId}`);
    if (!plan) return { success: false, error: { code: "NOT_FOUND", message: "Plan not found" } };
    return { success: true, data: JSON.parse(plan) };
  },

  applyDefaultWorkout: async (clientId, type) => {
    const defPlan = DEFAULT_PROGRAMS[type];
    if (!defPlan) return { success: false, error: { code: "INVALID_TYPE", message: "Program type not supported" } };
    
    const newPlan = JSON.parse(JSON.stringify(defPlan));
    newPlan.planId = `prog_${clientId}`;
    newPlan.type = "custom";
    newPlan.version = 1;
    
    // Update Client's planType
    const clients = JSON.parse(localStorage.getItem("clients"));
    const idx = clients.findIndex(c => c.id === clientId);
    if (idx !== -1) {
      clients[idx].planType = "custom";
      localStorage.setItem("clients", JSON.stringify(clients));
    }
    
    localStorage.setItem(`workout_plan_${clientId}`, JSON.stringify(newPlan));
    return { success: true, data: newPlan };
  },

  customizeWorkout: async (clientId) => {
    const plan = { planId: `prog_${clientId}`, type: "custom", version: 1, days: [{ day: 1, exercises: [] }] };
    
    const clients = JSON.parse(localStorage.getItem("clients"));
    const idx = clients.findIndex(c => c.id === clientId);
    if (idx !== -1) {
      clients[idx].planType = "custom";
      localStorage.setItem("clients", JSON.stringify(clients));
    }
    
    localStorage.setItem(`workout_plan_${clientId}`, JSON.stringify(plan));
    return { success: true, data: plan };
  },

  updateWorkoutPlan: async (clientId, payload) => {
    const key = `workout_plan_${clientId}`;
    const planRaw = localStorage.getItem(key);
    if (!planRaw) return { success: false, error: { code: "NOT_FOUND", message: "Plan not found" } };
    
    const plan = JSON.parse(planRaw);
    
    // Optimistic Concurrency Check
    if (payload.version !== plan.version) {
      return {
        success: false,
        status: 409,
        error: {
          code: "VERSION_CONFLICT",
          message: "This plan was updated elsewhere, please refresh",
          currentPlan: plan
        }
      };
    }
    
    plan.days = payload.days;
    plan.version += 1;
    
    localStorage.setItem(key, JSON.stringify(plan));
    return { success: true, data: plan };
  },

  addWorkoutExercise: async (clientId, payload) => {
    const { day, exerciseId, sets, reps, weight, restSeconds, customItem } = payload;
    const key = `workout_plan_${clientId}`;
    const planRaw = localStorage.getItem(key);
    if (!planRaw) return { success: false, error: { code: "NOT_FOUND", message: "Plan not found" } };
    
    const plan = JSON.parse(planRaw);
    
    let exercise;
    if (customItem) {
      exercise = customItem;
    } else {
      const lib = JSON.parse(localStorage.getItem("exerciseLibrary"));
      exercise = lib.find(e => e.id === exerciseId);
    }
    
    if (!exercise) return { success: false, error: { code: "EXERCISE_NOT_FOUND", message: "Exercise not found" } };
    
    const newItem = {
      id: `pi_${Date.now()}`,
      exerciseId: customItem ? null : exerciseId,
      name: exercise.name,
      videoUrl: exercise.videoUrl || "",
      sets,
      reps,
      weight,
      restSeconds,
      orderIndex: 0
    };
    
    let dayObj = plan.days.find(d => d.day === day);
    if (!dayObj) {
      dayObj = { day, exercises: [] };
      plan.days.push(dayObj);
    }
    
    newItem.orderIndex = dayObj.exercises.length;
    dayObj.exercises.push(newItem);
    
    plan.version += 1;
    localStorage.setItem(key, JSON.stringify(plan));
    
    return { success: true, data: newItem };
  },

  // Notifications
  getNotifications: async (params = {}) => {
    const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
    const { page = 1, limit = 5 } = params;
    
    // Sort descending by creation date
    const sorted = [...notifs].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const total = sorted.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    
    return {
      success: true,
      data: {
        notifications: sorted.slice(start, start + limit),
        pagination: { page: Number(page), limit: Number(limit), total, totalPages }
      }
    };
  },

  sendCustomNotification: async (payload) => {
    const { recipientIds, title, body } = payload;
    
    if (!recipientIds || recipientIds.length === 0 || recipientIds === "") {
      return {
        success: false,
        status: 422,
        error: { code: "EMPTY_RECIPIENT_LIST", message: "Select at least one recipient" }
      };
    }
    
    const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
    const newNotif = {
      id: `notif_${Date.now()}`,
      type: "custom_alert",
      title,
      body,
      readAt: null,
      createdAt: new Date().toISOString()
    };
    
    notifs.push(newNotif);
    localStorage.setItem("notifications", JSON.stringify(notifs));
    
    const count = recipientIds === "all" ? JSON.parse(localStorage.getItem("clients")).length : recipientIds.length;
    return { success: true, data: { message: "Notification sent", sentCount: count } };
  },

  markNotificationRead: async (id) => {
    const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
    const idx = notifs.findIndex(n => n.id === id);
    if (idx !== -1) {
      notifs[idx].readAt = new Date().toISOString();
      localStorage.setItem("notifications", JSON.stringify(notifs));
    }
    return { success: true, data: { message: "Marked as read" } };
  },

  markAllNotificationsRead: async () => {
    const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
    let count = 0;
    notifs.forEach(n => {
      if (!n.readAt) {
        n.readAt = new Date().toISOString();
        count++;
      }
    });
    localStorage.setItem("notifications", JSON.stringify(notifs));
    return { success: true, data: { message: "All notifications marked as read", updatedCount: count } };
  }
};
