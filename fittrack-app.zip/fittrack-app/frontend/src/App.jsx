// App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';

// Pages
import Login from './pages/Login';
import Clients from './pages/Clients';
import MealPlan from './pages/MealPlan';
import MealAssign from './pages/MealAssign';
import WorkoutPlan from './pages/WorkoutPlan';
import WorkoutAssign from './pages/WorkoutAssign';
import Chat from './pages/Chat';
import Notifications from './pages/Notifications';
import Analytics from './pages/Analytics';
import Profile from './pages/Profile';
import GroupLink from './pages/GroupLink';

// Route Guard Component
const ProtectedRoute = ({ children }) => {
  const { token, loading } = useAuth();
  
  if (loading) {
    return (
      <div style={{
        display: 'flex',
        minHeight: '100vh',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '1.25rem',
        fontFamily: 'var(--font-heading)',
        color: 'var(--text-dim)'
      }}>
        LOADING PORTAL SESSION...
      </div>
    );
  }
  
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  
  return <Layout>{children}</Layout>;
};

function AppRoutes() {
  const { token } = useAuth();
  
  return (
    <Routes>
      {/* Public Login Route */}
      <Route 
        path="/login" 
        element={token ? <Navigate to="/clients" replace /> : <Login />} 
      />

      {/* Protected Trainer Routes */}
      <Route path="/clients" element={<ProtectedRoute><Clients /></ProtectedRoute>} />
      <Route path="/nutrition" element={<ProtectedRoute><MealPlan /></ProtectedRoute>} />
      <Route path="/nutrition/assign/:clientId" element={<ProtectedRoute><MealAssign /></ProtectedRoute>} />
      
      <Route path="/workouts" element={<ProtectedRoute><WorkoutPlan /></ProtectedRoute>} />
      <Route path="/workouts/assign/:clientId" element={<ProtectedRoute><WorkoutAssign /></ProtectedRoute>} />
      
      <Route path="/chat" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
      <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
      <Route path="/group-link" element={<ProtectedRoute><GroupLink /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

      {/* Fallback redirect */}
      <Route path="*" element={<Navigate to="/clients" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
}
