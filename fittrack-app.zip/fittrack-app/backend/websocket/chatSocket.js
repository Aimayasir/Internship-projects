const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/authMiddleware');
const db = require('../config/db');

const clientsMap = new Map(); // userId -> { socket, role, lastDisconnectTimer }

function setupWebSocket(server) {
  const wss = new WebSocket.Server({ server, path: '/chat' });

  wss.on('connection', async (ws, req) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const token = url.searchParams.get('token');

      if (!token) {
        ws.close(4001, 'Unauthorized: Missing token');
        return;
      }

      const decoded = jwt.verify(token, JWT_SECRET);
      const userId = decoded.id;
      const role = decoded.role;

      // Cancel disconnect timer if reconnecting within grace period
      if (clientsMap.has(userId) && clientsMap.get(userId).lastDisconnectTimer) {
        clearTimeout(clientsMap.get(userId).lastDisconnectTimer);
      }

      clientsMap.set(userId, { socket: ws, role });

      // Broadcast presence online
      broadcastPresence(userId, true);

      ws.on('message', async (data) => {
        try {
          const messageObj = JSON.parse(data.toString());
          const { threadId, type, content, mediaUrl, duration, tempId } = messageObj;

          if (messageObj.type === 'typing:start' || messageObj.action === 'typing:start') {
            // Typing indicator
            const targetClient = clientsMap.get(threadId);
            if (targetClient && targetClient.socket.readyState === WebSocket.OPEN) {
              targetClient.socket.send(JSON.stringify({
                event: 'typing:update',
                threadId: userId,
                userId,
                isTyping: true,
              }));
            }
            return;
          }

          if (messageObj.type === 'message:read' || messageObj.action === 'message:read') {
            // Mark read status
            const msgId = messageObj.messageId;
            await db.query("UPDATE chat_messages SET status = 'read' WHERE id = $1", [msgId]);
            const targetClient = clientsMap.get(threadId);
            if (targetClient && targetClient.socket.readyState === WebSocket.OPEN) {
              targetClient.socket.send(JSON.stringify({
                event: 'message:status',
                messageId: msgId,
                status: 'read',
              }));
            }
            return;
          }

          // Save message to DB
          const msgId = `msg_${Date.now()}`;
          await db.query(
            `INSERT INTO chat_messages (id, thread_id, sender_id, sender_role, type, content, media_url, duration, status, temp_id)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
            [msgId, threadId, userId, role, type || 'text', content || null, mediaUrl || null, duration || null, 'sent', tempId || null]
          );

          // Update thread last message
          if (role === 'trainer') {
            await db.query(
              'UPDATE chat_threads SET last_message = $1, unread_count_client = unread_count_client + 1, updated_at = NOW() WHERE id = $2',
              [content || 'Media message', threadId]
            );
          } else {
            await db.query(
              'UPDATE chat_threads SET last_message = $1, unread_count_trainer = unread_count_trainer + 1, updated_at = NOW() WHERE id = $2',
              [content || 'Media message', threadId]
            );
          }

          const responsePayload = {
            event: 'message:new',
            id: msgId,
            threadId,
            senderRole: role,
            type: type || 'text',
            content: content || null,
            mediaUrl: mediaUrl || null,
            duration: duration || null,
            status: 'sent',
            createdAt: new Date().toISOString(),
            tempId,
          };

          // Send back to sender for confirmation
          ws.send(JSON.stringify(responsePayload));

          // Deliver live to recipient if connected
          const recipientSocket = clientsMap.get(threadId);
          if (recipientSocket && recipientSocket.socket.readyState === WebSocket.OPEN) {
            recipientSocket.socket.send(JSON.stringify(responsePayload));
          }
        } catch (err) {
          console.error('WebSocket Message error:', err);
        }
      });

      ws.on('close', () => {
        // Presence Flicker Protection: Wait 30 seconds before marking offline
        const clientEntry = clientsMap.get(userId);
        if (clientEntry) {
          clientEntry.lastDisconnectTimer = setTimeout(() => {
            clientsMap.delete(userId);
            broadcastPresence(userId, false);
          }, 30000);
        }
      });

    } catch (err) {
      ws.close(4002, 'Authentication Error');
    }
  });

  function broadcastPresence(userId, online) {
    const payload = JSON.stringify({
      event: 'presence:update',
      userId,
      online,
      lastSeen: new Date().toISOString(),
    });

    for (const [id, client] of clientsMap.entries()) {
      if (client.socket.readyState === WebSocket.OPEN) {
        client.socket.send(payload);
      }
    }
  }
}

module.exports = { setupWebSocket };
