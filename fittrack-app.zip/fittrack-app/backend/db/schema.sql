-- FitTrack PostgreSQL Database Schema DDL & Starter Seeds

CREATE TABLE IF NOT EXISTS trainers (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(64),
    photo_url TEXT DEFAULT 'https://cdn.fittrack.app/defaults/trainer-avatar.png',
    bio TEXT,
    specialty_tags JSONB DEFAULT '[]'::jsonb,
    address JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(32) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clients (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(64),
    photo_url TEXT DEFAULT 'https://cdn.fittrack.app/defaults/client-avatar.png',
    dob DATE,
    address JSONB DEFAULT '{}'::jsonb,
    starting_weight NUMERIC(5,2),
    height NUMERIC(5,2),
    status VARCHAR(32) DEFAULT 'active',
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE SET NULL,
    assigned_program_id VARCHAR(64),
    assigned_nutrition_plan_id VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS super_admins (
    id VARCHAR(64) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS invite_codes (
    id SERIAL PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    code VARCHAR(64) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS invite_logs (
    id SERIAL PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS exercises (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    muscle_group VARCHAR(64) NOT NULL,
    equipment VARCHAR(64),
    video_url TEXT,
    instructions TEXT,
    is_global BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS workout_plans (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    type VARCHAR(32) DEFAULT 'custom',
    version INT DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS workout_plan_days (
    id VARCHAR(64) PRIMARY KEY,
    plan_id VARCHAR(64) REFERENCES workout_plans(id) ON DELETE CASCADE,
    day_number INT NOT NULL
);

CREATE TABLE IF NOT EXISTS workout_plan_items (
    id VARCHAR(64) PRIMARY KEY,
    day_id VARCHAR(64) REFERENCES workout_plan_days(id) ON DELETE CASCADE,
    exercise_id VARCHAR(64) REFERENCES exercises(id) ON DELETE RESTRICT,
    sets INT DEFAULT 3,
    reps INT DEFAULT 10,
    weight NUMERIC(6,2) DEFAULT 0,
    rest_seconds INT DEFAULT 60,
    order_index INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS workout_logs (
    id VARCHAR(64) PRIMARY KEY,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    plan_item_id VARCHAR(64) REFERENCES workout_plan_items(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    workout_completed BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS workout_set_logs (
    id SERIAL PRIMARY KEY,
    log_id VARCHAR(64) REFERENCES workout_logs(id) ON DELETE CASCADE,
    set_number INT NOT NULL,
    reps INT NOT NULL,
    weight NUMERIC(6,2) DEFAULT 0,
    completed BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS food_library (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    image_url TEXT,
    calories NUMERIC(6,2) NOT NULL,
    protein NUMERIC(6,2) NOT NULL,
    carbs NUMERIC(6,2) NOT NULL,
    fat NUMERIC(6,2) NOT NULL,
    default_unit VARCHAR(32) DEFAULT 'g'
);

CREATE TABLE IF NOT EXISTS nutrition_plans (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    type VARCHAR(32) DEFAULT 'custom',
    version INT DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nutrition_plan_items (
    id VARCHAR(64) PRIMARY KEY,
    plan_id VARCHAR(64) REFERENCES nutrition_plans(id) ON DELETE CASCADE,
    day_number INT NOT NULL,
    meal_slot VARCHAR(32) NOT NULL,
    food_id VARCHAR(64) REFERENCES food_library(id) ON DELETE RESTRICT,
    name VARCHAR(255),
    image_url TEXT,
    quantity NUMERIC(6,2) NOT NULL,
    unit VARCHAR(32) DEFAULT 'g',
    calories NUMERIC(6,2) NOT NULL,
    protein NUMERIC(6,2) NOT NULL,
    carbs NUMERIC(6,2) NOT NULL,
    fat NUMERIC(6,2) NOT NULL,
    order_index INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS schedule_events (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    type VARCHAR(32) NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS event_clients (
    event_id VARCHAR(64) REFERENCES schedule_events(id) ON DELETE CASCADE,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    PRIMARY KEY (event_id, client_id)
);

CREATE TABLE IF NOT EXISTS progress_entries (
    id VARCHAR(64) PRIMARY KEY,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    weight NUMERIC(5,2),
    measurements JSONB DEFAULT '{}'::jsonb,
    photo_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_threads (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    client_id VARCHAR(64) REFERENCES clients(id) ON DELETE CASCADE,
    last_message TEXT,
    unread_count_trainer INT DEFAULT 0,
    unread_count_client INT DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id VARCHAR(64) PRIMARY KEY,
    thread_id VARCHAR(64) REFERENCES chat_threads(id) ON DELETE CASCADE,
    sender_id VARCHAR(64) NOT NULL,
    sender_role VARCHAR(32) NOT NULL,
    type VARCHAR(32) NOT NULL,
    content TEXT,
    media_url TEXT,
    duration INT,
    status VARCHAR(32) DEFAULT 'sent',
    temp_id VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS broadcasts (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) REFERENCES trainers(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    allow_replies BOOLEAN DEFAULT TRUE,
    recipient_ids JSONB DEFAULT '"all"'::jsonb,
    delivered_count INT DEFAULT 0,
    read_count INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    user_role VARCHAR(32) NOT NULL,
    type VARCHAR(64) NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    read_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS trainer_notification_settings (
    trainer_id VARCHAR(64) PRIMARY KEY REFERENCES trainers(id) ON DELETE CASCADE,
    new_client_joined BOOLEAN DEFAULT TRUE,
    new_message BOOLEAN DEFAULT TRUE,
    missed_workout_alert BOOLEAN DEFAULT TRUE,
    missed_meal_alert BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS client_notification_settings (
    client_id VARCHAR(64) PRIMARY KEY REFERENCES clients(id) ON DELETE CASCADE,
    workout_reminders BOOLEAN DEFAULT TRUE,
    session_reminders BOOLEAN DEFAULT TRUE,
    messages BOOLEAN DEFAULT TRUE,
    meal_reminders BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS user_push_tokens (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    user_role VARCHAR(32) NOT NULL,
    token TEXT NOT NULL,
    platform VARCHAR(32) DEFAULT 'android',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ====================================================================
-- STARTER SEED DATA (Base Global Exercise & Food Catalog)
-- ====================================================================

INSERT INTO exercises (id, name, muscle_group, equipment, video_url, instructions, is_global) VALUES
('ex_12', 'Barbell Back Squat', 'legs', 'barbell', 'https://cdn.fittrack.app/exercises/ex_12.mp4', 'Keep chest up, drive through heels.', true),
('ex_20', 'Dumbbell Bicep Curl', 'arms', 'dumbbell', 'https://cdn.fittrack.app/exercises/ex_20.mp4', 'Keep elbows tight, squeeze at top.', true),
('ex_1', 'Barbell Bench Press', 'chest', 'barbell', 'https://cdn.fittrack.app/exercises/ex_1.mp4', 'Lower bar to chest level, press up.', true),
('ex_2', 'Conventional Deadlift', 'back', 'barbell', 'https://cdn.fittrack.app/exercises/ex_2.mp4', 'Hinge at hips, pull bar along shins.', true),
('ex_3', 'Lat Pulldown', 'back', 'cable', 'https://cdn.fittrack.app/exercises/ex_3.mp4', 'Pull bar to upper chest, squeeze lats.', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO food_library (id, name, image_url, calories, protein, carbs, fat, default_unit) VALUES
('food_5', 'Grilled Chicken Breast', 'https://cdn.fittrack.app/foods/food_5.jpg', 165, 31, 0, 3.6, 'g'),
('food_9', 'Brown Rice', 'https://cdn.fittrack.app/foods/food_9.jpg', 220, 5, 46, 1.8, 'g'),
('food_1', 'Oatmeal', 'https://cdn.fittrack.app/foods/food_1.jpg', 150, 5, 27, 2.5, 'g'),
('food_2', 'Whole Eggs', 'https://cdn.fittrack.app/foods/food_2.jpg', 140, 12, 1, 10, 'g')
ON CONFLICT (id) DO NOTHING;
