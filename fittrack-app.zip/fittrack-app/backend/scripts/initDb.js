const { Client } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const config = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
};

async function initDatabase() {
  const dbName = process.env.DB_NAME || 'fittrack_db';
  console.log(`🔍 Connecting to PostgreSQL Server at ${config.host}:${config.port} as user '${config.user}'...`);

  // Connect to default 'postgres' database
  const client = new Client({ ...config, database: 'postgres' });
  try {
    await client.connect();
    console.log(`✅ Connected to PostgreSQL Server!`);

    const res = await client.query(`SELECT 1 FROM pg_database WHERE datname = $1`, [dbName]);
    if (res.rows.length === 0) {
      console.log(`⚙️ Creating database '${dbName}'...`);
      await client.query(`CREATE DATABASE "${dbName}"`);
      console.log(`✅ Database '${dbName}' created successfully.`);
    } else {
      console.log(`✅ Database '${dbName}' already exists.`);
    }
  } catch (err) {
    console.error('❌ Could not connect to PostgreSQL Server:');
    console.error(`   Message: ${err.message}`);
    console.error('💡 Ensure PostgreSQL service is running and DB_PASSWORD in .env is correct.');
    await client.end();
    process.exit(1);
  }
  await client.end();

  // Connect to fittrack_db and execute schema.sql
  console.log(`📦 Executing PostgreSQL schema.sql on database '${dbName}'...`);
  const dbClient = new Client({ ...config, database: dbName });
  try {
    await dbClient.connect();
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const sql = fs.readFileSync(schemaPath, 'utf8');
    await dbClient.query(sql);
    console.log('🎉 All 14 PostgreSQL database tables created successfully!');
  } catch (err) {
    console.error('❌ Error executing schema.sql:', err.message);
    process.exit(1);
  } finally {
    await dbClient.end();
  }
}

initDatabase();
