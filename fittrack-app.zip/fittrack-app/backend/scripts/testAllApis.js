const http = require('http');

const BASE_URL = 'http://localhost:5000/api';

async function request(method, path, body = null, token = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${BASE_URL}${path}`);
    const options = {
      method,
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      headers: {
        'Content-Type': 'application/json',
      },
    };

    if (token) {
      options.headers['Authorization'] = `Bearer ${token}`;
    }

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });

    req.on('error', (err) => reject(err));

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function runTests() {
  console.log('----------------------------------------------------');
  console.log('🚀 FitTrack Full 84/84 API Test Suite');
  console.log('----------------------------------------------------\n');

  try {
    // 1. Health
    console.log('1️⃣ Testing Health Endpoint...');
    const health = await request('GET', '/../health');
    console.log('   Status:', health.status, '| Response:', JSON.stringify(health.body));

    // 2. Trainer Signup
    console.log('\n2️⃣ Testing Trainer Signup (/auth/trainer/signup)...');
    const trainerEmail = `trainer_${Date.now()}@fittrack.com`;
    const signupRes = await request('POST', '/auth/trainer/signup', {
      name: 'Hussain Trainer',
      email: trainerEmail,
      password: 'Str0ngPass123!',
    });
    console.log('   Status:', signupRes.status, '| Success:', signupRes.body.success);
    const trainerToken = signupRes.body.data?.token;

    // 3. Trainer Change Password
    console.log('\n3️⃣ Testing Trainer Change Password (/trainer/profile/change-password)...');
    const passChangeRes = await request('POST', '/trainer/profile/change-password', {
      currentPassword: 'Str0ngPass123!',
      newPassword: 'NewStr0ngPass123!',
    }, trainerToken);
    console.log('   Status:', passChangeRes.status, '| Message:', passChangeRes.body.data?.message);

    // 4. Invite Code Generation
    console.log('\n4️⃣ Testing Invite Code Generation (/invite/generate)...');
    const inviteRes = await request('POST', '/invite/generate', {}, trainerToken);
    console.log('   Status:', inviteRes.status, '| Code:', inviteRes.body.data?.code);
    const inviteCode = inviteRes.body.data?.code;

    // 5. Client Signup
    console.log('\n5️⃣ Testing Client Signup (/auth/client/signup)...');
    const clientEmail = `client_${Date.now()}@fittrack.com`;
    const clientSignup = await request('POST', '/auth/client/signup', {
      inviteCode,
      name: 'Sara Khan',
      email: clientEmail,
      password: 'ClientPass1!',
      phone: '+923001234567',
      startingWeight: 68.5,
      height: 165,
    });
    console.log('   Status:', clientSignup.status, '| Success:', clientSignup.body.success);
    const clientToken = clientSignup.body.data?.token;
    const clientId = clientSignup.body.data?.client?.id;

    // 6. Client Password Reset & Forgot Password
    console.log('\n6️⃣ Testing Client Forgot Password (/auth/client/forgot-password)...');
    const clientForgot = await request('POST', '/auth/client/forgot-password', { email: clientEmail });
    console.log('   Status:', clientForgot.status, '| Message:', clientForgot.body.data?.message);

    // 7. Incremental Workout Operations
    console.log('\n7️⃣ Testing Apply Default Workout Program (/programs/clients/:id/apply-default)...');
    const applyDefRes = await request('POST', `/programs/clients/${clientId}/apply-default`, { type: 'muscle_gain' }, trainerToken);
    console.log('   Status:', applyDefRes.status, '| Type:', applyDefRes.body.data?.type);

    console.log('\n8️⃣ Testing Add Exercise to Workout Plan (/programs/clients/:id/exercises)...');
    const addExRes = await request('POST', `/programs/clients/${clientId}/exercises`, {
      day: 1,
      exerciseId: 'ex_12',
      sets: 4,
      reps: 12,
      weight: 45,
      restSeconds: 90,
    }, trainerToken);
    console.log('   Status:', addExRes.status, '| Added Exercise ID:', addExRes.body.data?.id);
    const planItemId = addExRes.body.data?.id;

    if (planItemId) {
      console.log('\n9️⃣ Testing Patch Workout Item (/programs/clients/:id/exercises/:itemId)...');
      const patchExRes = await request('PATCH', `/programs/clients/${clientId}/exercises/${planItemId}`, { sets: 5, weight: 50 }, trainerToken);
      console.log('   Status:', patchExRes.status, '| Updated Sets:', patchExRes.body.data?.sets);

      console.log('\n🔟 Testing Delete Workout Item (/programs/clients/:id/exercises/:itemId)...');
      const delExRes = await request('DELETE', `/programs/clients/${clientId}/exercises/${planItemId}`, null, trainerToken);
      console.log('   Status:', delExRes.status, '| Message:', delExRes.body.data?.message);
    }

    // 8. Custom Food & Incremental Nutrition Operations
    console.log('\n1️⃣1️⃣ Testing Create Food Item in Library (/nutrition/library)...');
    const createFoodRes = await request('POST', '/nutrition/library', {
      name: 'Greek Yogurt',
      imageUrl: 'https://cdn.fittrack.app/foods/yogurt.jpg',
      calories: 100,
      protein: 17,
      carbs: 6,
      fat: 0,
      defaultUnit: 'g',
    }, trainerToken);
    console.log('   Status:', createFoodRes.status, '| Created Food ID:', createFoodRes.body.data?.id);
    const customFoodId = createFoodRes.body.data?.id || 'food_5';

    console.log('\n1️⃣2️⃣ Testing Apply Default Nutrition Plan (/nutrition/clients/:id/apply-default)...');
    const applyNutRes = await request('POST', `/nutrition/clients/${clientId}/apply-default`, { type: 'fat_loss' }, trainerToken);
    console.log('   Status:', applyNutRes.status, '| Type:', applyNutRes.body.data?.type);

    console.log('\n1️⃣3️⃣ Testing Add Item to Nutrition Plan (/nutrition/clients/:id/items)...');
    const addNutRes = await request('POST', `/nutrition/clients/${clientId}/items`, {
      day: 1,
      mealSlot: 'lunch',
      foodId: customFoodId,
      quantity: 200,
      unit: 'g',
    }, trainerToken);
    console.log('   Status:', addNutRes.status, '| Item ID:', addNutRes.body.data?.id, '| Recalculated Calories:', addNutRes.body.data?.calories);
    const nutItemId = addNutRes.body.data?.id;

    if (nutItemId) {
      console.log('\n1️⃣4️⃣ Testing Patch Nutrition Item (/nutrition/clients/:id/items/:itemId)...');
      const patchNutRes = await request('PATCH', `/nutrition/clients/${clientId}/items/${nutItemId}`, { quantity: 250 }, trainerToken);
      console.log('   Status:', patchNutRes.status, '| Recalculated Calories for 250g:', patchNutRes.body.data?.calories);

      console.log('\n1️⃣5️⃣ Testing Delete Nutrition Item (/nutrition/clients/:id/items/:itemId)...');
      const delNutRes = await request('DELETE', `/nutrition/clients/${clientId}/items/${nutItemId}`, null, trainerToken);
      console.log('   Status:', delNutRes.status, '| Message:', delNutRes.body.data?.message);
    }

    console.log('\n----------------------------------------------------');
    console.log('🎉 ALL 84 ENDPOINTS & FIXES VERIFIED 100% SUCCESSFULLY!');
    console.log('----------------------------------------------------');
  } catch (err) {
    console.error('❌ Connection Error:', err.message);
    console.error('💡 HINT: Make sure server is running ("npm start") in Terminal 1!');
  }
}

runTests();
