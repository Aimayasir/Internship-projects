const jwt = require('jsonwebtoken');
const db = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'fittrack_super_secret_jwt_key_2026';

// Middleware to verify JWT token and attach user to req
const authenticateToken = (allowedRoles = []) => {
  return async (req, res, next) => {
    try {
      const authHeader = req.headers['authorization'];
      const token = authHeader && authHeader.split(' ')[1];

      if (!token) {
        return res.status(401).json({
          success: false,
          data: null,
          error: { code: 'UNAUTHORIZED', message: 'Missing or invalid token' },
        });
      }

      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;

      // Role check
      if (allowedRoles.length > 0 && !allowedRoles.includes(decoded.role)) {
        return res.status(403).json({
          success: false,
          data: null,
          error: { code: 'FORBIDDEN', message: 'You do not have access to this resource' },
        });
      }

      // Check if account is suspended/disabled
      if (decoded.role === 'trainer') {
        const trainerResult = await db.query('SELECT status FROM trainers WHERE id = $1', [decoded.id]);
        if (trainerResult.rows.length === 0 || trainerResult.rows[0].status === 'suspended') {
          return res.status(403).json({
            success: false,
            data: null,
            error: { code: 'ACCOUNT_SUSPENDED', message: 'Your account has been suspended by the platform admin' },
          });
        }
      } else if (decoded.role === 'client') {
        const clientResult = await db.query('SELECT status FROM clients WHERE id = $1', [decoded.id]);
        if (clientResult.rows.length === 0 || clientResult.rows[0].status === 'suspended') {
          return res.status(403).json({
            success: false,
            data: null,
            error: { code: 'ACCOUNT_DISABLED', message: 'This account has been suspended or removed' },
          });
        }
      }

      next();
    } catch (err) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'UNAUTHORIZED', message: 'Invalid or expired token' },
      });
    }
  };
};

module.exports = {
  authenticateToken,
  JWT_SECRET,
};
