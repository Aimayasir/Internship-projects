// db.js
// Dual-driver database adapter that automatically detects PostgreSQL
// and falls back to zero-config local SQLite if PostgreSQL is unreachable.

const { Pool } = require('pg');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
require('dotenv').config();

let useSQLite = false;
let sqliteDb = null;
let pgPool = null;

// Initialize pg pool
pgPool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'fittrack_db',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000, // short timeout to fail fast
});

// Helper to translate pg queries to sqlite
function translateQuery(text, params = []) {
  // Replace NOW() with CURRENT_TIMESTAMP (standard SQL)
  let sql = text.replace(/\bNOW\(\)/gi, 'CURRENT_TIMESTAMP');
  
  // Replace pg placeholders $1, $2... with SQLite ?
  const paramMatches = [...sql.matchAll(/\$(\d+)/g)];
  if (paramMatches.length === 0) {
    return { sql, params };
  }
  
  const newParams = [];
  paramMatches.forEach(match => {
    const pgIndex = parseInt(match[1], 10);
    newParams.push(params[pgIndex - 1]);
  });
  
  sql = sql.replace(/\$\d+/g, '?');
  return { sql, params: newParams };
}

// Function to run SQLite schema setup
function initSQLiteSchema(db) {
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  if (fs.existsSync(schemaPath)) {
    let sql = fs.readFileSync(schemaPath, 'utf8');
    
    // Translate schema SQL for SQLite
    sql = sql.replace(/::jsonb/gi, '');
    sql = sql.replace(/TIMESTAMP WITH TIME ZONE/gi, 'TIMESTAMP');
    sql = sql.replace(/JSONB/gi, 'TEXT');
    sql = sql.replace(/SERIAL PRIMARY KEY/gi, 'INTEGER PRIMARY KEY AUTOINCREMENT');
    sql = sql.replace(/NUMERIC\(\d+,\d+\)/gi, 'REAL');
    
    // Execute statements in single batch
    db.exec(sql, (err) => {
      if (err) {
        console.error('❌ SQLite Schema init error:', err.message);
      } else {
        console.log('✅ SQLite Schema initialized successfully.');
        
        // Seed default trainer & clients
        const seedSql = `
          INSERT OR IGNORE INTO trainers (id, name, email, password_hash, status)
          VALUES ('t_bilal', 'Coach Bilal', 'bilal@example.com', '$2a$10$8THQG4xUnbLwmK4wA0Taiew.Qale346HISP5w.MsuIEOm9OFhEHIW', 'active');
          
          INSERT OR IGNORE INTO trainer_notification_settings (trainer_id)
          VALUES ('t_bilal');
          
          INSERT OR IGNORE INTO clients (id, name, email, password_hash, status, trainer_id, starting_weight, height)
          VALUES ('c_sara', 'Sara Khan', 'sara@example.com', '$2a$10$8THQG4xUnbLwmK4wA0Taiew.Qale346HISP5w.MsuIEOm9OFhEHIW', 'active', 't_bilal', 68.50, 165.00);

          INSERT OR IGNORE INTO clients (id, name, email, password_hash, status, trainer_id, starting_weight, height)
          VALUES ('c_ali', 'Ali Raza', 'ali@example.com', '$2a$10$8THQG4xUnbLwmK4wA0Taiew.Qale346HISP5w.MsuIEOm9OFhEHIW', 'active', 't_bilal', 82.00, 178.00);

          INSERT OR IGNORE INTO clients (id, name, email, password_hash, status, trainer_id, starting_weight, height)
          VALUES ('c_zain', 'Zain Malik', 'zain@example.com', '$2a$10$8THQG4xUnbLwmK4wA0Taiew.Qale346HISP5w.MsuIEOm9OFhEHIW', 'at_risk', 't_bilal', 75.00, 172.00);
          
          INSERT OR IGNORE INTO invite_codes (trainer_id, code)
          VALUES ('t_bilal', 'BILAL2026');
        `;
        
        db.exec(seedSql, (err2) => {
          if (err2) {
            console.error('❌ SQLite Seed error:', err2.message);
          } else {
            console.log('✅ SQLite Starter seed records inserted successfully.');
          }
        });
      }
    });
  } else {
    console.error('⚠️ db/schema.sql not found! Cannot initialize SQLite database schema.');
  }
}

// Connect test to pg
pgPool.query('SELECT 1')
  .then(() => {
    console.log('📡 Connected to PostgreSQL database.');
  })
  .catch((err) => {
    console.log('⚠️ PostgreSQL connection failed. Falling back to local SQLite database...');
    useSQLite = true;
    
    const dbPath = path.join(__dirname, '../fittrack.db');
    const isNew = !fs.existsSync(dbPath);
    sqliteDb = new sqlite3.Database(dbPath);
    
    if (isNew) {
      console.log('⚙️ Initializing local SQLite database schema...');
      initSQLiteSchema(sqliteDb);
    } else {
      console.log('📡 Connected to local SQLite database (fittrack.db).');
    }
  });

// Helper to recursively parse JSON values in SQLite response rows
function parseRowJson(row) {
  if (!row) return row;
  const parsed = {};
  for (const key in row) {
    const val = row[key];
    if (typeof val === 'string') {
      const trimmed = val.trim();
      if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
        try {
          parsed[key] = JSON.parse(val);
          continue;
        } catch (e) {
          // ignore parsing error and keep as string
        }
      }
    }
    parsed[key] = val;
  }
  return parsed;
}

module.exports = {
  query: (text, params = []) => {
    if (useSQLite) {
      return new Promise((resolve, reject) => {
        const { sql, params: translatedParams } = translateQuery(text, params);
        const isSelect = sql.trim().toUpperCase().startsWith('SELECT');
        
        if (isSelect) {
          sqliteDb.all(sql, translatedParams, (err, rows) => {
            if (err) return reject(err);
            const parsedRows = (rows || []).map(parseRowJson);
            resolve({ rows: parsedRows, rowCount: parsedRows.length });
          });
        } else {
          sqliteDb.run(sql, translatedParams, function(err) {
            if (err) return reject(err);
            resolve({ rows: [], rowCount: this.changes });
          });
        }
      });
    } else {
      return pgPool.query(text, params);
    }
  },
  pool: pgPool
};
