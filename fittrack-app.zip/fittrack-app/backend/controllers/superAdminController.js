const db = require('../config/db');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/authMiddleware');

// POST /super-admin/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (email !== 'admin@alixo.pro' || password !== 'AdminPass1!') {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect' },
      });
    }

    const token = jwt.sign({ id: 'sa_1', role: 'super_admin', email }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({
      success: true,
      data: {
        admin: { id: 'sa_1', email: 'admin@alixo.pro' },
        token,
        refreshToken: 'rft_admin123',
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /super-admin/trainers
exports.getTrainers = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT t.id, t.name, t.email, t.status, t.created_at as "joinedAt", COUNT(c.id) as "clientCount" 
       FROM trainers t LEFT JOIN clients c ON t.id = c.trainer_id 
       GROUP BY t.id ORDER BY t.created_at DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    const countRes = await db.query('SELECT COUNT(*) FROM trainers');
    const total = parseInt(countRes.rows[0].count, 10);

    const trainers = result.rows.map(r => ({
      ...r,
      clientCount: parseInt(r.clientCount, 10),
    }));

    return res.json({
      success: true,
      data: {
        trainers,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /super-admin/trainers/:id
exports.getTrainerById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `SELECT t.id, t.name, t.email, t.phone, t.address, t.status, t.created_at as "createdAt", COUNT(c.id) as "clientCount"
       FROM trainers t LEFT JOIN clients c ON t.id = c.trainer_id WHERE t.id = $1 GROUP BY t.id`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Trainer not found' } });
    }

    return res.json({
      success: true,
      data: { ...result.rows[0], clientCount: parseInt(result.rows[0].clientCount, 10) },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /super-admin/trainers/:id/suspend
exports.suspendTrainer = async (req, res) => {
  try {
    const { id } = req.params;
    const { suspend } = req.body;
    const newStatus = suspend ? 'suspended' : 'active';

    await db.query('UPDATE trainers SET status = $1 WHERE id = $2', [newStatus, id]);
    return res.json({
      success: true,
      data: { id, status: newStatus },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /super-admin/trainers/:id
exports.deleteTrainer = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM trainers WHERE id = $1', [id]);
    return res.json({ success: true, data: { message: 'Trainer account deleted' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
