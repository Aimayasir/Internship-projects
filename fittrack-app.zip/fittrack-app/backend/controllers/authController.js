const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { JWT_SECRET } = require('../middleware/authMiddleware');

const REFRESH_SECRET = process.env.REFRESH_SECRET || 'fittrack_super_secret_refresh_key_2026';

const generateTokens = (payload) => {
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
  const refreshToken = jwt.sign(payload, REFRESH_SECRET, { expiresIn: '30d' });
  return { token, refreshToken };
};

// POST /auth/trainer/signup
exports.trainerSignup = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 8) {
      return res.status(422).json({
        success: false,
        data: null,
        error: { code: 'VALIDATION_ERROR', message: 'Password must be at least 8 characters' },
      });
    }

    const existing = await db.query('SELECT id FROM trainers WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({
        success: false,
        data: null,
        error: { code: 'EMAIL_EXISTS', message: 'An account with this email already exists' },
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const trainerId = `t_${Date.now()}`;

    await db.query(
      'INSERT INTO trainers (id, name, email, password_hash) VALUES ($1, $2, $3, $4)',
      [trainerId, name, email, hashedPassword]
    );

    // Initialize notification settings
    await db.query(
      'INSERT INTO trainer_notification_settings (trainer_id) VALUES ($1) ON CONFLICT DO NOTHING',
      [trainerId]
    );

    const { token, refreshToken } = generateTokens({ id: trainerId, role: 'trainer', email });

    return res.status(201).json({
      success: true,
      data: {
        trainer: { id: trainerId, name, email },
        token,
        refreshToken,
      },
      error: null,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /auth/trainer/login
exports.trainerLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await db.query('SELECT * FROM trainers WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect' },
      });
    }

    const trainer = result.rows[0];
    if (trainer.status === 'suspended') {
      return res.status(403).json({
        success: false,
        data: null,
        error: { code: 'ACCOUNT_SUSPENDED', message: 'Your account has been suspended by the platform admin' },
      });
    }

    const validPass = await bcrypt.compare(password, trainer.password_hash);
    if (!validPass) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect' },
      });
    }

    const { token, refreshToken } = generateTokens({ id: trainer.id, role: 'trainer', email: trainer.email });

    return res.json({
      success: true,
      data: {
        trainer: { id: trainer.id, name: trainer.name, email: trainer.email },
        token,
        refreshToken,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /auth/trainer/forgot-password
exports.trainerForgotPassword = async (req, res) => {
  return res.json({
    success: true,
    data: { message: 'If this email exists, a reset link has been sent' },
    error: null,
  });
};

// POST /auth/trainer/reset-password
exports.trainerResetPassword = async (req, res) => {
  const { resetToken, newPassword } = req.body;
  if (!resetToken || !newPassword) {
    return res.status(400).json({
      success: false,
      data: null,
      error: { code: 'INVALID_OR_EXPIRED_TOKEN', message: 'This reset link is invalid or has expired' },
    });
  }
  return res.json({
    success: true,
    data: { message: 'Password has been reset' },
    error: null,
  });
};

// POST /auth/client/preview
exports.clientPreview = async (req, res) => {
  try {
    const { inviteCode } = req.body;
    const result = await db.query(
      `SELECT t.name, t.photo_url FROM invite_codes i JOIN trainers t ON i.trainer_id = t.id WHERE i.code = $1`,
      [inviteCode]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CODE', message: 'This invite code is not valid' },
      });
    }

    const trainer = result.rows[0];
    return res.json({
      success: true,
      data: { trainer: { name: trainer.name, photo: trainer.photo_url } },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /auth/client/signup
exports.clientSignup = async (req, res) => {
  try {
    const { inviteCode, name, email, password, phone, startingWeight, height } = req.body;

    const codeResult = await db.query('SELECT trainer_id FROM invite_codes WHERE code = $1', [inviteCode]);
    if (codeResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CODE', message: 'This invite code is not valid' },
      });
    }

    const trainerId = codeResult.rows[0].trainer_id;

    const existing = await db.query('SELECT id FROM clients WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({
        success: false,
        data: null,
        error: { code: 'EMAIL_EXISTS', message: 'An account with this email already exists' },
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const clientId = `c_${Date.now()}`;

    await db.query(
      `INSERT INTO clients (id, name, email, password_hash, phone, starting_weight, height, trainer_id) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [clientId, name, email, hashedPassword, phone, startingWeight || null, height || null, trainerId]
    );

    // Log invite join
    await db.query('INSERT INTO invite_logs (trainer_id, client_id) VALUES ($1, $2)', [trainerId, clientId]);

    // Create chat thread between client and trainer
    await db.query(
      'INSERT INTO chat_threads (id, trainer_id, client_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
      [clientId, trainerId, clientId]
    );

    // Initialize notification settings
    await db.query(
      'INSERT INTO client_notification_settings (client_id) VALUES ($1) ON CONFLICT DO NOTHING',
      [clientId]
    );

    const { token, refreshToken } = generateTokens({ id: clientId, role: 'client', email, trainerId });

    return res.status(201).json({
      success: true,
      data: {
        client: { id: clientId, name, email },
        trainerId,
        token,
        refreshToken,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /auth/client/login
exports.clientLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await db.query('SELECT * FROM clients WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect' },
      });
    }

    const client = result.rows[0];
    if (client.status === 'suspended') {
      return res.status(403).json({
        success: false,
        data: null,
        error: { code: 'ACCOUNT_DISABLED', message: 'This account has been suspended or removed' },
      });
    }

    const validPass = await bcrypt.compare(password, client.password_hash);
    if (!validPass) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect' },
      });
    }

    const { token, refreshToken } = generateTokens({
      id: client.id,
      role: 'client',
      email: client.email,
      trainerId: client.trainer_id,
    });

    return res.json({
      success: true,
      data: {
        client: { id: client.id, name: client.name, email: client.email },
        token,
        refreshToken,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /auth/client/forgot-password
exports.clientForgotPassword = async (req, res) => {
  return res.json({
    success: true,
    data: { message: 'If this email exists, a reset link has been sent' },
    error: null,
  });
};

// POST /auth/client/reset-password
exports.clientResetPassword = async (req, res) => {
  const { resetToken, newPassword } = req.body;
  if (!resetToken || !newPassword) {
    return res.status(400).json({
      success: false,
      data: null,
      error: { code: 'INVALID_OR_EXPIRED_TOKEN', message: 'This reset link is invalid or has expired' },
    });
  }
  return res.json({
    success: true,
    data: { message: 'Password has been reset' },
    error: null,
  });
};

// POST /auth/refresh
exports.refreshToken = async (req, res) => {
  try {
    const { refreshToken: token } = req.body;
    if (!token) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'REFRESH_TOKEN_INVALID', message: 'Session expired, please log in again' },
      });
    }

    const decoded = jwt.verify(token, REFRESH_SECRET);
    const newTokens = generateTokens({
      id: decoded.id,
      role: decoded.role,
      email: decoded.email,
      trainerId: decoded.trainerId,
    });

    return res.json({
      success: true,
      data: {
        token: newTokens.token,
        refreshToken: newTokens.refreshToken,
      },
      error: null,
    });
  } catch (err) {
    return res.status(401).json({
      success: false,
      data: null,
      error: { code: 'REFRESH_TOKEN_INVALID', message: 'Session expired, please log in again' },
    });
  }
};

// POST /auth/logout
exports.logout = async (req, res) => {
  return res.json({
    success: true,
    data: { message: 'Logged out' },
    error: null,
  });
};
