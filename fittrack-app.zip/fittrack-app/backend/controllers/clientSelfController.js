const bcrypt = require('bcryptjs');
const db = require('../config/db');

// GET /client/profile
exports.getProfile = async (req, res) => {
  try {
    const clientId = req.user.id;
    const result = await db.query(
      `SELECT c.id, c.name, c.email, c.phone, c.photo_url as "photoUrl", c.dob, c.address, 
              t.id as "trainerId", t.name as "trainerName", t.photo_url as "trainerPhoto"
       FROM clients c LEFT JOIN trainers t ON c.trainer_id = t.id WHERE c.id = $1`,
      [clientId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Client not found' } });
    }

    const row = result.rows[0];
    return res.json({
      success: true,
      data: {
        id: row.id,
        name: row.name,
        email: row.email,
        phone: row.phone,
        photoUrl: row.photoUrl,
        dob: row.dob,
        address: row.address,
        trainer: row.trainerId ? { id: row.trainerId, name: row.trainerName, photoUrl: row.trainerPhoto } : null,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /client/profile
exports.updateProfile = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { name, phone, dob, address } = req.body;

    const fields = [];
    const values = [];
    let idx = 1;

    if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
    if (phone !== undefined) { fields.push(`phone = $${idx++}`); values.push(phone); }
    if (dob !== undefined) { fields.push(`dob = $${idx++}`); values.push(dob); }
    if (address !== undefined) { fields.push(`address = $${idx++}`); values.push(JSON.stringify(address)); }

    if (fields.length > 0) {
      values.push(clientId);
      await db.query(`UPDATE clients SET ${fields.join(', ')} WHERE id = $${idx}`, values);
    }

    return exports.getProfile(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /client/profile/photo
exports.uploadPhoto = async (req, res) => {
  try {
    const clientId = req.user.id;
    if (!req.file) {
      return res.status(400).json({ success: false, data: null, error: { code: 'VALIDATION_ERROR', message: 'No photo provided' } });
    }
    const photoUrl = `http://localhost:5000/uploads/${req.file.filename}`;
    await db.query('UPDATE clients SET photo_url = $1 WHERE id = $2', [photoUrl, clientId]);

    return res.json({ success: true, data: { photoUrl }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /client/profile/photo
exports.deletePhoto = async (req, res) => {
  try {
    const clientId = req.user.id;
    const defaultPhoto = 'https://cdn.fittrack.app/defaults/client-avatar.png';
    await db.query('UPDATE clients SET photo_url = $1 WHERE id = $2', [defaultPhoto, clientId]);

    return res.json({ success: true, data: { photoUrl: defaultPhoto }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /client/profile/change-password
exports.changePassword = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    const result = await db.query('SELECT password_hash FROM clients WHERE id = $1', [clientId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Client not found' } });
    }

    const validPass = await bcrypt.compare(currentPassword || '', result.rows[0].password_hash);
    if (!validPass) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INCORRECT_CURRENT_PASSWORD', message: 'Current password is incorrect' },
      });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE clients SET password_hash = $1 WHERE id = $2', [newHash, clientId]);

    return res.json({ success: true, data: { message: 'Password updated' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /client/notification-settings
exports.getNotificationSettings = async (req, res) => {
  try {
    const clientId = req.user.id;
    const result = await db.query(
      `SELECT workout_reminders as "workoutReminders", session_reminders as "sessionReminders", 
              messages, meal_reminders as "mealReminders" 
       FROM client_notification_settings WHERE client_id = $1`,
      [clientId]
    );

    if (result.rows.length === 0) {
      return res.json({
        success: true,
        data: { workoutReminders: true, sessionReminders: true, messages: true, mealReminders: true },
        error: null,
      });
    }

    return res.json({ success: true, data: result.rows[0], error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /client/notification-settings
exports.updateNotificationSettings = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { workoutReminders, sessionReminders, messages, mealReminders } = req.body;

    await db.query(
      `INSERT INTO client_notification_settings (client_id, workout_reminders, session_reminders, messages, meal_reminders)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (client_id) DO UPDATE SET
       workout_reminders = EXCLUDED.workout_reminders,
       session_reminders = EXCLUDED.session_reminders,
       messages = EXCLUDED.messages,
       meal_reminders = EXCLUDED.meal_reminders`,
      [clientId, workoutReminders, sessionReminders, messages, mealReminders]
    );

    return res.json({
      success: true,
      data: { workoutReminders, sessionReminders, messages, mealReminders },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
