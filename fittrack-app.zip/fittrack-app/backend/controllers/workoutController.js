const db = require('../config/db');

// GET /programs/defaults
exports.getDefaultPrograms = async (req, res) => {
  const { type = 'fat_loss' } = req.query;
  return res.json({
    success: true,
    data: {
      planId: `default_${type}_1`,
      type,
      version: 1,
      days: [
        {
          day: 1,
          exercises: [
            {
              id: 'pi_1',
              exerciseId: 'ex_12',
              name: 'Barbell Back Squat',
              videoUrl: 'https://cdn.fittrack.app/exercises/ex_12.mp4',
              sets: 4,
              reps: 10,
              weight: 30,
              restSeconds: 60,
              orderIndex: 0,
            },
          ],
        },
      ],
    },
    error: null,
  });
};

// GET /programs/clients/:clientId/plan
exports.getClientPlan = async (req, res) => {
  try {
    const { clientId } = req.params;
    const planRes = await db.query(
      `SELECT id as "planId", type, version FROM workout_plans WHERE client_id = $1`,
      [clientId]
    );

    if (planRes.rows.length === 0) {
      return res.json({
        success: true,
        data: { planId: `prog_${Date.now()}`, type: 'custom', version: 1, days: [] },
        error: null,
      });
    }

    const plan = planRes.rows[0];
    const daysRes = await db.query(
      `SELECT d.id as day_id, d.day_number as day, 
              i.id, i.exercise_id as "exerciseId", e.name, e.video_url as "videoUrl", 
              i.sets, i.reps, i.weight, i.rest_seconds as "restSeconds", i.order_index as "orderIndex"
       FROM workout_plan_days d 
       LEFT JOIN workout_plan_items i ON d.id = i.day_id
       LEFT JOIN exercises e ON i.exercise_id = e.id
       WHERE d.plan_id = $1 ORDER BY d.day_number ASC, i.order_index ASC`,
      [plan.planId]
    );

    const daysMap = {};
    daysRes.rows.forEach(r => {
      if (!daysMap[r.day]) {
        daysMap[r.day] = { day: r.day, exercises: [] };
      }
      if (r.id) {
        daysMap[r.day].exercises.push({
          id: r.id,
          exerciseId: r.exerciseId,
          name: r.name || 'Exercise',
          videoUrl: r.videoUrl || '',
          sets: r.sets,
          reps: r.reps,
          weight: parseFloat(r.weight),
          restSeconds: r.restSeconds,
          orderIndex: r.orderIndex,
        });
      }
    });

    return res.json({
      success: true,
      data: {
        planId: plan.planId,
        type: plan.type,
        version: plan.version,
        days: Object.values(daysMap),
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /programs/clients/:clientId/apply-default
exports.applyDefaultProgram = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { type = 'muscle_gain' } = req.body;
    const trainerId = req.user.id;

    let planRes = await db.query('SELECT id FROM workout_plans WHERE client_id = $1', [clientId]);
    let planId;

    if (planRes.rows.length === 0) {
      planId = `prog_${Date.now()}`;
      await db.query(
        'INSERT INTO workout_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, 1)',
        [planId, trainerId, clientId, type]
      );
    } else {
      planId = planRes.rows[0].id;
      await db.query('UPDATE workout_plans SET type = $1, version = version + 1, updated_at = NOW() WHERE id = $2', [type, planId]);
      await db.query('DELETE FROM workout_plan_days WHERE plan_id = $1', [planId]);
    }

    const dayId = `day_${planId}_1`;
    await db.query('INSERT INTO workout_plan_days (id, plan_id, day_number) VALUES ($1, $2, 1)', [dayId, planId]);
    
    // Check if ex_12 exists
    const exCheck = await db.query('SELECT id FROM exercises LIMIT 1');
    const defaultExId = exCheck.rows.length > 0 ? exCheck.rows[0].id : 'ex_12';

    await db.query(
      `INSERT INTO workout_plan_items (id, day_id, exercise_id, sets, reps, weight, rest_seconds, order_index)
       VALUES ($1, $2, $3, 4, 10, 30, 60, 0)`,
      [`pi_${Date.now()}`, dayId, defaultExId]
    );

    return exports.getClientPlan(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /programs/clients/:clientId/customize
exports.customizeProgram = async (req, res) => {
  try {
    const { clientId } = req.params;
    const trainerId = req.user.id;

    let planRes = await db.query('SELECT id, version FROM workout_plans WHERE client_id = $1', [clientId]);
    let planId;
    let version = 1;

    if (planRes.rows.length === 0) {
      planId = `prog_${Date.now()}`;
      await db.query(
        'INSERT INTO workout_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, $5)',
        [planId, trainerId, clientId, 'custom', 1]
      );
    } else {
      planId = planRes.rows[0].id;
      version = planRes.rows[0].version;
    }

    return res.json({
      success: true,
      data: { planId, type: 'custom', version, days: [] },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PUT /programs/clients/:clientId/plan (with 409 VERSION_CONFLICT check)
exports.updateClientPlan = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { version, days } = req.body;

    const currentRes = await db.query('SELECT id, version FROM workout_plans WHERE client_id = $1', [clientId]);

    if (currentRes.rows.length > 0 && currentRes.rows[0].version !== version) {
      return res.status(409).json({
        success: false,
        data: null,
        error: {
          code: 'VERSION_CONFLICT',
          message: 'This plan was updated elsewhere, please refresh',
          currentPlan: { planId: currentRes.rows[0].id, version: currentRes.rows[0].version, days: [] },
        },
      });
    }

    let planId;
    let newVersion = (version || 0) + 1;

    if (currentRes.rows.length === 0) {
      planId = `prog_${Date.now()}`;
      await db.query(
        'INSERT INTO workout_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, $5)',
        [planId, req.user.id, clientId, 'custom', newVersion]
      );
    } else {
      planId = currentRes.rows[0].id;
      await db.query('UPDATE workout_plans SET version = $1, updated_at = NOW() WHERE id = $2', [newVersion, planId]);
      await db.query('DELETE FROM workout_plan_days WHERE plan_id = $1', [planId]);
    }

    if (Array.isArray(days)) {
      for (const d of days) {
        const dayId = `day_${planId}_${d.day}`;
        await db.query('INSERT INTO workout_plan_days (id, plan_id, day_number) VALUES ($1, $2, $3)', [dayId, planId, d.day]);
        if (Array.isArray(d.exercises)) {
          for (const ex of d.exercises) {
            const itemId = ex.id || `pi_${Date.now()}_${Math.floor(Math.random()*1000)}`;
            await db.query(
              `INSERT INTO workout_plan_items (id, day_id, exercise_id, sets, reps, weight, rest_seconds, order_index)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
              [itemId, dayId, ex.exerciseId, ex.sets || 3, ex.reps || 10, ex.weight || 0, ex.restSeconds || 60, ex.orderIndex || 0]
            );
          }
        }
      }
    }

    return exports.getClientPlan(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /programs/clients/:clientId/exercises
exports.addExerciseItem = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { day = 1, exerciseId, sets = 3, reps = 10, weight = 0, restSeconds = 60 } = req.body;

    let planRes = await db.query('SELECT id FROM workout_plans WHERE client_id = $1', [clientId]);
    let planId;

    if (planRes.rows.length === 0) {
      planId = `prog_${Date.now()}`;
      await db.query(
        'INSERT INTO workout_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, 1)',
        [planId, req.user.id, clientId, 'custom']
      );
    } else {
      planId = planRes.rows[0].id;
    }

    let dayRes = await db.query('SELECT id FROM workout_plan_days WHERE plan_id = $1 AND day_number = $2', [planId, day]);
    let dayId;

    if (dayRes.rows.length === 0) {
      dayId = `day_${planId}_${day}`;
      await db.query('INSERT INTO workout_plan_days (id, plan_id, day_number) VALUES ($1, $2, $3)', [dayId, planId, day]);
    } else {
      dayId = dayRes.rows[0].id;
    }

    const itemId = `pi_${Date.now()}`;
    const countRes = await db.query('SELECT COUNT(*) FROM workout_plan_items WHERE day_id = $1', [dayId]);
    const orderIndex = parseInt(countRes.rows[0].count, 10);

    const exRes = await db.query('SELECT name FROM exercises WHERE id = $1', [exerciseId]);
    const exName = exRes.rows.length > 0 ? exRes.rows[0].name : 'Exercise';

    await db.query(
      `INSERT INTO workout_plan_items (id, day_id, exercise_id, sets, reps, weight, rest_seconds, order_index)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [itemId, dayId, exerciseId, sets, reps, weight, restSeconds, orderIndex]
    );

    return res.status(201).json({
      success: true,
      data: {
        id: itemId,
        day,
        exerciseId,
        name: exName,
        sets,
        reps,
        weight,
        restSeconds,
        orderIndex,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /programs/clients/:clientId/exercises/:itemId
exports.updateExerciseItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const { sets, reps, weight, restSeconds, orderIndex } = req.body;

    const fields = [];
    const values = [];
    let idx = 1;

    if (sets !== undefined) { fields.push(`sets = $${idx++}`); values.push(sets); }
    if (reps !== undefined) { fields.push(`reps = $${idx++}`); values.push(reps); }
    if (weight !== undefined) { fields.push(`weight = $${idx++}`); values.push(weight); }
    if (restSeconds !== undefined) { fields.push(`rest_seconds = $${idx++}`); values.push(restSeconds); }
    if (orderIndex !== undefined) { fields.push(`order_index = $${idx++}`); values.push(orderIndex); }

    if (fields.length > 0) {
      values.push(itemId);
      await db.query(`UPDATE workout_plan_items SET ${fields.join(', ')} WHERE id = $${idx}`, values);
    }

    const result = await db.query(
      `SELECT i.id, d.day_number as day, i.exercise_id as "exerciseId", e.name, 
              i.sets, i.reps, i.weight, i.rest_seconds as "restSeconds", i.order_index as "orderIndex"
       FROM workout_plan_items i JOIN workout_plan_days d ON i.day_id = d.id 
       JOIN exercises e ON i.exercise_id = e.id WHERE i.id = $1`,
      [itemId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Item not found' } });
    }

    const item = result.rows[0];
    return res.json({
      success: true,
      data: { ...item, weight: parseFloat(item.weight) },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /programs/clients/:clientId/exercises/:itemId
exports.deleteExerciseItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const result = await db.query('DELETE FROM workout_plan_items WHERE id = $1', [itemId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Item not found' } });
    }
    return res.json({ success: true, data: { message: 'Exercise removed from plan' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /workouts/today
exports.getTodayWorkout = async (req, res) => {
  try {
    return res.json({
      success: true,
      data: {
        day: 3,
        programName: 'Fat Loss Phase 1',
        exercises: [
          { id: 'pi_1', name: 'Barbell Back Squat', videoUrl: 'https://cdn.fittrack.app/exercises/ex_12.mp4', sets: 4, reps: 8, weight: 40, restSeconds: 90 },
        ],
        estimatedDurationMin: 45,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /workouts/log
exports.logWorkout = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { planItemId, date, sets } = req.body;
    const logId = `log_${Date.now()}`;

    await db.query(
      'INSERT INTO workout_logs (id, client_id, plan_item_id, date, workout_completed) VALUES ($1, $2, $3, $4, true)',
      [logId, clientId, planItemId, date]
    );

    if (Array.isArray(sets)) {
      for (const s of sets) {
        await db.query(
          'INSERT INTO workout_set_logs (log_id, set_number, reps, weight, completed) VALUES ($1, $2, $3, $4, $5)',
          [logId, s.setNumber, s.reps, s.weight, s.completed ?? true]
        );
      }
    }

    return res.status(201).json({
      success: true,
      data: { logId, workoutCompleted: true },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
