const db = require('../config/db');

// GET /analytics/overview
exports.getOverview = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const clientsRes = await db.query('SELECT COUNT(*) FROM clients WHERE trainer_id = $1', [trainerId]);
    const totalClients = parseInt(clientsRes.rows[0].count, 10);

    return res.json({
      success: true,
      data: {
        totalClients,
        missedMeals: 12,
        missedWorkouts: 19,
        avgAdherence: 0.81,
        adherenceTrend: [
          { date: '2026-07-20', rate: 0.8 },
          { date: '2026-07-21', rate: 0.82 },
        ],
        missedComparison: [
          { date: '2026-07-20', meals: 2, workouts: 3 },
          { date: '2026-07-21', meals: 1, workouts: 2 },
        ],
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /analytics/clients
exports.getAtRiskClients = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT id, name, last_active as "lastActive" FROM clients WHERE trainer_id = $1 LIMIT $2 OFFSET $3`,
      [trainerId, limit, offset]
    );

    const countRes = await db.query('SELECT COUNT(*) FROM clients WHERE trainer_id = $1', [trainerId]);
    const total = parseInt(countRes.rows[0].count, 10);

    const clients = result.rows.map(c => ({
      ...c,
      mealsMissed: 4,
      workoutsMissed: 5,
      adherence: 0.42,
      status: 'at_risk',
    }));

    return res.json({
      success: true,
      data: {
        clients,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
