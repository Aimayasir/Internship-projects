const db = require('../config/db');

// GET /schedule/events
exports.getEvents = async (req, res) => {
  try {
    const { from, to, clientId } = req.query;
    const trainerId = req.user.role === 'trainer' ? req.user.id : req.user.trainerId;

    let queryStr = `SELECT e.id, e.title, e.type, e.start_time as "startTime", e.end_time as "endTime" 
                    FROM schedule_events e WHERE e.trainer_id = $1`;
    const params = [trainerId];

    if (from) {
      params.push(from);
      queryStr += ` AND e.start_time >= $${params.length}`;
    }
    if (to) {
      params.push(to);
      queryStr += ` AND e.end_time <= $${params.length}`;
    }

    const result = await db.query(queryStr, params);

    const events = [];
    for (const ev of result.rows) {
      const clientRes = await db.query('SELECT client_id FROM event_clients WHERE event_id = $1', [ev.id]);
      const clientIds = clientRes.rows.map(r => r.client_id);
      if (!clientId || clientIds.includes(clientId)) {
        events.push({ ...ev, clientIds });
      }
    }

    return res.json({ success: true, data: { events }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /schedule/events
exports.createEvent = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { title, type, startTime, endTime, clientIds } = req.body;
    const id = `evt_${Date.now()}`;

    await db.query(
      `INSERT INTO schedule_events (id, trainer_id, title, type, start_time, end_time) VALUES ($1, $2, $3, $4, $5, $6)`,
      [id, trainerId, title, type, startTime, endTime]
    );

    if (Array.isArray(clientIds)) {
      for (const cid of clientIds) {
        await db.query('INSERT INTO event_clients (event_id, client_id) VALUES ($1, $2)', [id, cid]);
      }
    }

    return res.status(201).json({
      success: true,
      data: { id, title, type, startTime, endTime, clientIds: clientIds || [] },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /schedule/events/:id
exports.updateEvent = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { id } = req.params;
    const { title, startTime, endTime, clientIds } = req.body;

    const fields = [];
    const values = [];
    let idx = 1;

    if (title !== undefined) { fields.push(`title = $${idx++}`); values.push(title); }
    if (startTime !== undefined) { fields.push(`start_time = $${idx++}`); values.push(startTime); }
    if (endTime !== undefined) { fields.push(`end_time = $${idx++}`); values.push(endTime); }

    if (fields.length > 0) {
      values.push(id, trainerId);
      await db.query(`UPDATE schedule_events SET ${fields.join(', ')} WHERE id = $${idx++} AND trainer_id = $${idx}`, values);
    }

    if (Array.isArray(clientIds)) {
      await db.query('DELETE FROM event_clients WHERE event_id = $1', [id]);
      for (const cid of clientIds) {
        await db.query('INSERT INTO event_clients (event_id, client_id) VALUES ($1, $2)', [id, cid]);
      }
    }

    const updated = await db.query(
      `SELECT id, title, type, start_time as "startTime", end_time as "endTime" FROM schedule_events WHERE id = $1`,
      [id]
    );

    return res.json({ success: true, data: { ...updated.rows[0], clientIds: clientIds || [] }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /schedule/events/:id
exports.deleteEvent = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { id } = req.params;

    const result = await db.query('DELETE FROM schedule_events WHERE id = $1 AND trainer_id = $2', [id, trainerId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Event not found' } });
    }

    return res.json({ success: true, data: { message: 'Event cancelled' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
