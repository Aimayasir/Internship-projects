const db = require('../config/db');

// GET /progress/clients/:clientId/entries
exports.getEntries = async (req, res) => {
  try {
    const { clientId } = req.params;
    const result = await db.query(
      `SELECT id, date, weight, measurements, photo_url as "photoUrl" 
       FROM progress_entries WHERE client_id = $1 ORDER BY date DESC`,
      [clientId]
    );

    const entries = result.rows.map(r => ({
      ...r,
      weight: r.weight ? parseFloat(r.weight) : null,
    }));

    return res.json({ success: true, data: { entries }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /progress/entries
exports.createEntry = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { date, weight, measurements } = req.body;
    const id = `pe_${Date.now()}`;

    await db.query(
      `INSERT INTO progress_entries (id, client_id, date, weight, measurements) VALUES ($1, $2, $3, $4, $5)`,
      [id, clientId, date, weight, JSON.stringify(measurements || {})]
    );

    return res.status(201).json({
      success: true,
      data: { id, date, weight, measurements: measurements || {}, photoUrl: null },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /progress/entries/photo
exports.uploadPhoto = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { date } = req.body;
    const photoUrl = req.file ? `http://localhost:5000/uploads/${req.file.filename}` : 'https://cdn.fittrack.app/progress/sample.jpg';
    const id = `pe_${Date.now()}`;

    await db.query(
      `INSERT INTO progress_entries (id, client_id, date, photo_url) VALUES ($1, $2, $3, $4)`,
      [id, clientId, date || new Date().toISOString().split('T')[0], photoUrl]
    );

    return res.status(201).json({
      success: true,
      data: { id, photoUrl, date: date || new Date().toISOString().split('T')[0] },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /progress/entries/:id
exports.deleteEntry = async (req, res) => {
  try {
    const clientId = req.user.id;
    const { id } = req.params;

    const result = await db.query('DELETE FROM progress_entries WHERE id = $1 AND client_id = $2', [id, clientId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Entry not found' } });
    }

    return res.json({ success: true, data: { message: 'Entry deleted' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
