const db = require('../config/db');

// GET /exercises
exports.getExercises = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { search = '', muscleGroup, equipment, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let queryStr = `SELECT id, name, muscle_group as "muscleGroup", equipment, video_url as "videoUrl", instructions 
                    FROM exercises WHERE (is_global = true OR trainer_id = $1)`;
    const params = [trainerId];

    if (search) {
      params.push(`%${search}%`);
      queryStr += ` AND name ILIKE $${params.length}`;
    }

    if (muscleGroup) {
      params.push(muscleGroup);
      queryStr += ` AND muscle_group = $${params.length}`;
    }

    if (equipment) {
      params.push(equipment);
      queryStr += ` AND equipment = $${params.length}`;
    }

    const countRes = await db.query(`SELECT COUNT(*) FROM (${queryStr}) as total`, params);
    const total = parseInt(countRes.rows[0].count, 10);

    params.push(limit, offset);
    queryStr += ` ORDER BY name ASC LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const result = await db.query(queryStr, params);

    return res.json({
      success: true,
      data: {
        exercises: result.rows,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /exercises
exports.createExercise = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { name, muscleGroup, equipment, videoUrl, instructions } = req.body;
    const id = `ex_${Date.now()}`;

    await db.query(
      `INSERT INTO exercises (id, trainer_id, name, muscle_group, equipment, video_url, instructions, is_global) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, false)`,
      [id, trainerId, name, muscleGroup, equipment, videoUrl, instructions]
    );

    return res.status(201).json({
      success: true,
      data: { id, name, muscleGroup, equipment, videoUrl, instructions },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /exercises/:id
exports.updateExercise = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { id } = req.params;

    const check = await db.query('SELECT is_global, trainer_id FROM exercises WHERE id = $1', [id]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Exercise not found' } });
    }

    if (check.rows[0].is_global || check.rows[0].trainer_id !== trainerId) {
      return res.status(403).json({ success: false, data: null, error: { code: 'FORBIDDEN', message: 'You can only edit your custom exercises' } });
    }

    const { name, muscleGroup, equipment, videoUrl, instructions } = req.body;
    const fields = [];
    const values = [];
    let idx = 1;

    if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
    if (muscleGroup !== undefined) { fields.push(`muscle_group = $${idx++}`); values.push(muscleGroup); }
    if (equipment !== undefined) { fields.push(`equipment = $${idx++}`); values.push(equipment); }
    if (videoUrl !== undefined) { fields.push(`video_url = $${idx++}`); values.push(videoUrl); }
    if (instructions !== undefined) { fields.push(`instructions = $${idx++}`); values.push(instructions); }

    if (fields.length > 0) {
      values.push(id);
      await db.query(`UPDATE exercises SET ${fields.join(', ')} WHERE id = $${idx}`, values);
    }

    const updated = await db.query(
      `SELECT id, name, muscle_group as "muscleGroup", equipment, video_url as "videoUrl", instructions 
       FROM exercises WHERE id = $1`,
      [id]
    );

    return res.json({ success: true, data: updated.rows[0], error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /exercises/:id
exports.deleteExercise = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { id } = req.params;

    const check = await db.query('SELECT is_global, trainer_id FROM exercises WHERE id = $1', [id]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Exercise not found' } });
    }

    if (check.rows[0].is_global) {
      return res.status(403).json({
        success: false,
        data: null,
        error: { code: 'CANNOT_DELETE_GLOBAL', message: 'Base library exercises cannot be deleted' },
      });
    }

    if (check.rows[0].trainer_id !== trainerId) {
      return res.status(403).json({ success: false, data: null, error: { code: 'FORBIDDEN', message: 'Forbidden' } });
    }

    await db.query('DELETE FROM exercises WHERE id = $1', [id]);
    return res.json({ success: true, data: { message: 'Exercise deleted' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /nutrition/library
exports.getFoodLibrary = async (req, res) => {
  try {
    const { search = '', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let queryStr = `SELECT id, name, image_url as "imageUrl", calories, protein, carbs, fat, default_unit as "defaultUnit" 
                    FROM food_library WHERE 1=1`;
    const params = [];

    if (search) {
      params.push(`%${search}%`);
      queryStr += ` AND name ILIKE $${params.length}`;
    }

    const countRes = await db.query(`SELECT COUNT(*) FROM (${queryStr}) as total`, params);
    const total = parseInt(countRes.rows[0].count, 10);

    params.push(limit, offset);
    queryStr += ` ORDER BY name ASC LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const result = await db.query(queryStr, params);

    return res.json({
      success: true,
      data: {
        foods: result.rows,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /nutrition/library
exports.createFoodItem = async (req, res) => {
  try {
    const { name, imageUrl, calories, protein, carbs, fat, defaultUnit = 'g' } = req.body;
    const id = `food_${Date.now()}`;

    await db.query(
      `INSERT INTO food_library (id, name, image_url, calories, protein, carbs, fat, default_unit)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [id, name, imageUrl || '', calories || 0, protein || 0, carbs || 0, fat || 0, defaultUnit]
    );

    return res.status(201).json({
      success: true,
      data: { id, name, imageUrl, calories, protein, carbs, fat, defaultUnit },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
