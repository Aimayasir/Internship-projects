const bcrypt = require('bcryptjs');
const db = require('../config/db');

// GET /trainer/profile
exports.getProfile = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const result = await db.query(
      `SELECT id, name, email, phone, photo_url as "photoUrl", bio, specialty_tags as "specialtyTags", address, created_at as "createdAt" 
       FROM trainers WHERE id = $1`,
      [trainerId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Trainer not found' } });
    }

    return res.json({ success: true, data: result.rows[0], error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /trainer/profile
exports.updateProfile = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { name, phone, bio, specialtyTags, address } = req.body;

    const fields = [];
    const values = [];
    let idx = 1;

    if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
    if (phone !== undefined) { fields.push(`phone = $${idx++}`); values.push(phone); }
    if (bio !== undefined) { fields.push(`bio = $${idx++}`); values.push(bio); }
    if (specialtyTags !== undefined) { fields.push(`specialty_tags = $${idx++}`); values.push(JSON.stringify(specialtyTags)); }
    if (address !== undefined) { fields.push(`address = $${idx++}`); values.push(JSON.stringify(address)); }

    if (fields.length > 0) {
      values.push(trainerId);
      await db.query(`UPDATE trainers SET ${fields.join(', ')} WHERE id = $${idx}`, values);
    }

    const updated = await db.query(
      `SELECT id, name, email, phone, photo_url as "photoUrl", bio, specialty_tags as "specialtyTags", address, created_at as "createdAt" 
       FROM trainers WHERE id = $1`,
      [trainerId]
    );

    return res.json({ success: true, data: updated.rows[0], error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /trainer/profile/photo
exports.uploadPhoto = async (req, res) => {
  try {
    const trainerId = req.user.id;
    if (!req.file) {
      return res.status(400).json({ success: false, data: null, error: { code: 'VALIDATION_ERROR', message: 'No photo provided' } });
    }
    const photoUrl = `http://localhost:5000/uploads/${req.file.filename}`;
    await db.query('UPDATE trainers SET photo_url = $1 WHERE id = $2', [photoUrl, trainerId]);

    return res.json({ success: true, data: { photoUrl }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /trainer/profile/photo
exports.deletePhoto = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const defaultPhoto = 'https://cdn.fittrack.app/defaults/trainer-avatar.png';
    await db.query('UPDATE trainers SET photo_url = $1 WHERE id = $2', [defaultPhoto, trainerId]);

    return res.json({ success: true, data: { photoUrl: defaultPhoto }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /trainer/profile/change-password
exports.changePassword = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    const result = await db.query('SELECT password_hash FROM trainers WHERE id = $1', [trainerId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Trainer not found' } });
    }

    const validPass = await bcrypt.compare(currentPassword || '', result.rows[0].password_hash);
    if (!validPass) {
      return res.status(401).json({
        success: false,
        data: null,
        error: { code: 'INCORRECT_CURRENT_PASSWORD', message: 'Current password is incorrect' },
      });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE trainers SET password_hash = $1 WHERE id = $2', [newHash, trainerId]);

    return res.json({ success: true, data: { message: 'Password updated' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /trainer/dashboard
exports.getDashboard = async (req, res) => {
  try {
    const trainerId = req.user.id;

    const clientsRes = await db.query('SELECT COUNT(*) FROM clients WHERE trainer_id = $1 AND status = $2', [trainerId, 'active']);
    const activeClients = parseInt(clientsRes.rows[0].count, 10);

    const programsRes = await db.query('SELECT COUNT(*) FROM workout_plans WHERE trainer_id = $1', [trainerId]);
    const programsLive = parseInt(programsRes.rows[0].count, 10);

    return res.json({
      success: true,
      data: {
        activeClients,
        programsLive,
        missedWorkoutsThisWeek: 6,
        adherenceRate: 0.86,
        adherenceTrend: [
          { date: '2026-07-15', rate: 0.81 },
          { date: '2026-07-16', rate: 0.84 },
          { date: '2026-07-17', rate: 0.86 }
        ],
        recentActivity: [
          { clientId: 'c_501', clientName: 'Sara Khan', type: 'workout_completed', at: '2026-07-21T18:32:00Z' },
          { clientId: 'c_502', clientName: 'Ali Raza', type: 'message', at: '2026-07-21T17:10:00Z' },
          { clientId: 'c_503', clientName: 'Ayesha Noor', type: 'joined', at: '2026-07-21T09:00:00Z' }
        ]
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /trainer/notification-settings
exports.getNotificationSettings = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const result = await db.query(
      `SELECT new_client_joined as "newClientJoined", new_message as "newMessage", 
              missed_workout_alert as "missedWorkoutAlert", missed_meal_alert as "missedMealAlert" 
       FROM trainer_notification_settings WHERE trainer_id = $1`,
      [trainerId]
    );

    if (result.rows.length === 0) {
      return res.json({
        success: true,
        data: { newClientJoined: true, newMessage: true, missedWorkoutAlert: true, missedMealAlert: false },
        error: null,
      });
    }

    return res.json({ success: true, data: result.rows[0], error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /trainer/notification-settings
exports.updateNotificationSettings = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { newClientJoined, newMessage, missedWorkoutAlert, missedMealAlert } = req.body;

    await db.query(
      `INSERT INTO trainer_notification_settings (trainer_id, new_client_joined, new_message, missed_workout_alert, missed_meal_alert)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (trainer_id) DO UPDATE SET
       new_client_joined = EXCLUDED.new_client_joined,
       new_message = EXCLUDED.new_message,
       missed_workout_alert = EXCLUDED.missed_workout_alert,
       missed_meal_alert = EXCLUDED.missed_meal_alert`,
      [trainerId, newClientJoined, newMessage, missedWorkoutAlert, missedMealAlert]
    );

    return res.json({
      success: true,
      data: { newClientJoined, newMessage, missedWorkoutAlert, missedMealAlert },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
