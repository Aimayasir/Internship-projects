const db = require('../config/db');

// GET /chat/threads
exports.getThreads = async (req, res) => {
  try {
    const userId = req.user.id;
    const role = req.user.role;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let queryStr;
    let params;

    if (role === 'trainer') {
      queryStr = `SELECT t.client_id as "clientId", c.name, c.photo_url as "avatar", 
                         t.last_message as "lastMessage", t.unread_count_trainer as "unreadCount", 
                         c.last_active as "lastSeen"
                  FROM chat_threads t JOIN clients c ON t.client_id = c.id
                  WHERE t.trainer_id = $1 ORDER BY t.updated_at DESC LIMIT $2 OFFSET $3`;
      params = [userId, limit, offset];
    } else {
      queryStr = `SELECT t.trainer_id as "trainerId", tr.name, tr.photo_url as "avatar", 
                         t.last_message as "lastMessage", t.unread_count_client as "unreadCount", 
                         tr.created_at as "lastSeen"
                  FROM chat_threads t JOIN trainers tr ON t.trainer_id = tr.id
                  WHERE t.client_id = $1 ORDER BY t.updated_at DESC LIMIT $2 OFFSET $3`;
      params = [userId, limit, offset];
    }

    const result = await db.query(queryStr, params);
    const threads = result.rows.map(r => ({
      ...r,
      online: true,
    }));

    return res.json({ success: true, data: { threads }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /chat/threads/:threadId/messages
exports.getMessages = async (req, res) => {
  try {
    const { threadId } = req.params;
    const { before, limit = 50 } = req.query;

    let queryStr = `SELECT id, sender_role as "senderRole", type, content, media_url as "mediaUrl", 
                           duration, status, created_at as "createdAt"
                    FROM chat_messages WHERE thread_id = $1`;
    const params = [threadId];

    if (before) {
      params.push(before);
      queryStr += ` AND created_at < (SELECT created_at FROM chat_messages WHERE id = $2)`;
    }

    params.push(limit);
    queryStr += ` ORDER BY created_at ASC LIMIT $${params.length}`;

    const result = await db.query(queryStr, params);
    return res.json({ success: true, data: { messages: result.rows }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /chat/threads/:threadId/read
exports.markRead = async (req, res) => {
  try {
    const { threadId } = req.params;
    const role = req.user.role;

    if (role === 'trainer') {
      await db.query('UPDATE chat_threads SET unread_count_trainer = 0 WHERE id = $1', [threadId]);
    } else {
      await db.query('UPDATE chat_threads SET unread_count_client = 0 WHERE id = $1', [threadId]);
    }

    return res.json({ success: true, data: { message: 'Thread marked as read' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /chat/media
exports.uploadMedia = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, data: null, error: { code: 'VALIDATION_ERROR', message: 'No media file provided' } });
    }

    const isVoice = req.file.mimetype.includes('audio');
    const mediaUrl = `http://localhost:5000/uploads/${req.file.filename}`;

    return res.json({
      success: true,
      data: {
        mediaUrl,
        type: isVoice ? 'voice' : 'image',
        duration: isVoice ? 12 : null,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /chat/presence/:userId
exports.getPresence = async (req, res) => {
  return res.json({
    success: true,
    data: { online: true, lastSeen: new Date().toISOString() },
    error: null,
  });
};

// POST /chat/broadcast
exports.sendBroadcast = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { recipientIds, message, allowReplies = true } = req.body;
    const broadcastId = `bc_${Date.now()}`;

    let recipientsCount = 0;
    if (recipientIds === 'all') {
      const cRes = await db.query('SELECT COUNT(*) FROM clients WHERE trainer_id = $1', [trainerId]);
      recipientsCount = parseInt(cRes.rows[0].count, 10);
    } else if (Array.isArray(recipientIds)) {
      recipientsCount = recipientIds.length;
    }

    await db.query(
      `INSERT INTO broadcasts (id, trainer_id, message, allow_replies, recipient_ids, delivered_count)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [broadcastId, trainerId, message, allowReplies, JSON.stringify(recipientIds), recipientsCount]
    );

    return res.status(201).json({
      success: true,
      data: { broadcastId, deliveredCount: recipientsCount, failedCount: 0 },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /chat/broadcasts
exports.getBroadcasts = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT id, message, created_at as "sentAt", delivered_count as "deliveredCount", read_count as "readCount" 
       FROM broadcasts WHERE trainer_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [trainerId, limit, offset]
    );

    return res.json({
      success: true,
      data: { broadcasts: result.rows },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
