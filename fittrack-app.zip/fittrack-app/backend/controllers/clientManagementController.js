const db = require('../config/db');

// GET /clients
exports.getClients = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { search = '', status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let queryStr = `SELECT id, name, email, photo_url as "photoUrl", status, created_at as "joinedAt", last_active as "lastActive" 
                    FROM clients WHERE trainer_id = $1`;
    const params = [trainerId];

    if (search) {
      params.push(`%${search}%`);
      queryStr += ` AND name ILIKE $${params.length}`;
    }

    if (status) {
      params.push(status);
      queryStr += ` AND status = $${params.length}`;
    }

    const countRes = await db.query(`SELECT COUNT(*) FROM (${queryStr}) as total`, params);
    const total = parseInt(countRes.rows[0].count, 10);

    params.push(limit, offset);
    queryStr += ` ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const result = await db.query(queryStr, params);

    const clients = result.rows.map(c => ({
      ...c,
      planType: 'custom',
      adherence: 0.82,
    }));

    return res.json({
      success: true,
      data: {
        clients,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /clients/:clientId
exports.getClientById = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { clientId } = req.params;

    const result = await db.query(
      `SELECT id, name, email, phone, photo_url as "photoUrl", dob, address, status, 
              created_at as "joinedAt", assigned_program_id as "assignedProgramId", 
              assigned_nutrition_plan_id as "assignedNutritionPlanId", starting_weight as "startingWeight"
       FROM clients WHERE id = $1 AND trainer_id = $2`,
      [clientId, trainerId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'CLIENT_NOT_FOUND', message: 'Client not found' } });
    }

    const client = result.rows[0];
    return res.json({
      success: true,
      data: {
        ...client,
        stats: {
          currentWeight: client.startingWeight ? parseFloat(client.startingWeight) - 2 : 65.0,
          startingWeight: client.startingWeight ? parseFloat(client.startingWeight) : 68.5,
          workoutsCompleted: 40,
          workoutsMissed: 6,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /clients/:clientId
exports.updateClient = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { clientId } = req.params;
    const { name, phone, address, status } = req.body;

    const fields = [];
    const values = [];
    let idx = 1;

    if (name !== undefined) { fields.push(`name = $${idx++}`); values.push(name); }
    if (phone !== undefined) { fields.push(`phone = $${idx++}`); values.push(phone); }
    if (address !== undefined) { fields.push(`address = $${idx++}`); values.push(JSON.stringify(address)); }
    if (status !== undefined) { fields.push(`status = $${idx++}`); values.push(status); }

    if (fields.length > 0) {
      values.push(clientId, trainerId);
      await db.query(`UPDATE clients SET ${fields.join(', ')} WHERE id = $${idx++} AND trainer_id = $${idx}`, values);
    }

    return exports.getClientById(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /clients/:clientId
exports.deleteClient = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { clientId } = req.params;

    const result = await db.query('DELETE FROM clients WHERE id = $1 AND trainer_id = $2', [clientId, trainerId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'CLIENT_NOT_FOUND', message: 'Client not found' } });
    }

    return res.json({ success: true, data: { message: 'Client removed' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /clients/manual
exports.addClientManual = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { name, email, phone } = req.body;

    const clientId = `c_${Date.now()}`;
    const dummyPassword = '$2a$10$dummyhashforclientmanualsignup';

    await db.query(
      `INSERT INTO clients (id, name, email, password_hash, phone, status, trainer_id) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [clientId, name, email, dummyPassword, phone, 'pending', trainerId]
    );

    return res.status(201).json({
      success: true,
      data: { id: clientId, name, email, status: 'pending' },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
