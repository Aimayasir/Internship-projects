const db = require('../config/db');

// POST /notifications/custom
exports.sendCustomNotification = async (req, res) => {
  try {
    const { recipientIds, title, body } = req.body;
    if (!recipientIds || !Array.isArray(recipientIds) || recipientIds.length === 0) {
      return res.status(422).json({
        success: false,
        data: null,
        error: { code: 'EMPTY_RECIPIENT_LIST', message: 'Select at least one recipient' },
      });
    }

    for (const cid of recipientIds) {
      const id = `notif_${Date.now()}_${Math.floor(Math.random()*1000)}`;
      await db.query(
        `INSERT INTO notifications (id, user_id, user_role, type, title, body) VALUES ($1, $2, $3, $4, $5, $6)`,
        [id, cid, 'client', 'custom', title, body]
      );
    }

    return res.status(201).json({
      success: true,
      data: { message: 'Notification sent', sentCount: recipientIds.length },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /notifications
exports.getNotifications = async (req, res) => {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT id, type, title, body, read_at as "readAt", created_at as "createdAt" 
       FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [userId, limit, offset]
    );

    return res.json({
      success: true,
      data: { notifications: result.rows },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /notifications/:id/read
exports.markRead = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('UPDATE notifications SET read_at = NOW() WHERE id = $1', [id]);
    return res.json({ success: true, data: { message: 'Marked as read' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /notifications/read-all
exports.markAllRead = async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await db.query('UPDATE notifications SET read_at = NOW() WHERE user_id = $1 AND read_at IS NULL', [userId]);
    return res.json({
      success: true,
      data: { message: 'All notifications marked as read', updatedCount: result.rowCount },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /notifications/push-token
exports.registerPushToken = async (req, res) => {
  try {
    const userId = req.user.id;
    const role = req.user.role;
    const { token, platform = 'android' } = req.body;

    await db.query(
      `INSERT INTO user_push_tokens (user_id, user_role, token, platform) VALUES ($1, $2, $3, $4)`,
      [userId, role, token, platform]
    );

    return res.json({ success: true, data: { message: 'Push token registered' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
