const db = require('../config/db');

// POST /invite/generate
exports.generateInvite = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const code = `CODE_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    await db.query('DELETE FROM invite_codes WHERE trainer_id = $1', [trainerId]);
    await db.query('INSERT INTO invite_codes (trainer_id, code) VALUES ($1, $2)', [trainerId, code]);

    const link = `https://fittrack.app/join/${code}`;
    return res.json({ success: true, data: { code, link }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /invite/current
exports.getCurrentInvite = async (req, res) => {
  try {
    const trainerId = req.user.id;
    let result = await db.query('SELECT code, created_at as "createdAt" FROM invite_codes WHERE trainer_id = $1', [trainerId]);

    if (result.rows.length === 0) {
      const code = `TRAINER_${trainerId.substring(0, 6).toUpperCase()}`;
      await db.query('INSERT INTO invite_codes (trainer_id, code) VALUES ($1, $2)', [trainerId, code]);
      result = await db.query('SELECT code, created_at as "createdAt" FROM invite_codes WHERE trainer_id = $1', [trainerId]);
    }

    const item = result.rows[0];
    return res.json({
      success: true,
      data: {
        code: item.code,
        link: `https://fittrack.app/join/${item.code}`,
        createdAt: item.createdAt,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// GET /invite/log
exports.getInviteLog = async (req, res) => {
  try {
    const trainerId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT l.client_id as "clientId", c.name as "clientName", l.joined_at as "joinedAt" 
       FROM invite_logs l JOIN clients c ON l.client_id = c.id 
       WHERE l.trainer_id = $1 ORDER BY l.joined_at DESC LIMIT $2 OFFSET $3`,
      [trainerId, limit, offset]
    );

    const countRes = await db.query('SELECT COUNT(*) FROM invite_logs WHERE trainer_id = $1', [trainerId]);
    const total = parseInt(countRes.rows[0].count, 10);

    return res.json({
      success: true,
      data: {
        joins: result.rows,
        pagination: {
          page: parseInt(page, 10),
          limit: parseInt(limit, 10),
          total,
          totalPages: Math.ceil(total / limit) || 1,
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
