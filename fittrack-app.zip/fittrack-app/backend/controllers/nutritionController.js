const db = require('../config/db');

// GET /nutrition/defaults
exports.getDefaultNutrition = async (req, res) => {
  const { type = 'fat_loss' } = req.query;
  return res.json({
    success: true,
    data: {
      planId: `default_nut_${type}`,
      type,
      version: 1,
      days: [
        {
          day: 1,
          meals: {
            breakfast: [
              {
                id: 'ni_1',
                foodId: 'food_5',
                name: 'Grilled Chicken Breast',
                imageUrl: 'https://cdn.fittrack.app/foods/food_5.jpg',
                quantity: 100,
                unit: 'g',
                calories: 165,
                protein: 31,
                carbs: 0,
                fat: 3.6,
                orderIndex: 0,
              },
            ],
            lunch: [],
            dinner: [],
            snacks: [],
          },
        },
      ],
      totals: { calories: 165, protein: 31, carbs: 0, fat: 3.6 },
    },
    error: null,
  });
};

// GET /nutrition/clients/:clientId/plan
exports.getClientNutritionPlan = async (req, res) => {
  try {
    const { clientId } = req.params;
    const planRes = await db.query(
      'SELECT id as "planId", type, version FROM nutrition_plans WHERE client_id = $1',
      [clientId]
    );

    if (planRes.rows.length === 0) {
      return res.json({
        success: true,
        data: {
          planId: `nut_${Date.now()}`,
          type: 'custom',
          version: 1,
          days: [],
          totals: { calories: 0, protein: 0, carbs: 0, fat: 0 },
        },
        error: null,
      });
    }

    const plan = planRes.rows[0];
    const itemsRes = await db.query(
      `SELECT id, day_number as day, meal_slot as "mealSlot", food_id as "foodId", name, image_url as "imageUrl", 
              quantity, unit, calories, protein, carbs, fat, order_index as "orderIndex"
       FROM nutrition_plan_items WHERE plan_id = $1 ORDER BY day_number ASC, order_index ASC`,
      [plan.planId]
    );

    const daysMap = {};
    let totalCalories = 0, totalProtein = 0, totalCarbs = 0, totalFat = 0;

    itemsRes.rows.forEach(item => {
      const day = item.day;
      if (!daysMap[day]) {
        daysMap[day] = { day, meals: { breakfast: [], lunch: [], dinner: [], snacks: [] } };
      }
      const slot = item.mealSlot || 'breakfast';
      if (!daysMap[day].meals[slot]) daysMap[day].meals[slot] = [];

      const parsedCal = parseFloat(item.calories) || 0;
      const parsedProt = parseFloat(item.protein) || 0;
      const parsedCarb = parseFloat(item.carbs) || 0;
      const parsedFat = parseFloat(item.fat) || 0;

      totalCalories += parsedCal;
      totalProtein += parsedProt;
      totalCarbs += parsedCarb;
      totalFat += parsedFat;

      daysMap[day].meals[slot].push({
        id: item.id,
        foodId: item.foodId,
        name: item.name,
        imageUrl: item.imageUrl,
        quantity: parseFloat(item.quantity),
        unit: item.unit,
        calories: parsedCal,
        protein: parsedProt,
        carbs: parsedCarb,
        fat: parsedFat,
        orderIndex: item.orderIndex,
      });
    });

    return res.json({
      success: true,
      data: {
        planId: plan.planId,
        type: plan.type,
        version: plan.version,
        days: Object.values(daysMap),
        totals: {
          calories: Math.round(totalCalories),
          protein: Math.round(totalProtein),
          carbs: Math.round(totalCarbs),
          fat: Math.round(totalFat),
        },
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /nutrition/clients/:clientId/apply-default
exports.applyDefaultNutrition = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { type = 'fat_loss' } = req.body;
    const trainerId = req.user.id;

    let planRes = await db.query('SELECT id FROM nutrition_plans WHERE client_id = $1', [clientId]);
    let planId;

    if (planRes.rows.length === 0) {
      planId = `nut_${Date.now()}`;
      await db.query(
        'INSERT INTO nutrition_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, 1)',
        [planId, trainerId, clientId, type]
      );
    } else {
      planId = planRes.rows[0].id;
      await db.query('UPDATE nutrition_plans SET type = $1, version = version + 1, updated_at = NOW() WHERE id = $2', [type, planId]);
      await db.query('DELETE FROM nutrition_plan_items WHERE plan_id = $1', [planId]);
    }

    const foodCheck = await db.query('SELECT id, name, image_url, calories, protein, carbs, fat, default_unit FROM food_library LIMIT 1');
    const food = foodCheck.rows.length > 0 ? foodCheck.rows[0] : { id: 'food_5', name: 'Grilled Chicken Breast', image_url: '', calories: 165, protein: 31, carbs: 0, fat: 3.6, default_unit: 'g' };

    await db.query(
      `INSERT INTO nutrition_plan_items (id, plan_id, day_number, meal_slot, food_id, name, image_url, quantity, unit, calories, protein, carbs, fat, order_index)
       VALUES ($1, $2, 1, 'breakfast', $3, $4, $5, 100, $6, $7, $8, $9, $10, 0)`,
      [`ni_${Date.now()}`, planId, food.id, food.name, food.image_url, food.default_unit, food.calories, food.protein, food.carbs, food.fat]
    );

    return exports.getClientNutritionPlan(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /nutrition/clients/:clientId/customize
exports.customizeNutrition = async (req, res) => {
  try {
    const { clientId } = req.params;
    const trainerId = req.user.id;

    let planRes = await db.query('SELECT id, version FROM nutrition_plans WHERE client_id = $1', [clientId]);
    let planId;
    let version = 1;

    if (planRes.rows.length === 0) {
      planId = `nut_${Date.now()}`;
      await db.query(
        'INSERT INTO nutrition_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, $5)',
        [planId, trainerId, clientId, 'custom', 1]
      );
    } else {
      planId = planRes.rows[0].id;
      version = planRes.rows[0].version;
    }

    return res.json({
      success: true,
      data: { planId, type: 'custom', version, days: [], totals: { calories: 0, protein: 0, carbs: 0, fat: 0 } },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PUT /nutrition/clients/:clientId/plan
exports.updateClientNutritionPlan = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { version, days } = req.body;

    const currentRes = await db.query('SELECT id, version FROM nutrition_plans WHERE client_id = $1', [clientId]);

    if (currentRes.rows.length > 0 && currentRes.rows[0].version !== version) {
      return res.status(409).json({
        success: false,
        data: null,
        error: {
          code: 'VERSION_CONFLICT',
          message: 'This plan was updated elsewhere, please refresh',
          currentPlan: { planId: currentRes.rows[0].id, version: currentRes.rows[0].version },
        },
      });
    }

    let planId;
    let newVersion = (version || 0) + 1;

    if (currentRes.rows.length === 0) {
      planId = `nut_${Date.now()}`;
      await db.query(
        'INSERT INTO nutrition_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, $5)',
        [planId, req.user.id, clientId, 'custom', newVersion]
      );
    } else {
      planId = currentRes.rows[0].id;
      await db.query('UPDATE nutrition_plans SET version = $1, updated_at = NOW() WHERE id = $2', [newVersion, planId]);
      await db.query('DELETE FROM nutrition_plan_items WHERE plan_id = $1', [planId]);
    }

    if (Array.isArray(days)) {
      for (const d of days) {
        if (d.meals) {
          for (const slot of ['breakfast', 'lunch', 'dinner', 'snacks']) {
            if (Array.isArray(d.meals[slot])) {
              for (const item of d.meals[slot]) {
                const itemId = item.id || `ni_${Date.now()}_${Math.floor(Math.random()*1000)}`;
                const qty = item.quantity || 100;
                const cal = item.calories || (qty * 1.5);
                const prot = item.protein || (qty * 0.2);
                const carb = item.carbs || 0;
                const fat = item.fat || (qty * 0.05);

                await db.query(
                  `INSERT INTO nutrition_plan_items (id, plan_id, day_number, meal_slot, food_id, name, image_url, quantity, unit, calories, protein, carbs, fat, order_index)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
                  [itemId, planId, d.day, slot, item.foodId || 'food_default', item.name || 'Food Item', item.imageUrl || '', qty, item.unit || 'g', cal, prot, carb, fat, item.orderIndex || 0]
                );
              }
            }
          }
        }
      }
    }

    return exports.getClientNutritionPlan(req, res);
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// POST /nutrition/clients/:clientId/items
exports.addNutritionItem = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { day = 1, mealSlot = 'lunch', foodId, quantity = 100, unit = 'g' } = req.body;

    let planRes = await db.query('SELECT id FROM nutrition_plans WHERE client_id = $1', [clientId]);
    let planId;

    if (planRes.rows.length === 0) {
      planId = `nut_${Date.now()}`;
      await db.query(
        'INSERT INTO nutrition_plans (id, trainer_id, client_id, type, version) VALUES ($1, $2, $3, $4, 1)',
        [planId, req.user.id, clientId, 'custom']
      );
    } else {
      planId = planRes.rows[0].id;
    }

    const foodRes = await db.query('SELECT name, image_url, calories, protein, carbs, fat FROM food_library WHERE id = $1', [foodId]);
    const food = foodRes.rows.length > 0 ? foodRes.rows[0] : { name: 'Food Item', image_url: '', calories: 150, protein: 10, carbs: 20, fat: 3 };

    const multiplier = quantity / 100;
    const calories = parseFloat((parseFloat(food.calories) * multiplier).toFixed(1));
    const protein = parseFloat((parseFloat(food.protein) * multiplier).toFixed(1));
    const carbs = parseFloat((parseFloat(food.carbs) * multiplier).toFixed(1));
    const fat = parseFloat((parseFloat(food.fat) * multiplier).toFixed(1));

    const itemId = `ni_${Date.now()}`;
    const countRes = await db.query('SELECT COUNT(*) FROM nutrition_plan_items WHERE plan_id = $1 AND day_number = $2 AND meal_slot = $3', [planId, day, mealSlot]);
    const orderIndex = parseInt(countRes.rows[0].count, 10);

    await db.query(
      `INSERT INTO nutrition_plan_items (id, plan_id, day_number, meal_slot, food_id, name, image_url, quantity, unit, calories, protein, carbs, fat, order_index)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
      [itemId, planId, day, mealSlot, foodId, food.name, food.image_url, quantity, unit, calories, protein, carbs, fat, orderIndex]
    );

    return res.status(201).json({
      success: true,
      data: {
        id: itemId,
        day,
        mealSlot,
        foodId,
        name: food.name,
        imageUrl: food.image_url,
        quantity,
        unit,
        calories,
        protein,
        carbs,
        fat,
        orderIndex,
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// PATCH /nutrition/clients/:clientId/items/:itemId
exports.updateNutritionItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const { quantity, unit } = req.body;

    const currentRes = await db.query('SELECT food_id, quantity FROM nutrition_plan_items WHERE id = $1', [itemId]);
    if (currentRes.rows.length === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Item not found' } });
    }

    const foodId = currentRes.rows[0].food_id;
    const newQty = quantity !== undefined ? quantity : parseFloat(currentRes.rows[0].quantity);

    const foodRes = await db.query('SELECT calories, protein, carbs, fat FROM food_library WHERE id = $1', [foodId]);
    const food = foodRes.rows.length > 0 ? foodRes.rows[0] : { calories: 150, protein: 10, carbs: 20, fat: 3 };

    const multiplier = newQty / 100;
    const calories = parseFloat((parseFloat(food.calories) * multiplier).toFixed(1));
    const protein = parseFloat((parseFloat(food.protein) * multiplier).toFixed(1));
    const carbs = parseFloat((parseFloat(food.carbs) * multiplier).toFixed(1));
    const fat = parseFloat((parseFloat(food.fat) * multiplier).toFixed(1));

    const fields = [`quantity = $1`, `calories = $2`, `protein = $3`, `carbs = $4`, `fat = $5` ];
    const values = [newQty, calories, protein, carbs, fat];
    let idx = 6;

    if (unit !== undefined) { fields.push(`unit = $${idx++}`); values.push(unit); }

    values.push(itemId);
    await db.query(`UPDATE nutrition_plan_items SET ${fields.join(', ')} WHERE id = $${idx}`, values);

    const updatedRes = await db.query(
      `SELECT id, day_number as day, meal_slot as "mealSlot", food_id as "foodId", name, image_url as "imageUrl", 
              quantity, unit, calories, protein, carbs, fat, order_index as "orderIndex"
       FROM nutrition_plan_items WHERE id = $1`,
      [itemId]
    );

    const item = updatedRes.rows[0];
    return res.json({
      success: true,
      data: {
        ...item,
        quantity: parseFloat(item.quantity),
        calories: parseFloat(item.calories),
        protein: parseFloat(item.protein),
        carbs: parseFloat(item.carbs),
        fat: parseFloat(item.fat),
      },
      error: null,
    });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// DELETE /nutrition/clients/:clientId/items/:itemId
exports.deleteNutritionItem = async (req, res) => {
  try {
    const { itemId } = req.params;
    const result = await db.query('DELETE FROM nutrition_plan_items WHERE id = $1', [itemId]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Item not found' } });
    }
    return res.json({ success: true, data: { message: 'Item removed from plan' }, error: null });
  } catch (err) {
    return res.status(500).json({ success: false, data: null, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
