const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, `${Date.now()}_${file.originalname}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

const { authenticateToken } = require('../middleware/authMiddleware');

const auth = require('../controllers/authController');
const trainer = require('../controllers/trainerController');
const clients = require('../controllers/clientManagementController');
const clientSelf = require('../controllers/clientSelfController');
const invite = require('../controllers/inviteController');
const library = require('../controllers/libraryController');
const workout = require('../controllers/workoutController');
const nutrition = require('../controllers/nutritionController');
const schedule = require('../controllers/scheduleController');
const progress = require('../controllers/progressController');
const chat = require('../controllers/chatRestController');
const notification = require('../controllers/notificationController');
const analytics = require('../controllers/analyticsController');
const superAdmin = require('../controllers/superAdminController');

// Module 1: Auth
router.post('/auth/trainer/signup', auth.trainerSignup);
router.post('/auth/trainer/login', auth.trainerLogin);
router.post('/auth/trainer/forgot-password', auth.trainerForgotPassword);
router.post('/auth/trainer/reset-password', auth.trainerResetPassword);
router.post('/auth/client/preview', auth.clientPreview);
router.post('/auth/client/signup', auth.clientSignup);
router.post('/auth/client/login', auth.clientLogin);
router.post('/auth/client/forgot-password', auth.clientForgotPassword);
router.post('/auth/client/reset-password', auth.clientResetPassword);
router.post('/auth/refresh', auth.refreshToken);
router.post('/auth/logout', authenticateToken(), auth.logout);

// Module 2: Trainer Profile
router.get('/trainer/profile', authenticateToken(['trainer']), trainer.getProfile);
router.patch('/trainer/profile', authenticateToken(['trainer']), trainer.updateProfile);
router.post('/trainer/profile/photo', authenticateToken(['trainer']), upload.single('photo'), trainer.uploadPhoto);
router.delete('/trainer/profile/photo', authenticateToken(['trainer']), trainer.deletePhoto);
router.post('/trainer/profile/change-password', authenticateToken(['trainer']), trainer.changePassword);
router.get('/trainer/dashboard', authenticateToken(['trainer']), trainer.getDashboard);
router.get('/trainer/notification-settings', authenticateToken(['trainer']), trainer.getNotificationSettings);
router.patch('/trainer/notification-settings', authenticateToken(['trainer']), trainer.updateNotificationSettings);

// Module 3: Client Management (Trainer)
router.get('/clients', authenticateToken(['trainer']), clients.getClients);
router.get('/clients/:clientId', authenticateToken(['trainer']), clients.getClientById);
router.patch('/clients/:clientId', authenticateToken(['trainer']), clients.updateClient);
router.delete('/clients/:clientId', authenticateToken(['trainer']), clients.deleteClient);
router.post('/clients/manual', authenticateToken(['trainer']), clients.addClientManual);

// Module 4: Client Self-Profile (Client App)
router.get('/client/profile', authenticateToken(['client']), clientSelf.getProfile);
router.patch('/client/profile', authenticateToken(['client']), clientSelf.updateProfile);
router.post('/client/profile/photo', authenticateToken(['client']), upload.single('photo'), clientSelf.uploadPhoto);
router.delete('/client/profile/photo', authenticateToken(['client']), clientSelf.deletePhoto);
router.post('/client/profile/change-password', authenticateToken(['client']), clientSelf.changePassword);
router.get('/client/notification-settings', authenticateToken(['client']), clientSelf.getNotificationSettings);
router.patch('/client/notification-settings', authenticateToken(['client']), clientSelf.updateNotificationSettings);

// Module 5: Invite Link
router.post('/invite/generate', authenticateToken(['trainer']), invite.generateInvite);
router.get('/invite/current', authenticateToken(['trainer']), invite.getCurrentInvite);
router.get('/invite/log', authenticateToken(['trainer']), invite.getInviteLog);

// Module 6: Exercise Library
router.get('/exercises', authenticateToken(['trainer']), library.getExercises);
router.post('/exercises', authenticateToken(['trainer']), library.createExercise);
router.patch('/exercises/:id', authenticateToken(['trainer']), library.updateExercise);
router.delete('/exercises/:id', authenticateToken(['trainer']), library.deleteExercise);

// Module 7: Workout Programs & Log
router.get('/programs/defaults', authenticateToken(['trainer']), workout.getDefaultPrograms);
router.get('/programs/clients/:clientId/plan', authenticateToken(['trainer', 'client']), workout.getClientPlan);
router.post('/programs/clients/:clientId/apply-default', authenticateToken(['trainer']), workout.applyDefaultProgram);
router.post('/programs/clients/:clientId/customize', authenticateToken(['trainer']), workout.customizeProgram);
router.put('/programs/clients/:clientId/plan', authenticateToken(['trainer']), workout.updateClientPlan);
router.post('/programs/clients/:clientId/exercises', authenticateToken(['trainer']), workout.addExerciseItem);
router.patch('/programs/clients/:clientId/exercises/:itemId', authenticateToken(['trainer']), workout.updateExerciseItem);
router.delete('/programs/clients/:clientId/exercises/:itemId', authenticateToken(['trainer']), workout.deleteExerciseItem);
router.get('/workouts/today', authenticateToken(['client']), workout.getTodayWorkout);
router.post('/workouts/log', authenticateToken(['client']), workout.logWorkout);

// Module 8: Nutrition
router.get('/nutrition/library', authenticateToken(['trainer']), library.getFoodLibrary);
router.post('/nutrition/library', authenticateToken(['trainer']), library.createFoodItem);
router.get('/nutrition/defaults', authenticateToken(['trainer']), nutrition.getDefaultNutrition);
router.get('/nutrition/clients/:clientId/plan', authenticateToken(['trainer', 'client']), nutrition.getClientNutritionPlan);
router.post('/nutrition/clients/:clientId/apply-default', authenticateToken(['trainer']), nutrition.applyDefaultNutrition);
router.post('/nutrition/clients/:clientId/customize', authenticateToken(['trainer']), nutrition.customizeNutrition);
router.put('/nutrition/clients/:clientId/plan', authenticateToken(['trainer']), nutrition.updateClientNutritionPlan);
router.post('/nutrition/clients/:clientId/items', authenticateToken(['trainer']), nutrition.addNutritionItem);
router.patch('/nutrition/clients/:clientId/items/:itemId', authenticateToken(['trainer']), nutrition.updateNutritionItem);
router.delete('/nutrition/clients/:clientId/items/:itemId', authenticateToken(['trainer']), nutrition.deleteNutritionItem);

// Module 9: Schedule
router.get('/schedule/events', authenticateToken(['trainer', 'client']), schedule.getEvents);
router.post('/schedule/events', authenticateToken(['trainer']), schedule.createEvent);
router.patch('/schedule/events/:id', authenticateToken(['trainer']), schedule.updateEvent);
router.delete('/schedule/events/:id', authenticateToken(['trainer']), schedule.deleteEvent);

// Module 10: Progress Tracking
router.get('/progress/clients/:clientId/entries', authenticateToken(['trainer', 'client']), progress.getEntries);
router.post('/progress/entries', authenticateToken(['client']), progress.createEntry);
router.post('/progress/entries/photo', authenticateToken(['client']), upload.single('photo'), progress.uploadPhoto);
router.delete('/progress/entries/:id', authenticateToken(['client']), progress.deleteEntry);

// Module 11: Chat
router.get('/chat/threads', authenticateToken(['trainer', 'client']), chat.getThreads);
router.get('/chat/threads/:threadId/messages', authenticateToken(['trainer', 'client']), chat.getMessages);
router.patch('/chat/threads/:threadId/read', authenticateToken(['trainer', 'client']), chat.markRead);
router.post('/chat/media', authenticateToken(['trainer', 'client']), upload.single('file'), chat.uploadMedia);
router.get('/chat/presence/:userId', authenticateToken(['trainer', 'client']), chat.getPresence);
router.post('/chat/broadcast', authenticateToken(['trainer']), chat.sendBroadcast);
router.get('/chat/broadcasts', authenticateToken(['trainer']), chat.getBroadcasts);

// Module 12: Notifications
router.post('/notifications/custom', authenticateToken(['trainer']), notification.sendCustomNotification);
router.get('/notifications', authenticateToken(['trainer', 'client']), notification.getNotifications);
router.patch('/notifications/:id/read', authenticateToken(['trainer', 'client']), notification.markRead);
router.patch('/notifications/read-all', authenticateToken(['trainer', 'client']), notification.markAllRead);
router.post('/notifications/push-token', authenticateToken(['trainer', 'client']), notification.registerPushToken);

// Module 13: Analytics
router.get('/analytics/overview', authenticateToken(['trainer']), analytics.getOverview);
router.get('/analytics/clients', authenticateToken(['trainer']), analytics.getAtRiskClients);

// Module 14: Super Admin
router.post('/super-admin/login', superAdmin.login);
router.get('/super-admin/trainers', authenticateToken(['super_admin']), superAdmin.getTrainers);
router.get('/super-admin/trainers/:id', authenticateToken(['super_admin']), superAdmin.getTrainerById);
router.patch('/super-admin/trainers/:id/suspend', authenticateToken(['super_admin']), superAdmin.suspendTrainer);
router.delete('/super-admin/trainers/:id', authenticateToken(['super_admin']), superAdmin.deleteTrainer);

module.exports = router;
