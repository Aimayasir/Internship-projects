import React from 'react';
import { formatWeight } from '../../utils/formatWeight';

export function StockBarChart({ data }) {
  const categorySummary = React.useMemo(() => {
    const map = {};
    data.forEach(item => {
      const tag = item.tagCode;
      if (!map[tag]) {
        map[tag] = {
          name: item.categoryName,
          tag: item.tagCode,
          ukWeight: 0,
          pkWeight: 0,
          totalWeight: 0
        };
      }
      if (item.region === 'uk') {
        map[tag].ukWeight += item.totalWeight;
      } else if (item.region === 'pakistan') {
        map[tag].pkWeight += item.totalWeight;
      }
      map[tag].totalWeight += item.totalWeight;
    });
    return Object.values(map).sort((a, b) => b.totalWeight - a.totalWeight).slice(0, 8); // Top 8 categories
  }, [data]);

  const maxWeight = React.useMemo(() => {
    const maxVal = Math.max(...categorySummary.map(c => c.totalWeight), 1);
    return maxVal;
  }, [categorySummary]);

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-xs">
      <div className="mb-4">
        <h3 className="text-base font-bold text-gray-900">Top Categories Stock Levels</h3>
        <p className="text-xs text-gray-400">Total weight on hand split by region</p>
      </div>

      {categorySummary.length === 0 ? (
        <div className="h-[250px] flex items-center justify-center text-gray-450 text-sm">
          No stock data available
        </div>
      ) : (
        <div className="space-y-4">
          {categorySummary.map((cat) => {
            const ukPercent = (cat.ukWeight / maxWeight) * 100;
            const pkPercent = (cat.pkWeight / maxWeight) * 100;
            
            return (
              <div key={cat.tag} className="group">
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="font-bold text-gray-700">
                    {cat.name} ({cat.tag})
                  </span>
                  <span className="font-semibold text-gray-500">
                    {formatWeight(cat.totalWeight)}
                  </span>
                </div>
                
                {/* Visual Stacked Bar */}
                <div className="w-full bg-gray-100 h-5 rounded overflow-hidden flex shadow-inner relative">
                  {cat.ukWeight > 0 && (
                    <div
                      style={{ width: `${ukPercent}%` }}
                      className="bg-blue-500 transition-all duration-300 ease-out hover:opacity-90 relative"
                      title={`UK: ${formatWeight(cat.ukWeight)}`}
                    />
                  )}
                  {cat.pkWeight > 0 && (
                    <div
                      style={{ width: `${pkPercent}%` }}
                      className="bg-emerald-500 transition-all duration-300 ease-out hover:opacity-90 relative"
                      title={`Pakistan: ${formatWeight(cat.pkWeight)}`}
                    />
                  )}
                </div>

                {/* Subtext info */}
                <div className="flex gap-4 mt-1 text-[10px] text-gray-400 font-medium">
                  {cat.ukWeight > 0 && (
                    <span className="flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                      UK: {formatWeight(cat.ukWeight)}
                    </span>
                  )}
                  {cat.pkWeight > 0 && (
                    <span className="flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      Pakistan: {formatWeight(cat.pkWeight)}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default StockBarChart;
