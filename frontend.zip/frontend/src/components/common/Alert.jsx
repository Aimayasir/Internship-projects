import React from 'react';

export function Alert({
  type = 'error', // success, error, warning, info
  message,
  onClose,
  className = ''
}) {
  const baseStyles = 'relative p-4 rounded-md border text-sm transition-all duration-200';
  
  const types = {
    success: 'bg-emerald-50 border-emerald-200 text-emerald-800',
    error: 'bg-rose-50 border-rose-200 text-rose-800',
    warning: 'bg-amber-50 border-amber-200 text-amber-800',
    info: 'bg-blue-50 border-blue-200 text-blue-800'
  };

  const currentType = types[type] || types.error;

  return (
    <div className={`${baseStyles} ${currentType} ${className}`} role="alert">
      <div className="flex items-center justify-between">
        <div className="flex-1 font-medium">{message}</div>
        {onClose && (
          <button
            type="button"
            className="ml-3 inline-flex text-current hover:opacity-75 focus:outline-none transition-opacity cursor-pointer font-bold text-lg"
            onClick={onClose}
          >
            &times;
          </button>
        )}
      </div>
    </div>
  );
}

export default Alert;
