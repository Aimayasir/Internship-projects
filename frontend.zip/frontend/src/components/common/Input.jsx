import React from 'react';

export const Input = React.forwardRef(({
  label,
  id,
  type = 'text',
  error,
  className = '',
  required = false,
  ...props
}, ref) => {
  return (
    <div className="flex flex-col w-full mb-4">
      {label && (
        <label htmlFor={id} className="mb-1.5 text-sm font-medium text-gray-700 flex items-center">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      <input
        ref={ref}
        type={type}
        id={id}
        required={required}
        className={`
          w-full px-3 py-2 text-sm border rounded-md shadow-sm h-[44px] transition-colors focus:outline-none focus:ring-1
          ${error 
            ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
            : 'border-gray-300 focus:border-[#D4AF37] focus:ring-[#D4AF37]'
          }
          ${className}
        `}
        {...props}
      />
      {error && (
        <span className="mt-1.5 text-xs text-red-600 font-medium">
          {error}
        </span>
      )}
    </div>
  );
});

Input.displayName = 'Input';
export default Input;
