import React from 'react';

export function Badge({
  children,
  variant = 'default', // default, success, danger, warning, info, primary, uk, pakistan
  className = ''
}) {
  const baseStyles = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold transition-colors duration-150';
  
  const variants = {
    default: 'bg-gray-100 text-gray-800',
    primary: 'bg-amber-100 text-amber-900 border border-amber-200',
    success: 'bg-emerald-100 text-emerald-800 border border-emerald-200',
    danger: 'bg-rose-100 text-rose-800 border border-rose-200',
    warning: 'bg-amber-100 text-amber-800 border border-amber-200',
    info: 'bg-blue-100 text-blue-800 border border-blue-200',
    uk: 'bg-blue-100 text-blue-800 border border-blue-200', // UK = Blue background
    pakistan: 'bg-emerald-100 text-emerald-800 border border-emerald-200', // Pakistan = Green background
  };

  const currentVariant = variants[variant] || variants.default;

  return (
    <span className={`${baseStyles} ${currentVariant} ${className}`}>
      {children}
    </span>
  );
}

export default Badge;
