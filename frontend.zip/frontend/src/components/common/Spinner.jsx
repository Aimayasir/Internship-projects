import React from 'react';

export function Spinner({
  size = 'md', // sm, md, lg
  className = '',
  overlay = false
}) {
  const sizeClasses = {
    sm: 'h-6 w-6 border-2',
    md: 'h-10 w-10 border-3',
    lg: 'h-16 w-16 border-4'
  };

  const currentSize = sizeClasses[size] || sizeClasses.md;

  const spinner = (
    <div className={`relative flex items-center justify-center ${className}`}>
      <div
        className={`
          animate-spin rounded-full border-t-[#D4AF37] border-gray-200
          ${currentSize}
        `}
      />
    </div>
  );

  if (overlay) {
    return (
      <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex items-center justify-center z-40 rounded-lg">
        {spinner}
      </div>
    );
  }

  return spinner;
}

export default Spinner;
