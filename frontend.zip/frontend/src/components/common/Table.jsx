import React, { useState } from 'react';

export function Table({
  columns, // array of { key, header, sortable, render, rightAlign }
  data, // array of items
  onRowClick,
  mobileCardRender, // optional custom render for cards on mobile
  emptyMessage = 'No data available',
  className = ''
}) {
  const [sortKey, setSortKey] = useState('');
  const [sortDirection, setSortDirection] = useState('asc'); // asc or desc

  const handleSort = (key, sortable) => {
    if (!sortable) return;
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  const sortedData = React.useMemo(() => {
    if (!sortKey) return data;
    const sorted = [...data].sort((a, b) => {
      let aVal = a[sortKey];
      let bVal = b[sortKey];
      
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
      
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [data, sortKey, sortDirection]);

  return (
    <div className={`w-full ${className}`}>
      {/* Desktop/Tablet Table view */}
      <div className="hidden md:block overflow-x-auto border border-gray-200 rounded-lg shadow-sm">
        <table className="min-w-full divide-y divide-gray-200 text-sm text-left">
          <thead className="bg-[#1F2937] text-white">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key, col.sortable)}
                  className={`
                    px-6 py-3 font-semibold uppercase tracking-wider
                    ${col.sortable ? 'cursor-pointer select-none hover:bg-gray-700' : ''}
                    ${col.rightAlign ? 'text-right' : 'text-left'}
                  `}
                >
                  <div className={`flex items-center ${col.rightAlign ? 'justify-end' : ''}`}>
                    <span>{col.header}</span>
                    {col.sortable && sortKey === col.key && (
                      <span className="ml-1 text-xs">
                        {sortDirection === 'asc' ? ' ▲' : ' ▼'}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="px-6 py-8 text-center text-gray-500">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              sortedData.map((row, idx) => (
                <tr
                  key={row.id || row.saleId || row.categoryId || idx}
                  onClick={() => onRowClick && onRowClick(row)}
                  className={`
                    transition-colors duration-150
                    ${onRowClick ? 'cursor-pointer hover:bg-gray-50' : 'hover:bg-gray-50/50'}
                    ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}
                  `}
                >
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={`
                        px-6 py-4 whitespace-nowrap text-gray-700
                        ${col.rightAlign ? 'text-right' : 'text-left'}
                      `}
                    >
                      {col.render ? col.render(row, idx) : row[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Card List View */}
      <div className="block md:hidden space-y-4">
        {sortedData.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500 shadow-sm">
            {emptyMessage}
          </div>
        ) : (
          sortedData.map((row, idx) => (
            <div
              key={row.id || row.saleId || row.categoryId || idx}
              onClick={() => onRowClick && onRowClick(row)}
              className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow active:bg-gray-50 cursor-pointer"
            >
              {mobileCardRender ? (
                mobileCardRender(row, idx)
              ) : (
                <div className="space-y-2">
                  {columns.map((col) => (
                    <div key={col.key} className="flex justify-between text-sm">
                      <span className="font-semibold text-gray-500">{col.header}:</span>
                      <span className="text-gray-950 font-medium">
                        {col.render ? col.render(row, idx) : row[col.key]}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Table;
