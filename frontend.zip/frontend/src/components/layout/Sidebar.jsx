import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  History, 
  Coins, 
  BarChart3, 
  FileText, 
  Settings, 
  Users,
  Menu,
  X
} from 'lucide-react';

export function Sidebar() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => setIsOpen(!isOpen);

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['owner', 'manager', 'cashier'] },
    { to: '/pos', label: 'Point of Sale', icon: ShoppingBag, roles: ['owner', 'manager', 'cashier'] },
    { to: '/inventory', label: 'Inventory', icon: Package, roles: ['owner', 'manager', 'cashier'] },
    { to: '/sales-history', label: 'Sale History', icon: History, roles: ['owner', 'manager', 'cashier'] },
    { to: '/fine-gold', label: 'Fine Gold', icon: Coins, roles: ['owner', 'manager', 'cashier'] },
    { to: '/stock-report', label: 'Stock Report', icon: BarChart3, roles: ['owner', 'manager', 'cashier'] },
    { to: '/reports', label: 'Reports', icon: FileText, roles: ['owner', 'manager', 'cashier'] },
    { to: '/categories', label: 'Categories', icon: Settings, roles: ['owner'] },
    { to: '/users', label: 'Users', icon: Users, roles: ['owner'] },
  ];

  const filteredItems = navItems.filter(item => {
    if (!user) return false;
    return item.roles.includes(user.role);
  });

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#1F2937] text-white w-[250px] shadow-lg">
      {/* Brand Header */}
      <div className="h-[60px] flex items-center justify-between px-6 border-b border-gray-700 bg-gray-900/30">
        <div className="flex items-center gap-2">
          <Coins className="text-[#D4AF37] h-6 w-6 animate-pulse" />
          <span className="font-bold text-lg tracking-wider text-[#D4AF37]">JEWEL POS</span>
        </div>
        <button className="md:hidden text-white cursor-pointer" onClick={toggleSidebar}>
          <X className="h-6 w-6" />
        </button>
      </div>

      {/* Nav Links */}
      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setIsOpen(false)}
              className={({ isActive }) => `
                flex items-center gap-3 px-4 py-3 rounded-md text-sm font-semibold transition-all duration-150
                ${isActive 
                  ? 'bg-[#D4AF37] text-white shadow-md transform scale-[1.02]' 
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }
              `}
            >
              <Icon className="h-5 w-5 flex-shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* User Footer */}
      <div className="p-4 border-t border-gray-700 bg-gray-900/10">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] font-bold text-sm">
            {user?.full_name ? user.full_name.charAt(0) : 'U'}
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-sm font-bold truncate">{user?.full_name}</span>
            <span className="text-xs text-gray-400 capitalize">{user?.role}</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Toggle Button */}
      <div className="md:hidden fixed top-3 left-4 z-40">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-md bg-[#1F2937] text-white hover:bg-gray-800 focus:outline-none shadow-md cursor-pointer"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:flex-shrink-0 h-screen sticky top-0">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={toggleSidebar}
          />
          {/* Sidebar Panel */}
          <div className="relative flex flex-col flex-1 max-w-[250px] w-full bg-[#1F2937] transition-transform duration-250 transform translate-x-0">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}

export default Sidebar;
