import React from 'react';
import { useAuth } from '../../hooks/useAuth';

export function Header({
  title,
  selectedRegion,
  onRegionChange,
  showRegionSelector = true
}) {
  const { user, logout } = useAuth();

  return (
    <header className="h-[60px] bg-white border-b border-gray-200 px-6 flex items-center justify-between shadow-xs z-30">
      {/* Page Title */}
      <h2 className="text-xl font-bold text-gray-900 tracking-tight leading-none my-0">
        {title}
      </h2>

      {/* Right Side Options */}
      <div className="flex items-center gap-4">
        {/* Region Selector */}
        {showRegionSelector && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Region:
            </span>
            <select
              id="header-region-selector"
              value={selectedRegion}
              onChange={(e) => onRegionChange && onRegionChange(e.target.value)}
              className="bg-gray-50 border border-gray-300 text-gray-800 text-sm rounded-md focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] px-3 py-1.5 font-medium transition-colors cursor-pointer"
            >
              {(user?.region_access === 'both' || !user) && (
                <option value="both">Both Regions</option>
              )}
              {(user?.region_access === 'both' || user?.region_access === 'uk' || !user) && (
                <option value="uk">UK Only</option>
              )}
              {(user?.region_access === 'both' || user?.region_access === 'pakistan' || !user) && (
                <option value="pakistan">Pakistan Only</option>
              )}
            </select>
          </div>
        )}

        {/* User Profile / Logout */}
        {user && (
          <div className="flex items-center gap-3 border-l border-gray-200 pl-4">
            <div className="flex flex-col text-right hidden sm:flex">
              <span className="text-sm font-bold text-gray-800">{user.full_name}</span>
              <span className="text-xs font-medium text-gray-400 capitalize">{user.role}</span>
            </div>
            <button
              onClick={logout}
              className="text-xs font-semibold text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md px-2.5 py-1.5 transition-all cursor-pointer"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
