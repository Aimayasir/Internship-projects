import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Sidebar from './Sidebar';
import Header from './Header';

export function Layout({
  children,
  title,
  selectedRegion,
  onRegionChange,
  showRegionSelector = true,
  allowedRoles = []
}) {
  const { isAuthenticated, user, hasRole } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles.length > 0 && !hasRole(allowedRoles)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return (
    <div className="flex h-screen bg-[#F9FAFB] overflow-hidden text-gray-800">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Layout Area */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Header */}
        <Header
          title={title}
          selectedRegion={selectedRegion}
          onRegionChange={onRegionChange}
          showRegionSelector={showRegionSelector}
        />

        {/* Content Panel */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 relative">
          <div className="max-w-[1400px] mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Layout;
