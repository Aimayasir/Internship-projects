import { useState, useCallback } from 'react';
import { fineGoldService } from '../services/fineGoldService';

export function useFineGold(region = 'uk') {
  const [summary, setSummary] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchSummary = useCallback(async (r = region) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fineGoldService.getSummary(r);
      setSummary(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch fine gold summary');
    } finally {
      setLoading(false);
    }
  }, [region]);

  const fetchTransactions = useCallback(async (r = region) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fineGoldService.getTransactions(r);
      setTransactions(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch transaction history');
    } finally {
      setLoading(false);
    }
  }, [region]);

  const updatePrice = useCallback(async (r, price) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fineGoldService.updateCurrentPrice(r, price);
      setSummary(data);
      return data;
    } catch (err) {
      setError(err.message || 'Failed to update gold price');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const buyGold = useCallback(async (buyData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await fineGoldService.buyGold(buyData);
      await fetchSummary(buyData.region);
      await fetchTransactions(buyData.region);
      return result;
    } catch (err) {
      setError(err.message || 'Failed to buy gold');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchTransactions]);

  const sellGold = useCallback(async (sellData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await fineGoldService.sellGold(sellData);
      await fetchSummary(sellData.region);
      await fetchTransactions(sellData.region);
      return result;
    } catch (err) {
      setError(err.message || 'Failed to sell gold');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchTransactions]);

  return {
    summary,
    transactions,
    loading,
    error,
    fetchSummary,
    fetchTransactions,
    updatePrice,
    buyGold,
    sellGold
  };
}
