import { useState, useEffect, useCallback } from 'react';
import { useInventoryStore } from '../store/inventoryStore';

export function useInventory(region = 'both') {
  const { inventory, categories, fetchInventory, fetchCategories, loading, error } = useInventoryStore();

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  useEffect(() => {
    fetchInventory(region);
  }, [fetchInventory, region]);

  const refreshInventory = useCallback(() => {
    return fetchInventory(region);
  }, [fetchInventory, region]);

  return {
    inventory,
    categories,
    loading,
    error,
    refreshInventory
  };
}
