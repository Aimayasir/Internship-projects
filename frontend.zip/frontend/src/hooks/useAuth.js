import { useAuthStore } from '../store/authStore';

export function useAuth() {
  const { user, token, isAuthenticated, login, logout } = useAuthStore();

  return {
    user,
    token,
    isAuthenticated,
    login,
    logout,
    hasRole: (roles) => {
      if (!user) return false;
      if (Array.isArray(roles)) {
        return roles.includes(user.role);
      }
      return user.role === roles;
    },
    hasRegionAccess: (region) => {
      if (!user) return false;
      if (user.region_access === 'both') return true;
      return user.region_access === region;
    }
  };
}
