import { useState, useCallback } from 'react';
import { salesService } from '../services/salesService';

export function useSales() {
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchSales = useCallback(async (filters = {}) => {
    setLoading(true);
    setError(null);
    try {
      const data = await salesService.getSales(filters);
      setSales(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch sales history');
    } finally {
      setLoading(false);
    }
  }, []);

  const confirmSale = useCallback(async (saleData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await salesService.confirmSale(saleData);
      return result;
    } catch (err) {
      setError(err.message || 'Failed to confirm sale');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const voidSale = useCallback(async (saleId) => {
    setLoading(true);
    setError(null);
    try {
      const result = await salesService.voidSale(saleId);
      return result;
    } catch (err) {
      setError(err.message || 'Failed to void sale');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    sales,
    loading,
    error,
    fetchSales,
    confirmSale,
    voidSale
  };
}
