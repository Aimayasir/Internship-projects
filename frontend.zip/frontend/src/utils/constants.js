export const REGIONS = { UK: 'uk', PAKISTAN: 'pakistan', BOTH: 'both' };
export const ROLES = { OWNER: 'owner', MANAGER: 'manager', CASHIER: 'cashier' };

export const CATEGORIES = {
  DIAMOND_RINGS: { tag: 'DR', name: 'Diamond Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_RINGS: { tag: 'GR', name: 'Gold Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_NECKLACES: { tag: 'GN', name: 'Gold Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_BANGLES: { tag: 'GB', name: 'Gold Bangles', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  DIAMOND_NECKLACES: { tag: 'DN', name: 'Diamond Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_EARRINGS: { tag: 'GE', name: 'Gold Earrings', weightUnit: 'grams (g)', quantityUnit: 'pairs' },
  DIAMOND_EARRINGS: { tag: 'DE', name: 'Diamond Earrings', weightUnit: 'grams (g)', quantityUnit: 'pairs' },
  GOLD_BRACELETS: { tag: 'GBR', name: 'Gold Bracelets', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  SILVER_RINGS: { tag: 'SR', name: 'Silver Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  SILVER_NECKLACES: { tag: 'SN', name: 'Silver Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GEMSTONE_RINGS: { tag: 'GSR', name: 'Gemstone Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_CHAINS: { tag: 'GC', name: 'Gold Chains', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_PENDANTS: { tag: 'GP', name: 'Gold Pendants', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  DIAMOND_PENDANTS: { tag: 'DP', name: 'Diamond Pendants', weightUnit: 'grams (g)', quantityUnit: 'pieces' },
  GOLD_SETS: { tag: 'GS', name: 'Gold Sets', weightUnit: 'grams (g)', quantityUnit: 'sets' },
  LOOSE_DIAMONDS: { tag: 'LD', name: 'Loose Diamonds', weightUnit: 'grams (g)', quantityUnit: 'pieces' }
};

export const API_BASE_URL = 'http://localhost:5000/api/v1';
export const JWT_STORAGE_KEY = 'jewellery_pos_token';
