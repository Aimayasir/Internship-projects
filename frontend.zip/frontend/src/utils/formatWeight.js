export function formatWeight(grams) {
  if (grams === undefined || grams === null || isNaN(grams)) {
    return '0.000 g';
  }
  const parsed = parseFloat(grams);
  return parsed.toLocaleString('en-US', {
    minimumFractionDigits: 3,
    maximumFractionDigits: 3
  }) + ' g';
}
