export function formatCurrency(amount, region) {
  if (amount === undefined || amount === null || isNaN(amount)) {
    amount = 0;
  }
  const parsed = parseFloat(amount);
  const formattedNumber = parsed.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  if (region === 'uk' || region === 'UK') {
    return `£ ${formattedNumber}`;
  } else if (region === 'pakistan' || region === 'PAKISTAN' || region === 'pk' || region === 'PK') {
    return `Rs ${formattedNumber}`;
  } else {
    return `£ ${formattedNumber}`; // Default fallback
  }
}
