import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import InventoryPage from './pages/InventoryPage';
import AddStockPage from './pages/AddStockPage';
import PosPage from './pages/PosPage';
import SaleHistoryPage from './pages/SaleHistoryPage';
import FineGoldPage from './pages/FineGoldPage';
import StockReportPage from './pages/StockReportPage';
import ReportsPage from './pages/ReportsPage';
import CategoryPage from './pages/CategoryPage';
import UsersPage from './pages/UsersPage';

function UnauthorizedPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-md border border-gray-200">
        <h2 className="text-2xl font-bold text-red-600 mb-2">Access Denied</h2>
        <p className="text-sm text-gray-500 mb-6">
          You do not have the required permissions to view this page. Please contact your system owner.
        </p>
        <a
          href="/dashboard"
          className="inline-flex justify-center px-4 py-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white text-sm font-semibold rounded-md transition-colors"
        >
          Go back to Dashboard
        </a>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/inventory" element={<InventoryPage />} />
        <Route path="/add-stock" element={<AddStockPage />} />
        <Route path="/pos" element={<PosPage />} />
        <Route path="/sales-history" element={<SaleHistoryPage />} />
        <Route path="/fine-gold" element={<FineGoldPage />} />
        <Route path="/stock-report" element={<StockReportPage />} />
        <Route path="/reports" element={<ReportsPage />} />
        
        {/* Admin protected screens */}
        <Route path="/categories" element={<CategoryPage />} />
        <Route path="/users" element={<UsersPage />} />
        
        {/* Unauthorized page */}
        <Route path="/unauthorized" element={<UnauthorizedPage />} />
        
        {/* Fallback routing */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
