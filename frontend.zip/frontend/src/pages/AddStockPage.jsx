import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Package, ArrowLeft, Save, Sparkles, X } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';
import { inventoryService } from '../services/inventoryService';
import { useInventoryStore } from '../store/inventoryStore';
import { formatWeight } from '../utils/formatWeight';

export function AddStockPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { fetchInventory } = useInventoryStore();

  const [categories, setCategories] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form Fields
  const [categoryId, setCategoryId] = useState('');
  const [region, setRegion] = useState('');
  const [weight, setWeight] = useState('');
  const [qty, setQty] = useState('');
  const [pricePerGram, setPricePerGram] = useState('');
  const [pricePerPiece, setPricePerPiece] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [notes, setNotes] = useState('');

  // Search/Filter for Category Dropdown
  const [catSearch, setCatSearch] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  // Form Validation Errors
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    const loadInitData = async () => {
      setFetching(true);
      try {
        const cats = await inventoryService.getCategories();
        setCategories(cats.filter(c => c.isActive));

        const inv = await inventoryService.getInventory('both');
        setInventory(inv);

        // Prepopulate from state (if redirected from Inventory details)
        if (location.state) {
          if (location.state.categoryId) {
            setCategoryId(location.state.categoryId);
            const foundCat = cats.find(c => c.id === location.state.categoryId);
            if (foundCat) setCatSearch(`${foundCat.name} (${foundCat.tagCode})`);
          }
          if (location.state.region) setRegion(location.state.region);
        }
      } catch (err) {
        console.error(err);
        setError('Failed to load category metadata');
      } finally {
        setFetching(false);
      }
    };
    loadInitData();
  }, [location.state]);

  // Current Stock Lookup
  const currentStock = useMemo(() => {
    if (!categoryId || !region) return { weight: 0, qty: 0 };
    const match = inventory.find(
      item => item.categoryId === categoryId && item.region === region
    );
    return {
      weight: match ? match.totalWeight : 0,
      qty: match ? match.totalQty : 0
    };
  }, [categoryId, region, inventory]);

  // Calculations for Preview Section
  const preview = useMemo(() => {
    const inputWeight = parseFloat(weight) || 0;
    const inputQty = parseInt(qty, 10) || 0;

    return {
      currentWeight: currentStock.weight,
      currentQty: currentStock.qty,
      newWeight: currentStock.weight + inputWeight,
      newQty: currentStock.qty + inputQty
    };
  }, [currentStock, weight, qty]);

  // Filter Categories for search dropdown
  const filteredCategories = useMemo(() => {
    return categories.filter(c => 
      c.name.toLowerCase().includes(catSearch.toLowerCase()) ||
      c.tagCode.toLowerCase().includes(catSearch.toLowerCase())
    );
  }, [categories, catSearch]);

  const validate = () => {
    const errs = {};
    if (!categoryId) errs.categoryId = 'Category selection is required';
    if (!region) errs.region = 'Operation region is required';
    
    const parsedWeight = parseFloat(weight);
    if (!weight) {
      errs.weight = 'Weight is required';
    } else if (isNaN(parsedWeight) || parsedWeight <= 0) {
      errs.weight = 'Weight must be a decimal value greater than 0';
    }

    const parsedQty = parseInt(qty, 10);
    if (!qty) {
      errs.qty = 'Quantity is required';
    } else if (isNaN(parsedQty) || parsedQty <= 0 || !Number.isInteger(Number(qty))) {
      errs.qty = 'Quantity must be an integer greater than 0';
    }

    if (!supplierName) errs.supplierName = 'Supplier Name is required';
    if (!referenceNumber) errs.referenceNumber = 'Reference Number/Invoice number is required';

    setValidationErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validate()) return;

    setLoading(true);
    try {
      const stockData = {
        categoryId,
        region,
        weight_grams: parseFloat(weight),
        quantity: parseInt(qty, 10),
        price_per_gram: pricePerGram ? parseFloat(pricePerGram) : null,
        price_per_piece: pricePerPiece ? parseFloat(pricePerPiece) : null,
        supplier_name: supplierName,
        reference_number: referenceNumber,
        notes
      };

      await inventoryService.addStockEntry(stockData);
      
      setSuccess(`Stock added successfully! New total: ${formatWeight(preview.newWeight)}, ${preview.newQty} pcs`);
      
      // Update local ZUSTAND store
      await fetchInventory('both');

      // Clear Form
      setWeight('');
      setQty('');
      setPricePerGram('');
      setPricePerPiece('');
      setNotes('');
      // Scroll to top to see success alert
      window.scrollTo({ top: 0, behavior: 'smooth' });

      // Refresh inventory records list
      const inv = await inventoryService.getInventory('both');
      setInventory(inv);

    } catch (err) {
      setError(err.message || 'Failed to register stock entry');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout title="Add Stock Entry" showRegionSelector={false}>
      
      {/* Back Link */}
      <div className="mb-4">
        <button
          onClick={() => navigate('/inventory')}
          className="flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Inventory
        </button>
      </div>

      {error && <Alert type="error" message={error} className="mb-6" />}
      {success && <Alert type="success" message={success} className="mb-6" />}

      {fetching ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Form (takes 2 cols) */}
          <div className="lg:col-span-2 bg-white p-6 md:p-8 border border-gray-200 rounded-lg shadow-xs">
            <form onSubmit={handleSave} className="space-y-6">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Category Searchable Dropdown */}
                <div className="relative">
                  <label className="mb-1.5 text-sm font-medium text-gray-700 flex items-center">
                    Category Name / Tag <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="text"
                    id="stock-category-input"
                    placeholder="Type to search category..."
                    value={catSearch}
                    onChange={(e) => {
                      setCatSearch(e.target.value);
                      setShowDropdown(true);
                      if (!e.target.value) setCategoryId('');
                    }}
                    onFocus={() => setShowDropdown(true)}
                    className={`w-full px-3 py-2 text-sm border rounded-md shadow-sm h-[44px] focus:outline-none focus:ring-1 ${
                      validationErrors.categoryId ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#D4AF37] focus:ring-[#D4AF37]'
                    }`}
                  />
                  {showDropdown && (
                    <div className="absolute left-0 right-0 mt-1 max-h-56 overflow-y-auto bg-white border border-gray-200 rounded-md shadow-lg z-50">
                      {filteredCategories.length === 0 ? (
                        <div className="p-3 text-xs text-gray-400">No categories found</div>
                      ) : (
                        filteredCategories.map(c => (
                          <div
                            key={c.id}
                            onClick={() => {
                              setCategoryId(c.id);
                              setCatSearch(`${c.name} (${c.tagCode})`);
                              setShowDropdown(false);
                            }}
                            className="p-3 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer border-b border-gray-50 flex justify-between items-center"
                          >
                            <span className="font-semibold">{c.name}</span>
                            <span className="font-mono text-xs text-gray-450 bg-gray-105 px-1.5 py-0.5 rounded">{c.tagCode}</span>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                  {validationErrors.categoryId && (
                    <span className="text-xs text-red-600 font-medium mt-1 block">{validationErrors.categoryId}</span>
                  )}
                </div>

                {/* Region Selector */}
                <div>
                  <label className="mb-1.5 text-sm font-medium text-gray-700 flex items-center">
                    Operational Region <span className="text-red-500 ml-1">*</span>
                  </label>
                  <select
                    id="stock-region-select"
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    className={`w-full px-3 py-2 text-sm border rounded-md shadow-sm h-[44px] bg-white focus:outline-none focus:ring-1 ${
                      validationErrors.region ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#D4AF37] focus:ring-[#D4AF37]'
                    }`}
                  >
                    <option value="">Select Region</option>
                    <option value="uk">UK</option>
                    <option value="pakistan">Pakistan</option>
                  </select>
                  {validationErrors.region && (
                    <span className="text-xs text-red-600 font-medium mt-1 block">{validationErrors.region}</span>
                  )}
                </div>

              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Weight Input */}
                <Input
                  label="Weight (grams)"
                  id="weight"
                  type="number"
                  step="any"
                  placeholder="e.g. 10.500"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  error={validationErrors.weight}
                  required
                />

                {/* Quantity Input */}
                <Input
                  label="Quantity (pieces)"
                  id="qty"
                  type="number"
                  placeholder="e.g. 5"
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  error={validationErrors.qty}
                  required
                />

              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Price Per Gram */}
                <Input
                  label="Price Per Gram (Optional)"
                  id="pricePerGram"
                  type="number"
                  step="any"
                  placeholder="e.g. 4200"
                  value={pricePerGram}
                  onChange={(e) => setPricePerGram(e.target.value)}
                />

                {/* Price Per Piece */}
                <Input
                  label="Price Per Piece (Optional)"
                  id="pricePerPiece"
                  type="number"
                  step="any"
                  placeholder="e.g. 15000"
                  value={pricePerPiece}
                  onChange={(e) => setPricePerPiece(e.target.value)}
                />

              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Supplier Name */}
                <Input
                  label="Supplier Name"
                  id="supplierName"
                  placeholder="e.g. Al-Hafiz Jewellers"
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  error={validationErrors.supplierName}
                  required
                />

                {/* Reference Number */}
                <Input
                  label="Reference Number / Invoice"
                  id="referenceNumber"
                  placeholder="e.g. INV-2024-9988"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  error={validationErrors.referenceNumber}
                  required
                />

              </div>

              {/* Notes */}
              <div>
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                  Notes / Audit Remarks (Optional)
                </label>
                <textarea
                  id="notes"
                  rows="3"
                  placeholder="Additional stock remarks..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors"
                />
              </div>

              {/* Save / Cancel buttons */}
              <div className="flex gap-4 pt-4 border-t border-gray-200">
                <Button
                  variant="outline"
                  onClick={() => navigate('/inventory')}
                  className="w-full sm:w-auto"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  loading={loading}
                  className="w-full sm:w-auto flex items-center justify-center gap-1.5"
                >
                  <Save className="h-4 w-4" /> Save Stock Entry
                </Button>
              </div>

            </form>
          </div>

          {/* Real-time Preview Section (takes 1 col) */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col justify-between max-h-[350px] shadow-sm">
            <div>
              <div className="flex items-center gap-2 mb-4 border-b border-gray-200 pb-3">
                <Package className="h-5 w-5 text-[#D4AF37]" />
                <h3 className="text-base font-bold text-gray-900 my-0">Stock Preview</h3>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-gray-550">Current Total Weight:</span>
                  <span className="font-mono text-gray-900 font-bold">{formatWeight(preview.currentWeight)}</span>
                </div>
                
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-gray-550">Current Quantity:</span>
                  <span className="font-mono text-gray-900 font-bold">{preview.currentQty} pieces</span>
                </div>

                <div className="border-t border-gray-200 pt-3 flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#D4AF37]">Weight After Adding:</span>
                  <span className="font-mono text-emerald-600 font-extrabold text-sm">
                    {formatWeight(preview.newWeight)}
                  </span>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#D4AF37]">Quantity After Adding:</span>
                  <span className="font-mono text-emerald-600 font-extrabold text-sm">
                    {preview.newQty} pieces
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-3 bg-amber-50 border border-amber-200/50 rounded-md text-[11px] text-amber-800 flex gap-2">
              <Sparkles className="h-4 w-4 text-[#D4AF37] flex-shrink-0" />
              <span>Preview updates automatically as you select categories and type weights or quantities.</span>
            </div>
          </div>

        </div>
      )}

    </Layout>
  );
}

export default AddStockPage;
