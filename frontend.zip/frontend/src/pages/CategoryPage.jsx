import React, { useState, useEffect } from 'react';
import { Settings, Plus, Edit2, ToggleLeft, ToggleRight, Check, X, Sparkles } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Alert from '../components/common/Alert';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import { inventoryService } from '../services/inventoryService';

export function CategoryPage() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Custom Category Adding Form
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newTag, setNewTag] = useState('');
  const [newName, setNewName] = useState('');
  const [newQtyUnit, setNewQtyUnit] = useState('pieces');
  const [addErrors, setAddErrors] = useState({});
  const [addLoading, setAddLoading] = useState(false);

  // Category Editing Form
  const [editingCat, setEditingCat] = useState(null);
  const [editName, setEditName] = useState('');
  const [editSort, setEditSort] = useState('');
  const [editErrors, setEditErrors] = useState({});
  const [editLoading, setEditLoading] = useState(false);

  const fetchCategories = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await inventoryService.getCategories();
      // Sort by sortOrder
      const sorted = [...result].sort((a, b) => (a.sortOrder || 999) - (b.sortOrder || 999));
      setCategories(sorted);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch categories list');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    setAddErrors({});

    const errs = {};
    const alphanumericTag = /^[A-Z0-9]{1,10}$/i;
    
    if (!newTag) {
      errs.tag = 'Tag code is required';
    } else if (!alphanumericTag.test(newTag)) {
      errs.tag = 'Tag code must be alphanumeric and between 1-10 characters';
    } else if (categories.some(c => c.tagCode.toUpperCase() === newTag.toUpperCase())) {
      errs.tag = 'This tag code is already in use';
    }

    if (!newName) errs.name = 'Category Name is required';

    if (Object.keys(errs).length > 0) {
      setAddErrors(errs);
      return;
    }

    setAddLoading(true);
    try {
      await inventoryService.addCustomCategory({
        tagCode: newTag.toUpperCase(),
        name: newName,
        quantityUnit: newQtyUnit
      });
      alert('Custom category added successfully!');
      setIsAddOpen(false);
      setNewTag('');
      setNewName('');
      setNewQtyUnit('pieces');
      fetchCategories();
    } catch (err) {
      alert(err.message || 'Failed to add category');
    } finally {
      setAddLoading(false);
    }
  };

  const handleEditClick = (cat) => {
    if (!cat.isCustom && cat.id.startsWith('cat-')) {
      // Default categories are non-editable (non-deletable)
      alert('Default categories cannot be renamed or deleted.');
      return;
    }
    setEditingCat(cat);
    setEditName(cat.name);
    setEditSort(cat.sortOrder || '');
    setEditErrors({});
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setEditErrors({});

    if (!editName) {
      setEditErrors({ name: 'Category Name is required' });
      return;
    }

    setEditLoading(true);
    try {
      await inventoryService.updateCategory(editingCat.id, {
        name: editName,
        sortOrder: editSort ? parseInt(editSort, 10) : undefined
      });
      alert('Category updated successfully!');
      setEditingCat(null);
      fetchCategories();
    } catch (err) {
      alert(err.message || 'Failed to update category');
    } finally {
      setEditLoading(false);
    }
  };

  const handleDeactivate = async (id, isActive) => {
    const actionStr = isActive ? 'deactivate' : 'reactivate';
    if (!window.confirm(`Are you sure you want to ${actionStr} this category?`)) return;

    try {
      if (isActive) {
        await inventoryService.deactivateCategory(id);
      } else {
        await inventoryService.reactivateCategory(id);
      }
      alert(`Category ${isActive ? 'deactivated' : 'reactivated'} successfully!`);
      fetchCategories();
    } catch (err) {
      alert(err.message || 'Failed to update category status');
    }
  };

  const columns = [
    { 
      key: 'tagCode', 
      header: 'Tag', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-gray-800">{row.tagCode}</span>
    },
    { key: 'name', header: 'Category Name', sortable: true },
    { key: 'weightUnit', header: 'Weight Unit' },
    { key: 'quantityUnit', header: 'Qty Unit' },
    { 
      key: 'isActive', 
      header: 'Status', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.isActive ? 'success' : 'danger'}>
          {row.isActive ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    { 
      key: 'isCustom', 
      header: 'Type',
      render: (row) => <span>{row.isCustom ? 'Custom' : 'Default'}</span>
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <div className="flex gap-2">
          {row.isCustom && (
            <>
              <button
                onClick={() => handleEditClick(row)}
                className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer"
                title="Edit Category"
              >
                <Edit2 className="h-4 w-4" />
              </button>
              <button
                onClick={() => handleDeactivate(row.id, row.isActive)}
                className={`p-1 cursor-pointer ${row.isActive ? 'text-rose-500 hover:text-rose-700' : 'text-emerald-500 hover:text-emerald-700'}`}
                title={row.isActive ? 'Deactivate Category' : 'Reactivate Category'}
              >
                {row.isActive ? <ToggleLeft className="h-5 w-5" /> : <ToggleRight className="h-5 w-5" />}
              </button>
            </>
          )}
          {!row.isCustom && (
            <span className="text-[10px] text-gray-400 font-semibold uppercase italic bg-gray-100 px-1.5 py-0.5 rounded">Fixed</span>
          )}
        </div>
      )
    }
  ];

  return (
    <Layout title="Category Management" allowedRoles={['owner']} showRegionSelector={false}>
      
      <div className="flex justify-between items-center mb-6">
        <p className="text-xs text-gray-500 max-w-md my-0">
          Admin dashboard to manage system category metrics. Default categories cannot be deactivated or edited.
        </p>
        <button
          onClick={() => setIsAddOpen(true)}
          className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white px-5 py-2.5 rounded-md text-sm font-semibold shadow-sm transition-colors cursor-pointer h-[44px]"
        >
          <Plus className="h-4 w-4" /> Add Custom Category
        </button>
      </div>

      {error && <Alert type="error" message={error} className="mb-6" />}

      {loading ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <Table
          columns={columns}
          data={categories}
          emptyMessage="No categories created in the system."
          mobileCardRender={(row) => (
            <div className={`space-y-3 ${!row.isActive ? 'opacity-60' : ''}`}>
              <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                <span className="font-semibold text-gray-800 text-sm">{row.name}</span>
                <span className="font-mono text-xs font-bold text-gray-500 bg-gray-105 px-1.5 py-0.5 rounded">{row.tagCode}</span>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Units: {row.weightUnit} / {row.quantityUnit}</span>
                <span>Type: {row.isCustom ? 'Custom' : 'Default'}</span>
              </div>
              <div className="pt-2 border-t border-gray-105 flex justify-between items-center text-xs">
                <Badge variant={row.isActive ? 'success' : 'danger'}>
                  {row.isActive ? 'Active' : 'Inactive'}
                </Badge>
                {row.isCustom && (
                  <div className="flex gap-2">
                    <button onClick={() => handleEditClick(row)} className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer">
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button onClick={() => handleDeactivate(row.id, row.isActive)} className={row.isActive ? 'text-rose-500' : 'text-emerald-500'}>
                      {row.isActive ? <ToggleLeft className="h-5 w-5" /> : <ToggleRight className="h-5 w-5" />}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        />
      )}

      {/* Add Custom Category Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Add Custom Category"
        size="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-4">
          <div className="p-3 bg-amber-50 border border-amber-200/50 rounded-md text-[11px] text-amber-800 flex gap-2 mb-2">
            <Sparkles className="h-4 w-4 text-[#D4AF37] flex-shrink-0 mt-0.5" />
            <span>Tag codes must be unique and once created cannot be changed. Weight unit is fixed as grams (g).</span>
          </div>

          <Input
            label="Tag Code (1-10 Alphanumeric chars)"
            id="newTag"
            placeholder="e.g. SLR"
            value={newTag}
            onChange={(e) => setNewTag(e.target.value)}
            error={addErrors.tag}
            required
          />

          <Input
            label="Category Name"
            id="newName"
            placeholder="e.g. Silver Earrings"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            error={addErrors.name}
            required
          />

          <div>
            <label htmlFor="newQtyUnit" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              Quantity Unit
            </label>
            <select
              id="newQtyUnit"
              value={newQtyUnit}
              onChange={(e) => setNewQtyUnit(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
            >
              <option value="pieces">pieces</option>
              <option value="sets">sets</option>
              <option value="pairs">pairs</option>
              <option value="dozens">dozens</option>
            </select>
          </div>

          <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
            <Button variant="outline" onClick={() => setIsAddOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={addLoading}>
              Save Category
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit Category Modal */}
      {editingCat && (
        <Modal
          isOpen={!!editingCat}
          onClose={() => setEditingCat(null)}
          title={`Edit Category: ${editingCat.tagCode}`}
          size="md"
        >
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <Input
              label="Tag Code (Disabled)"
              id="editTag"
              value={editingCat.tagCode}
              disabled
            />
            
            <Input
              label="Category Name"
              id="editName"
              placeholder="Rename category..."
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              error={editErrors.name}
              required
            />

            <Input
              label="Sort Priority Order"
              id="editSort"
              type="number"
              placeholder="e.g. 5"
              value={editSort}
              onChange={(e) => setEditSort(e.target.value)}
            />

            <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
              <Button variant="outline" onClick={() => setEditingCat(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={editLoading}>
                Save Changes
              </Button>
            </div>
          </form>
        </Modal>
      )}

    </Layout>
  );
}

export default CategoryPage;
