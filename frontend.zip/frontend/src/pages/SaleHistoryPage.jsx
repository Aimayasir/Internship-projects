import React, { useState, useEffect, useMemo } from 'react';
import { Calendar, Download, RefreshCw, Eye, AlertTriangle, FileSpreadsheet, FileText } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Table from '../components/common/Table';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Modal from '../components/common/Modal';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';
import { useSales } from '../hooks/useSales';
import { useAuth } from '../hooks/useAuth';
import { reportService } from '../services/reportService';
import { formatWeight } from '../utils/formatWeight';
import { formatCurrency } from '../utils/formatCurrency';

export function SaleHistoryPage() {
  const { user } = useAuth();
  const { sales, loading, error, fetchSales, voidSale } = useSales();

  // Filter States
  const [region, setRegion] = useState('both');
  const [fromDate, setFromDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7); // Default 7 days ago
    return d.toISOString().split('T')[0];
  });
  const [toDate, setToDate] = useState(() => {
    return new Date().toISOString().split('T')[0]; // Default today
  });

  // Modal Details State
  const [selectedSale, setSelectedSale] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [voiding, setVoiding] = useState(false);
  const [voidConfirmOpen, setVoidConfirmOpen] = useState(false);

  const activeFilters = useMemo(() => {
    return {
      region,
      fromDate,
      toDate
    };
  }, [region, fromDate, toDate]);

  useEffect(() => {
    fetchSales(activeFilters);
  }, [activeFilters, fetchSales]);

  const handleRowClick = (sale) => {
    setSelectedSale(sale);
    setIsDetailOpen(true);
  };

  const handleVoidSaleClick = () => {
    setVoidConfirmOpen(true);
  };

  const handleConfirmVoid = async () => {
    if (!selectedSale) return;
    setVoidConfirmOpen(false);
    setVoiding(true);
    try {
      await voidSale(selectedSale.saleId);
      // Success toast
      alert(`Sale ${selectedSale.transactionCode} has been voided. Inventory stock restored.`);
      setIsDetailOpen(false);
      fetchSales(activeFilters);
    } catch (err) {
      alert(err.message || 'Failed to void sale');
    } finally {
      setVoiding(false);
    }
  };

  const handleExport = async (format) => {
    try {
      await reportService.exportReport('sales', format, activeFilters);
    } catch (err) {
      alert('Failed to export report');
    }
  };

  const columns = [
    { 
      key: 'transactionCode', 
      header: 'Code', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-gray-900">{row.transactionCode}</span>
    },
    { 
      key: 'timestamp', 
      header: 'Date & Time', 
      sortable: true,
      render: (row) => <span>{new Date(row.timestamp).toLocaleString()}</span>
    },
    { 
      key: 'region', 
      header: 'Region', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.region === 'uk' ? 'uk' : 'pakistan'}>
          {row.region === 'uk' ? 'UK' : 'Pakistan'}
        </Badge>
      )
    },
    { 
      key: 'itemCount', 
      header: 'Items', 
      sortable: true,
      render: (row) => <span className="font-mono">{row.itemCount}</span>
    },
    { 
      key: 'totalWeight', 
      header: 'Total Weight (g)', 
      sortable: true,
      render: (row) => <span className="font-mono text-gray-900">{formatWeight(row.totalWeight)}</span>
    },
    { 
      key: 'totalPrice', 
      header: 'Sale Price', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-emerald-600">{formatCurrency(row.totalPrice, row.region)}</span>
    },
    { key: 'staffName', header: 'Staff Name' },
    { 
      key: 'status', 
      header: 'Status', 
      render: (row) => (
        <Badge variant={row.isVoided ? 'danger' : 'success'}>
          {row.isVoided ? 'Voided' : 'Completed'}
        </Badge>
      )
    }
  ];

  return (
    <Layout title="Sale History" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={true}>
      
      {/* Filtering Options & Exporters */}
      <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-xs mb-6 flex flex-col md:flex-row gap-4 justify-between items-end">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full md:max-w-xl">
          <div>
            <label htmlFor="sales-from-date" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              From Date
            </label>
            <input
              type="date"
              id="sales-from-date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
            />
          </div>
          <div>
            <label htmlFor="sales-to-date" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              To Date
            </label>
            <input
              type="date"
              id="sales-to-date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
            />
          </div>
        </div>

        {/* Exporters */}
        <div className="flex gap-2 w-full md:w-auto">
          <Button
            variant="outline"
            onClick={() => handleExport('excel')}
            className="w-full md:w-auto flex items-center justify-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" /> Export Excel
          </Button>
          <Button
            variant="outline"
            onClick={() => handleExport('pdf')}
            className="w-full md:w-auto flex items-center justify-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileText className="h-4 w-4 text-red-500" /> Export PDF
          </Button>
        </div>
      </div>

      {error && (
        <Alert type="error" message={error} className="mb-6" />
      )}

      {loading && sales.length === 0 ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <Table
          columns={columns}
          data={sales}
          onRowClick={handleRowClick}
          emptyMessage="No sales found for the selected date range."
          mobileCardRender={(row) => (
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                <span className="font-mono font-bold text-gray-800 text-sm">{row.transactionCode}</span>
                <div className="flex gap-1.5">
                  <Badge variant={row.isVoided ? 'danger' : 'success'}>
                    {row.isVoided ? 'Void' : 'Done'}
                  </Badge>
                  <Badge variant={row.region === 'uk' ? 'uk' : 'pakistan'}>
                    {row.region === 'uk' ? 'UK' : 'PK'}
                  </Badge>
                </div>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Date: {new Date(row.timestamp).toLocaleDateString()}</span>
                <span>Staff: {row.staffName}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs pt-2 border-t border-gray-105 text-gray-550">
                <div>
                  <span className="block font-semibold">Weight:</span>
                  <span className="font-mono text-gray-900 font-bold">{formatWeight(row.totalWeight)}</span>
                </div>
                <div>
                  <span className="block font-semibold">Sale Value:</span>
                  <span className="font-mono text-emerald-600 font-bold">{formatCurrency(row.totalPrice, row.region)}</span>
                </div>
              </div>
            </div>
          )}
        />
      )}

      {/* Sale Details Modal */}
      {selectedSale && (
        <Modal
          isOpen={isDetailOpen}
          onClose={() => setIsDetailOpen(false)}
          title={`Sale Invoice: ${selectedSale.transactionCode}`}
          size="lg"
        >
          <div className="space-y-6">
            
            {/* Top overview metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200 text-xs">
              <div>
                <span className="block text-gray-400 font-bold uppercase tracking-wider mb-0.5">Invoice Date</span>
                <span className="font-semibold text-gray-800">{new Date(selectedSale.timestamp).toLocaleString()}</span>
              </div>
              <div>
                <span className="block text-gray-400 font-bold uppercase tracking-wider mb-0.5">Operational Region</span>
                <Badge variant={selectedSale.region === 'uk' ? 'uk' : 'pakistan'} className="mt-0.5">
                  {selectedSale.region === 'uk' ? 'United Kingdom' : 'Pakistan'}
                </Badge>
              </div>
              <div>
                <span className="block text-gray-400 font-bold uppercase tracking-wider mb-0.5">Cashier</span>
                <span className="font-semibold text-gray-800 uppercase">{selectedSale.staffName}</span>
              </div>
              <div>
                <span className="block text-gray-400 font-bold uppercase tracking-wider mb-0.5">Invoice Status</span>
                <Badge variant={selectedSale.isVoided ? 'danger' : 'success'} className="mt-0.5">
                  {selectedSale.isVoided ? 'Voided / Cancelled' : 'Completed'}
                </Badge>
              </div>
            </div>

            {/* Sold Items Table */}
            <div>
              <h4 className="text-sm font-bold text-gray-900 mb-2">Sold Items Details</h4>
              <div className="border border-gray-200 rounded-md overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200 text-xs text-left">
                  <thead className="bg-gray-50 text-gray-500 font-bold">
                    <tr>
                      <th className="px-4 py-2">Tag Code</th>
                      <th className="px-4 py-2">Category Name</th>
                      <th className="px-4 py-2 text-right">Weight (g)</th>
                      <th className="px-4 py-2 text-right">Quantity</th>
                      <th className="px-4 py-2 text-right">Price per gram</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {selectedSale.items.map((item, idx) => (
                      <tr key={idx}>
                        <td className="px-4 py-2.5 font-mono font-bold text-gray-700">{item.tagCode}</td>
                        <td className="px-4 py-2.5 font-medium text-gray-900">{item.categoryName}</td>
                        <td className="px-4 py-2.5 text-right font-mono">{formatWeight(item.weight_grams)}</td>
                        <td className="px-4 py-2.5 text-right font-mono">{item.quantity}</td>
                        <td className="px-4 py-2.5 text-right font-mono text-emerald-600">
                          {formatCurrency(item.price_per_gram, selectedSale.region)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Sums overview */}
            <div className="flex flex-col items-end gap-1.5 border-t border-gray-200 pt-4">
              <div className="text-xs text-gray-500 font-medium">
                Total Weight: <span className="font-mono text-gray-900 font-bold ml-1">{formatWeight(selectedSale.totalWeight)}</span>
              </div>
              <div className="text-xs text-gray-500 font-medium">
                Total Items: <span className="font-mono text-gray-900 font-bold ml-1">{selectedSale.totalQty || selectedSale.items.reduce((s,i)=>s+i.quantity,0)} pieces</span>
              </div>
              <div className="text-sm font-bold text-gray-800 flex items-center">
                Invoice Total: 
                <span className="font-mono text-emerald-600 font-extrabold text-base ml-2">
                  {formatCurrency(selectedSale.totalPrice, selectedSale.region)}
                </span>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex justify-between items-center pt-4 border-t border-gray-200">
              <div>
                {!selectedSale.isVoided && (user?.role === 'owner' || user?.role === 'manager') && (
                  <Button
                    variant="danger"
                    loading={voiding}
                    onClick={handleVoidSaleClick}
                    className="flex items-center gap-1.5 cursor-pointer"
                  >
                    <AlertTriangle className="h-4 w-4" /> Void Sale
                  </Button>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsDetailOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>

          </div>
        </Modal>
      )}

      {/* Void Confirmation dialog */}
      <Modal
        isOpen={voidConfirmOpen}
        onClose={() => setVoidConfirmOpen(false)}
        title="Void Sale Confirmation"
        size="sm"
      >
        <div className="space-y-4">
          <div className="flex items-start gap-2.5 p-3 bg-red-50 text-red-800 rounded border border-red-200">
            <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5 text-red-500" />
            <div className="text-xs">
              <span className="font-bold block mb-1">CRITICAL SYSTEM ACTION:</span>
              Voiding this sale will restore the exact weights and quantities back into inventory stock. This cannot be undone.
            </div>
          </div>
          <p className="text-sm text-gray-600">
            Are you sure you want to void sale <strong className="font-mono">{selectedSale?.transactionCode}</strong>?
          </p>
          <div className="flex justify-end gap-3 pt-3">
            <Button variant="outline" onClick={() => setVoidConfirmOpen(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleConfirmVoid}>
              Yes, Void Sale
            </Button>
          </div>
        </div>
      </Modal>

    </Layout>
  );
}

export default SaleHistoryPage;
