import React, { useState, useEffect, useMemo } from 'react';
import { Users, Plus, Edit2, ToggleLeft, ToggleRight, Check, X, ShieldAlert, Key } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Alert from '../components/common/Alert';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import api from '../services/api';

const MOCK_USERS_KEY = 'mock_users';
const defaultUsers = [
  { id: 'user-1', fullName: 'Super Admin', email: 'owner@jewellery.com', role: 'owner', regionAccess: 'both', isActive: true, lastLoginAt: '2026-06-03T10:30:00Z' },
  { id: 'user-2', fullName: 'UK Cashier Ahmed', email: 'cashier_uk@jewellery.com', role: 'cashier', regionAccess: 'uk', isActive: true, lastLoginAt: '2026-06-03T14:30:00Z' },
  { id: 'user-3', fullName: 'PK Manager Aman', email: 'manager_pk@jewellery.com', role: 'manager', regionAccess: 'pakistan', isActive: true, lastLoginAt: '2026-06-02T11:15:00Z' }
];

export function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Add User States
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [addName, setAddName] = useState('');
  const [addEmail, setAddEmail] = useState('');
  const [addPassword, setAddPassword] = useState('');
  const [addRole, setAddRole] = useState('cashier');
  const [addRegion, setAddRegion] = useState('uk');
  const [addErrors, setAddErrors] = useState({});
  const [addLoading, setAddLoading] = useState(false);

  // Edit User States
  const [editingUser, setEditingUser] = useState(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState('cashier');
  const [editRegion, setEditRegion] = useState('uk');
  const [editErrors, setEditErrors] = useState({});
  const [editLoading, setEditLoading] = useState(false);

  // Reset Password States
  const [resettingUser, setResettingUser] = useState(null);
  const [newPassword, setNewPassword] = useState('');
  const [resetErrors, setResetErrors] = useState({});
  const [resetLoading, setResetLoading] = useState(false);

  const getStoredUsers = () => {
    const data = sessionStorage.getItem(MOCK_USERS_KEY);
    if (!data) {
      sessionStorage.setItem(MOCK_USERS_KEY, JSON.stringify(defaultUsers));
      return defaultUsers;
    }
    return JSON.parse(data);
  };

  const fetchUsers = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/users');
      setUsers(response.data);
    } catch (err) {
      if (err.code === 'ERR_NETWORK' || !err.response) {
        setUsers(getStoredUsers());
      } else {
        setError('Failed to fetch user list');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Password strength calculator
  const passwordStrength = useMemo(() => {
    if (!addPassword) return { label: 'Empty', color: 'bg-gray-200', score: 0 };
    let score = 0;
    if (addPassword.length >= 8) score++;
    if (/[A-Z]/.test(addPassword)) score++;
    if (/[0-9]/.test(addPassword)) score++;
    if (/[^A-Za-z0-9]/.test(addPassword)) score++;

    if (score <= 1) return { label: 'Weak', color: 'bg-rose-500 w-1/3', score };
    if (score === 2 || score === 3) return { label: 'Medium', color: 'bg-amber-500 w-2/3', score };
    return { label: 'Strong', color: 'bg-emerald-500 w-full', score };
  }, [addPassword]);

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    setAddErrors({});

    const errs = {};
    if (!addName) errs.name = 'Full Name is required';
    
    if (!addEmail) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(addEmail)) {
      errs.email = 'Please enter a valid email format';
    } else if (users.some(u => u.email.toLowerCase() === addEmail.toLowerCase())) {
      errs.email = 'This email is already registered';
    }

    if (!addPassword) {
      errs.password = 'Password is required';
    } else if (addPassword.length < 8) {
      errs.password = 'Password must be at least 8 characters long';
    }

    if (Object.keys(errs).length > 0) {
      setAddErrors(errs);
      return;
    }

    setAddLoading(true);
    try {
      const newUser = {
        fullName: addName,
        email: addEmail,
        password: addPassword,
        role: addRole,
        regionAccess: addRegion
      };

      try {
        await api.post('/users', newUser);
      } catch (err) {
        if (err.code !== 'ERR_NETWORK') throw err;
        
        // Mock fallback
        const list = getStoredUsers();
        const created = {
          id: 'user-' + Date.now(),
          fullName: addName,
          email: addEmail,
          role: addRole,
          regionAccess: addRegion,
          isActive: true,
          lastLoginAt: null
        };
        list.push(created);
        sessionStorage.setItem(MOCK_USERS_KEY, JSON.stringify(list));
      }

      alert('User added successfully!');
      setIsAddOpen(false);
      setAddName('');
      setAddEmail('');
      setAddPassword('');
      setAddRole('cashier');
      setAddRegion('uk');
      fetchUsers();
    } catch (err) {
      alert(err.message || 'Failed to create user');
    } finally {
      setAddLoading(false);
    }
  };

  const handleEditClick = (row) => {
    setEditingUser(row);
    setEditName(row.fullName);
    setEditRole(row.role);
    setEditRegion(row.regionAccess);
    setEditErrors({});
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setEditErrors({});

    if (!editName) {
      setEditErrors({ name: 'Full Name is required' });
      return;
    }

    setEditLoading(true);
    try {
      try {
        await api.patch(`/users/${editingUser.id}`, {
          fullName: editName,
          role: editRole,
          regionAccess: editRegion
        });
      } catch (err) {
        if (err.code !== 'ERR_NETWORK') throw err;

        // Mock fallback
        const list = getStoredUsers();
        const idx = list.findIndex(u => u.id === editingUser.id);
        if (idx > -1) {
          list[idx].fullName = editName;
          list[idx].role = editRole;
          list[idx].regionAccess = editRegion;
          sessionStorage.setItem(MOCK_USERS_KEY, JSON.stringify(list));
        }
      }

      alert('User details updated successfully!');
      setEditingUser(null);
      fetchUsers();
    } catch (err) {
      alert(err.message || 'Failed to update user');
    } finally {
      setEditLoading(false);
    }
  };

  const handleDeactivate = async (u, isActive) => {
    const actionStr = isActive ? 'deactivate' : 'reactivate';
    if (!window.confirm(`Are you sure you want to ${actionStr} user ${u.fullName}?`)) return;

    try {
      try {
        if (isActive) {
          await api.patch(`/users/${u.id}/deactivate`);
        } else {
          await api.patch(`/users/${u.id}/reactivate`);
        }
      } catch (err) {
        if (err.code !== 'ERR_NETWORK') throw err;

        // Mock fallback
        const list = getStoredUsers();
        const idx = list.findIndex(item => item.id === u.id);
        if (idx > -1) {
          list[idx].isActive = !isActive;
          sessionStorage.setItem(MOCK_USERS_KEY, JSON.stringify(list));
        }
      }

      alert(`User account ${isActive ? 'deactivated' : 'reactivated'} successfully!`);
      fetchUsers();
    } catch (err) {
      alert(err.message || 'Action failed');
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setResetErrors({});

    if (!newPassword || newPassword.length < 8) {
      setResetErrors({ password: 'Password must be at least 8 characters long' });
      return;
    }

    setResetLoading(true);
    try {
      try {
        await api.patch(`/users/${resettingUser.id}/password`, { password: newPassword });
      } catch (e) {
        // Mock success
      }
      alert('User password has been reset successfully!');
      setResettingUser(null);
      setNewPassword('');
    } catch (err) {
      alert('Failed to reset password');
    } finally {
      setResetLoading(false);
    }
  };

  const columns = [
    { key: 'fullName', header: 'Full Name', sortable: true },
    { key: 'email', header: 'Email Address', sortable: true },
    { 
      key: 'role', 
      header: 'Role', 
      sortable: true,
      render: (row) => <span className="font-semibold text-gray-700 capitalize">{row.role}</span>
    },
    { 
      key: 'regionAccess', 
      header: 'Region Access', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.regionAccess === 'both' ? 'primary' : row.regionAccess === 'uk' ? 'uk' : 'pakistan'}>
          {row.regionAccess === 'both' ? 'Both Regions' : row.regionAccess === 'uk' ? 'UK' : 'Pakistan'}
        </Badge>
      )
    },
    { 
      key: 'isActive', 
      header: 'Status', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.isActive ? 'success' : 'danger'}>
          {row.isActive ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <div className="flex gap-2">
          <button
            onClick={() => handleEditClick(row)}
            className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer"
            title="Edit User Info"
          >
            <Edit2 className="h-4 w-4" />
          </button>
          <button
            onClick={() => { setResettingUser(row); setResetErrors({}); }}
            className="text-amber-500 hover:text-amber-700 p-1 cursor-pointer"
            title="Reset Password"
          >
            <Key className="h-4 w-4" />
          </button>
          {row.email !== 'owner@jewellery.com' && (
            <button
              onClick={() => handleDeactivate(row, row.isActive)}
              className={`p-1 cursor-pointer ${row.isActive ? 'text-rose-500 hover:text-rose-700' : 'text-emerald-500 hover:text-emerald-700'}`}
              title={row.isActive ? 'Deactivate User' : 'Reactivate User'}
            >
              {row.isActive ? <ToggleLeft className="h-5 w-5" /> : <ToggleRight className="h-5 w-5" />}
            </button>
          )}
        </div>
      )
    }
  ];

  return (
    <Layout title="User Management" allowedRoles={['owner']} showRegionSelector={false}>
      
      <div className="flex justify-between items-center mb-6">
        <p className="text-xs text-gray-500 max-w-md my-0">
          Admin dashboard to manage staff, assign roles (Owner, Manager, Cashier), and restrict regional store access.
        </p>
        <button
          onClick={() => setIsAddOpen(true)}
          className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white px-5 py-2.5 rounded-md text-sm font-semibold shadow-sm transition-colors cursor-pointer h-[44px]"
        >
          <Plus className="h-4 w-4" /> Add New User
        </button>
      </div>

      {error && <Alert type="error" message={error} className="mb-6" />}

      {loading ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <Table
          columns={columns}
          data={users}
          emptyMessage="No users registered in the system."
          mobileCardRender={(row) => (
            <div className={`space-y-3 ${!row.isActive ? 'opacity-65' : ''}`}>
              <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                <span className="font-semibold text-gray-800 text-sm">{row.fullName}</span>
                <span className="text-xs text-gray-400 capitalize">{row.role}</span>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span className="truncate max-w-[150px]">{row.email}</span>
                <Badge variant={row.regionAccess === 'both' ? 'primary' : row.regionAccess === 'uk' ? 'uk' : 'pakistan'}>
                  {row.regionAccess === 'both' ? 'Both' : row.regionAccess === 'uk' ? 'UK' : 'PK'}
                </Badge>
              </div>
              <div className="pt-2 border-t border-gray-105 flex justify-between items-center text-xs">
                <Badge variant={row.isActive ? 'success' : 'danger'}>
                  {row.isActive ? 'Active' : 'Inactive'}
                </Badge>
                <div className="flex gap-2">
                  <button onClick={() => handleEditClick(row)} className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer">
                    <Edit2 className="h-4 w-4" />
                  </button>
                  <button onClick={() => { setResettingUser(row); setResetErrors({}); }} className="text-amber-500 hover:text-amber-700 p-1 cursor-pointer">
                    <Key className="h-4 w-4" />
                  </button>
                  {row.email !== 'owner@jewellery.com' && (
                    <button onClick={() => handleDeactivate(row, row.isActive)} className={row.isActive ? 'text-rose-500' : 'text-emerald-500'}>
                      {row.isActive ? <ToggleLeft className="h-5 w-5" /> : <ToggleRight className="h-5 w-5" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        />
      )}

      {/* Add New User Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Add New User Account"
        size="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-4">
          <Input
            label="Full Name"
            id="addName"
            placeholder="e.g. John Doe"
            value={addName}
            onChange={(e) => setAddName(e.target.value)}
            error={addErrors.name}
            required
          />

          <Input
            label="Email Address"
            id="addEmail"
            type="email"
            placeholder="john@jewellery.com"
            value={addEmail}
            onChange={(e) => setAddEmail(e.target.value)}
            error={addErrors.email}
            required
          />

          <div className="space-y-1">
            <Input
              label="Account Password (8+ characters)"
              id="addPassword"
              type="password"
              placeholder="••••••••"
              value={addPassword}
              onChange={(e) => setAddPassword(e.target.value)}
              error={addErrors.password}
              required
            />
            {addPassword && (
              <div className="text-xs space-y-1 bg-gray-50 p-2 rounded border border-gray-200">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-gray-500">Strength:</span>
                  <span className="font-bold text-gray-700">{passwordStrength.label}</span>
                </div>
                <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full ${passwordStrength.color} transition-all duration-300`} />
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="addRole" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Staff Role
              </label>
              <select
                id="addRole"
                value={addRole}
                onChange={(e) => setAddRole(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
              >
                <option value="owner">Owner / Admin</option>
                <option value="manager">Manager</option>
                <option value="cashier">Cashier</option>
              </select>
            </div>

            <div>
              <label htmlFor="addRegion" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Region Access
              </label>
              <select
                id="addRegion"
                value={addRegion}
                onChange={(e) => setAddRegion(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
              >
                <option value="both">Both Regions</option>
                <option value="uk">UK</option>
                <option value="pakistan">Pakistan</option>
              </select>
            </div>
          </div>

          <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
            <Button variant="outline" onClick={() => setIsAddOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={addLoading}>
              Create Account
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit User Modal */}
      {editingUser && (
        <Modal
          isOpen={!!editingUser}
          onClose={() => setEditingUser(null)}
          title={`Edit User Account: ${editingUser.fullName}`}
          size="md"
        >
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <Input
              label="Email Address (Disabled)"
              id="editEmail"
              value={editingUser.email}
              disabled
            />

            <Input
              label="Full Name"
              id="editName"
              placeholder="Name..."
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              error={editErrors.name}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="editRole" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  Staff Role
                </label>
                <select
                  id="editRole"
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none h-[44px]"
                >
                  <option value="owner">Owner / Admin</option>
                  <option value="manager">Manager</option>
                  <option value="cashier">Cashier</option>
                </select>
              </div>

              <div>
                <label htmlFor="editRegion" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  Region Access
                </label>
                <select
                  id="editRegion"
                  value={editRegion}
                  onChange={(e) => setEditRegion(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none h-[44px]"
                >
                  <option value="both">Both Regions</option>
                  <option value="uk">UK</option>
                  <option value="pakistan">Pakistan</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
              <Button variant="outline" onClick={() => setEditingUser(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={editLoading}>
                Save Changes
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Reset Password Modal */}
      {resettingUser && (
        <Modal
          isOpen={!!resettingUser}
          onClose={() => setResettingUser(null)}
          title={`Reset Password for ${resettingUser.fullName}`}
          size="sm"
        >
          <form onSubmit={handleResetPassword} className="space-y-4">
            <Input
              label="New Password (8+ characters)"
              id="newPassword"
              type="password"
              placeholder="••••••••"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              error={resetErrors.password}
              required
            />
            <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
              <Button variant="outline" onClick={() => setResettingUser(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={resetLoading}>
                Reset Password
              </Button>
            </div>
          </form>
        </Modal>
      )}

    </Layout>
  );
}

export default UsersPage;
