import React, { useState, useEffect } from 'react';
import { Calendar, Download, RefreshCw, FileSpreadsheet, FileText } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Table from '../components/common/Table';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';
import { reportService } from '../services/reportService';
import { formatWeight } from '../utils/formatWeight';

export function StockReportPage() {
  const [region, setRegion] = useState('both');
  const [asOfDate, setAsOfDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchReport = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await reportService.getStockLevels({
        region,
        asOfDate
      });
      setData(result);
    } catch (err) {
      console.error(err);
      setError('Failed to generate stock report');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [region, asOfDate]);

  const handleExport = async (format) => {
    try {
      await reportService.exportReport('stock-levels', format, { region, asOfDate });
    } catch (err) {
      alert('Export failed');
    }
  };

  const columns = [
    { 
      key: 'tagCode', 
      header: 'Tag Code', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-gray-800">{row.tagCode}</span>
    },
    { key: 'categoryName', header: 'Category Name', sortable: true },
    { 
      key: 'totalWeightAdded', 
      header: 'Total Added (g)', 
      sortable: true,
      render: (row) => <span className="font-mono text-gray-650">{formatWeight(row.totalWeightAdded)}</span>
    },
    { 
      key: 'totalWeightSold', 
      header: 'Total Sold (g)', 
      sortable: true,
      render: (row) => <span className="font-mono text-gray-650">{formatWeight(row.totalWeightSold)}</span>
    },
    { 
      key: 'availableWeight', 
      header: 'Available Stock (g)', 
      sortable: true,
      render: (row) => (
        <span className="font-mono font-extrabold text-emerald-600">
          {formatWeight(row.availableWeight || (row.totalWeightAdded - row.totalWeightSold))}
        </span>
      )
    },
    { 
      key: 'currentQty', 
      header: 'Quantity (pcs)', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-gray-900">{row.currentQty}</span>
    },
    { 
      key: 'lastActivityDate', 
      header: 'Last Activity', 
      sortable: true,
      render: (row) => <span>{new Date(row.lastActivityDate).toLocaleDateString()}</span>
    }
  ];

  return (
    <Layout title="Stock Levels Report" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={true}>
      
      {/* Filtering options bar */}
      <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-xs mb-6 flex flex-col md:flex-row gap-4 justify-between items-end">
        <div className="w-full md:max-w-xs">
          <label htmlFor="report-as-of-date" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
            As of Date
          </label>
          <input
            type="date"
            id="report-as-of-date"
            value={asOfDate}
            onChange={(e) => setAsOfDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
          />
        </div>

        {/* Exporters */}
        <div className="flex gap-2 w-full md:w-auto">
          <Button
            variant="outline"
            onClick={() => handleExport('excel')}
            className="w-full md:w-auto flex items-center justify-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" /> Export Excel
          </Button>
          <Button
            variant="outline"
            onClick={() => handleExport('pdf')}
            className="w-full md:w-auto flex items-center justify-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileText className="h-4 w-4 text-red-500" /> Export PDF
          </Button>
        </div>
      </div>

      {error && (
        <Alert type="error" message={error} className="mb-6" />
      )}

      {loading ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <Table
          columns={columns}
          data={data}
          emptyMessage="No stock data compiled for this report filter."
          mobileCardRender={(row) => (
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                <span className="font-semibold text-gray-800 text-sm">{row.categoryName}</span>
                <span className="font-mono text-xs font-bold text-gray-500 bg-gray-105 px-1.5 py-0.5 rounded">{row.tagCode}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="block font-semibold text-gray-500">Added Wt:</span>
                  <span className="font-mono text-gray-800">{formatWeight(row.totalWeightAdded)}</span>
                </div>
                <div>
                  <span className="block font-semibold text-gray-500">Sold Wt:</span>
                  <span className="font-mono text-gray-800">{formatWeight(row.totalWeightSold)}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs pt-2 border-t border-gray-105">
                <div>
                  <span className="block font-bold text-[#D4AF37]">Available Wt:</span>
                  <span className="font-mono text-emerald-600 font-extrabold">{formatWeight(row.availableWeight)}</span>
                </div>
                <div>
                  <span className="block font-semibold text-gray-500">Available Qty:</span>
                  <span className="font-mono text-gray-950 font-bold">{row.currentQty} pieces</span>
                </div>
              </div>
            </div>
          )}
        />
      )}

    </Layout>
  );
}

export default StockReportPage;
