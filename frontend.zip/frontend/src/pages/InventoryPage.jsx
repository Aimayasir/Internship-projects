import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Eye, History, Sparkles } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Table from '../components/common/Table';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Modal from '../components/common/Modal';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';
import { inventoryService } from '../services/inventoryService';
import { formatWeight } from '../utils/formatWeight';

export function InventoryPage() {
  const navigate = useNavigate();
  const [region, setRegion] = useState('both');
  const [searchQuery, setSearchQuery] = useState('');
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Modal detail states
  const [selectedItem, setSelectedItem] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const fetchInventory = async (r = region) => {
    setLoading(true);
    setError('');
    try {
      const data = await inventoryService.getInventory(r);
      setInventory(data);
    } catch (err) {
      console.error(err);
      setError('Unable to load inventory data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, [region]);

  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      const matchSearch = 
        item.categoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tagCode.toLowerCase().includes(searchQuery.toLowerCase());
      return matchSearch;
    });
  }, [inventory, searchQuery]);

  const handleRowClick = (item) => {
    setSelectedItem(item);
    setIsDetailOpen(true);
  };

  const columns = [
    { 
      key: 'tagCode', 
      header: 'Tag Code', 
      sortable: true,
      rightAlign: true,
      render: (row) => <span className="font-mono font-bold text-gray-800">{row.tagCode}</span>
    },
    { key: 'categoryName', header: 'Category Name', sortable: true },
    { 
      key: 'totalWeight', 
      header: 'Total Weight (g)', 
      sortable: true,
      render: (row) => <span className="font-mono text-gray-900">{formatWeight(row.totalWeight)}</span>
    },
    { 
      key: 'totalQty', 
      header: 'Total Quantity', 
      sortable: true,
      render: (row) => <span className="font-mono font-bold">{row.totalQty.toLocaleString()}</span>
    },
    { 
      key: 'region', 
      header: 'Region', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.region === 'uk' ? 'uk' : 'pakistan'}>
          {row.region === 'uk' ? 'UK' : 'Pakistan'}
        </Badge>
      )
    }
  ];

  return (
    <Layout title="Inventory" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={true}>
      
      {/* Search Bar & Actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-6">
        
        {/* Search input */}
        <div className="relative w-full sm:max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search className="h-5 w-5" />
          </span>
          <input
            type="text"
            id="inventory-search"
            placeholder="Search by category name or tag..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px] transition-colors"
          />
        </div>

        {/* Quick add */}
        <button
          onClick={() => navigate('/add-stock')}
          className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white px-5 py-2.5 rounded-md text-sm font-semibold shadow-sm transition-colors w-full sm:w-auto justify-center cursor-pointer h-[44px]"
        >
          <Plus className="h-4 w-4" /> Add Stock Entry
        </button>

      </div>

      {error && (
        <Alert type="error" message={error} className="mb-6" />
      )}

      {loading ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <Table
          columns={columns}
          data={filteredInventory}
          onRowClick={handleRowClick}
          emptyMessage="No inventory items found matching your filters"
          mobileCardRender={(row) => (
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                <span className="font-mono font-bold text-gray-800 text-sm bg-gray-105 px-2 py-0.5 rounded">
                  {row.tagCode}
                </span>
                <Badge variant={row.region === 'uk' ? 'uk' : 'pakistan'}>
                  {row.region === 'uk' ? 'UK' : 'Pakistan'}
                </Badge>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="font-semibold text-gray-800">{row.categoryName}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs pt-1 border-t border-gray-105 text-gray-500">
                <div>
                  <span className="block font-semibold">Weight:</span>
                  <span className="font-mono text-gray-900 font-bold">{formatWeight(row.totalWeight)}</span>
                </div>
                <div>
                  <span className="block font-semibold">Quantity:</span>
                  <span className="font-mono text-gray-900 font-bold">{row.totalQty} pieces</span>
                </div>
              </div>
            </div>
          )}
        />
      )}

      {/* Row Details Modal */}
      {selectedItem && (
        <Modal
          isOpen={isDetailOpen}
          onClose={() => setIsDetailOpen(false)}
          title={`Category Stock: ${selectedItem.categoryName}`}
          size="md"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div>
                <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Tag Code</span>
                <span className="text-lg font-mono font-bold text-gray-900">{selectedItem.tagCode}</span>
              </div>
              <div>
                <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Operational Region</span>
                <Badge variant={selectedItem.region === 'uk' ? 'uk' : 'pakistan'} className="mt-1">
                  {selectedItem.region === 'uk' ? 'United Kingdom' : 'Pakistan'}
                </Badge>
              </div>
              <div className="mt-2">
                <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Available Weight</span>
                <span className="text-lg font-mono font-extrabold text-emerald-600">
                  {formatWeight(selectedItem.totalWeight)}
                </span>
              </div>
              <div className="mt-2">
                <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Available Quantity</span>
                <span className="text-lg font-mono font-bold text-gray-900">
                  {selectedItem.totalQty} items
                </span>
              </div>
            </div>

            <div className="flex gap-3 justify-end pt-4 border-t border-gray-200">
              <Button
                variant="outline"
                onClick={() => setIsDetailOpen(false)}
                className="w-full sm:w-auto"
              >
                Close
              </Button>
              <Button
                variant="primary"
                onClick={() => {
                  setIsDetailOpen(false);
                  navigate('/add-stock', { 
                    state: { 
                      categoryId: selectedItem.categoryId,
                      region: selectedItem.region 
                    } 
                  });
                }}
                className="w-full sm:w-auto"
              >
                <Plus className="h-4 w-4 mr-2" /> Add Stock
              </Button>
            </div>
          </div>
        </Modal>
      )}

    </Layout>
  );
}

export default InventoryPage;
