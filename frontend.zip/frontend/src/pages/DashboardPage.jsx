import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, 
  ShoppingBag, 
  FileText, 
  Coins, 
  Activity, 
  AlertTriangle, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import StockBarChart from '../components/charts/StockBarChart';
import Spinner from '../components/common/Spinner';
import Alert from '../components/common/Alert';
import Badge from '../components/common/Badge';
import { inventoryService } from '../services/inventoryService';
import { salesService } from '../services/salesService';
import { fineGoldService } from '../services/fineGoldService';
import { formatWeight } from '../utils/formatWeight';
import { formatCurrency } from '../utils/formatCurrency';

export function DashboardPage() {
  const navigate = useNavigate();
  const [region, setRegion] = useState('both');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Dashboard state
  const [inventory, setInventory] = useState([]);
  const [todaySales, setTodaySales] = useState({ count: 0, weight: 0 });
  const [goldSummaryUk, setGoldSummaryUk] = useState(null);
  const [goldSummaryPk, setGoldSummaryPk] = useState(null);

  const fetchData = useCallback(async (r = region) => {
    setLoading(true);
    setError('');
    try {
      // 1. Fetch Inventory
      const invData = await inventoryService.getInventory(r);
      setInventory(invData);

      // 2. Fetch Today's Sales
      const today = new Date().toISOString().split('T')[0];
      const salesData = await salesService.getSales({
        region: r,
        fromDate: today,
        toDate: today
      });
      
      const count = salesData.length;
      const weight = salesData.reduce((sum, item) => sum + (item.totalWeight || 0), 0);
      setTodaySales({ count, weight });

      // 3. Fetch Fine Gold Summary
      if (r === 'both') {
        const goldUk = await fineGoldService.getSummary('uk');
        const goldPk = await fineGoldService.getSummary('pakistan');
        setGoldSummaryUk(goldUk);
        setGoldSummaryPk(goldPk);
      } else if (r === 'uk') {
        const goldUk = await fineGoldService.getSummary('uk');
        setGoldSummaryUk(goldUk);
        setGoldSummaryPk(null);
      } else {
        const goldPk = await fineGoldService.getSummary('pakistan');
        setGoldSummaryPk(goldPk);
        setGoldSummaryUk(null);
      }

    } catch (err) {
      console.error(err);
      setError('Unable to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, [region]);

  useEffect(() => {
    fetchData();
    // Auto refresh every 30 seconds
    const interval = setInterval(() => {
      fetchData();
    }, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Aggregate stats
  const stats = React.useMemo(() => {
    let ukWeight = 0;
    let pkWeight = 0;
    
    inventory.forEach(item => {
      if (item.region === 'uk') {
        ukWeight += item.totalWeight;
      } else if (item.region === 'pakistan') {
        pkWeight += item.totalWeight;
      }
    });

    // Gold
    let goldGrams = 0;
    let goldValue = 0;
    let goldCurrencyRegion = 'uk';

    if (region === 'both') {
      goldGrams = (goldSummaryUk?.availableGrams || 0) + (goldSummaryPk?.availableGrams || 0);
      goldValue = (goldSummaryUk?.totalValue || 0) + (goldSummaryPk?.totalValue || 0); // mixed currencies, but will represent overall scale
      goldCurrencyRegion = 'uk'; // Default format
    } else if (region === 'uk') {
      goldGrams = goldSummaryUk?.availableGrams || 0;
      goldValue = goldSummaryUk?.totalValue || 0;
      goldCurrencyRegion = 'uk';
    } else {
      goldGrams = goldSummaryPk?.availableGrams || 0;
      goldValue = goldSummaryPk?.totalValue || 0;
      goldCurrencyRegion = 'pakistan';
    }

    return {
      ukWeight,
      pkWeight,
      goldGrams,
      goldValue,
      goldCurrencyRegion
    };
  }, [inventory, region, goldSummaryUk, goldSummaryPk]);

  // Low Stock Logic
  const minStockThreshold = 10;
  const lowStockAlerts = React.useMemo(() => {
    const alerts = [];
    inventory.forEach(item => {
      if (item.totalQty <= minStockThreshold) {
        alerts.push({
          categoryName: item.categoryName,
          region: item.region,
          qty: item.totalQty
        });
      }
    });
    return alerts;
  }, [inventory]);

  const handleRegionChange = (newRegion) => {
    setRegion(newRegion);
  };

  return (
    <Layout title="Dashboard" selectedRegion={region} onRegionChange={handleRegionChange} showRegionSelector={true}>
      {error && (
        <div className="mb-6 flex gap-4 items-center">
          <Alert type="error" message={error} className="flex-1" />
          <button 
            onClick={() => fetchData()}
            className="px-4 py-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white text-sm font-semibold rounded-md transition-colors"
          >
            Retry
          </button>
        </div>
      )}

      {loading && inventory.length === 0 ? (
        <div className="h-[400px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <div className="space-y-8 animate-fade-in">
          
          {/* Quick Actions Buttons */}
          <div className="flex flex-wrap items-center gap-4 bg-white p-4 rounded-lg border border-gray-200 shadow-xs">
            <h3 className="text-sm font-bold text-gray-800 mr-2">Quick Actions:</h3>
            <button
              onClick={() => navigate('/add-stock')}
              className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#C59B27] text-white px-4 py-2 rounded-md text-sm font-semibold shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="h-4 w-4" /> Add Stock
            </button>
            <button
              onClick={() => navigate('/pos')}
              className="flex items-center gap-2 bg-[#1F2937] hover:bg-[#374151] text-white px-4 py-2 rounded-md text-sm font-semibold shadow-sm transition-colors cursor-pointer"
            >
              <ShoppingBag className="h-4 w-4" /> New Sale
            </button>
            <button
              onClick={() => navigate('/reports')}
              className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-md text-sm font-semibold shadow-sm transition-colors cursor-pointer"
            >
              <FileText className="h-4 w-4" /> View Reports
            </button>
          </div>

          {/* Grid of 4 Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Card 1: Total Weight UK */}
            <div className="bg-white p-6 rounded-lg border-l-4 border-blue-500 border-y border-r border-gray-200 shadow-xs flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Weight (UK)</span>
                <Badge variant="uk">UK Operations</Badge>
              </div>
              <div className="mt-4">
                <span className="text-2xl font-extrabold text-emerald-600 block">
                  {formatWeight(stats.ukWeight)}
                </span>
                <span className="text-xs text-gray-400 font-medium">Available in UK stock</span>
              </div>
            </div>

            {/* Card 2: Total Weight Pakistan */}
            <div className="bg-white p-6 rounded-lg border-l-4 border-emerald-500 border-y border-r border-gray-200 shadow-xs flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Weight (PK)</span>
                <Badge variant="pakistan">PK Operations</Badge>
              </div>
              <div className="mt-4">
                <span className="text-2xl font-extrabold text-emerald-600 block">
                  {formatWeight(stats.pkWeight)}
                </span>
                <span className="text-xs text-gray-400 font-medium">Available in Pakistan stock</span>
              </div>
            </div>

            {/* Card 3: Fine Gold Available */}
            <div className="bg-white p-6 rounded-lg border-l-4 border-[#D4AF37] border-y border-r border-gray-200 shadow-xs flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Fine Gold Available</span>
                <Coins className="h-5 w-5 text-[#D4AF37]" />
              </div>
              <div className="mt-4">
                <span className="text-2xl font-extrabold text-emerald-600 block">
                  {formatWeight(stats.goldGrams)}
                </span>
                <span className="text-xs text-gray-500 font-semibold block">
                  Valued at {formatCurrency(stats.goldValue, stats.goldCurrencyRegion)}
                </span>
              </div>
            </div>

            {/* Card 4: Today's Sales */}
            <div className="bg-white p-6 rounded-lg border-l-4 border-purple-500 border-y border-r border-gray-200 shadow-xs flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Today's Sales</span>
                <Activity className="h-5 w-5 text-purple-500" />
              </div>
              <div className="mt-4">
                <span className="text-2xl font-extrabold text-[#1F2937] block">
                  {todaySales.count} Invoices
                </span>
                <span className="text-xs text-emerald-600 font-bold">
                  Weight: {formatWeight(todaySales.weight)}
                </span>
              </div>
            </div>
          </div>

          {/* Center Content split: Chart (left) and alerts (right) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Chart (takes 2 columns on large screens) */}
            <div className="lg:col-span-2">
              <StockBarChart data={inventory} />
            </div>

            {/* Low Stock Alerts Section */}
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-xs flex flex-col">
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <h3 className="text-base font-bold text-gray-900 my-0">Low Stock Alerts</h3>
              </div>
              
              {lowStockAlerts.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-gray-400">
                  <Sparkles className="h-8 w-8 text-[#D4AF37] mb-2" />
                  <p className="text-sm font-semibold text-gray-600">All stocks are healthy</p>
                  <p className="text-xs">No categories are currently below threshold ({minStockThreshold} pcs)</p>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto max-h-[300px] space-y-3 pr-1">
                  {lowStockAlerts.map((alert, index) => (
                    <div 
                      key={index} 
                      className="p-3 bg-red-50 border border-red-200 rounded-md flex items-center justify-between text-xs"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-gray-800">{alert.categoryName}</span>
                        <span className="text-[10px] text-gray-450 uppercase font-semibold">
                          Region: {alert.region}
                        </span>
                      </div>
                      <Badge variant="danger">
                        {alert.qty} left (Threshold: {minStockThreshold})
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      )}
    </Layout>
  );
}

export default DashboardPage;
