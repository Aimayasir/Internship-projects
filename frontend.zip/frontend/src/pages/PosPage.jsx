import React, { useState, useEffect, useMemo, useRef } from 'react';
import { ShoppingBag, Search, Trash2, Edit2, Check, RefreshCw, X, Printer, Sparkles } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Alert from '../components/common/Alert';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Modal from '../components/common/Modal';
import { useCartStore } from '../store/cartStore';
import { useInventoryStore } from '../store/inventoryStore';
import { useAuth } from '../hooks/useAuth';
import { salesService } from '../services/salesService';
import { formatWeight } from '../utils/formatWeight';
import { formatCurrency } from '../utils/formatCurrency';

export function PosPage() {
  const { user } = useAuth();
  const { items, addItem, removeItem, updateItem, clearCart, getCartTotal } = useCartStore();
  const { inventory, fetchInventory } = useInventoryStore();

  const [region, setRegion] = useState('uk'); // UK is default
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Item Addition Form States
  const [tagSearch, setTagSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [sellWeight, setSellWeight] = useState('');
  const [sellQty, setSellQty] = useState('');
  const [sellPrice, setSellPrice] = useState(''); // Optional custom price per piece or gram
  const [addError, setAddError] = useState('');

  // Cart edit mode states
  const [editingIndex, setEditingIndex] = useState(-1);
  const [editWeight, setEditWeight] = useState('');
  const [editQty, setEditQty] = useState('');

  // Confirmation / Receipt states
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [receipt, setReceipt] = useState(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);

  // Search input ref
  const searchInputRef = useRef(null);

  useEffect(() => {
    fetchInventory('both');
  }, [fetchInventory]);

  // Aggregate current inventory matching selected region
  const regionalInventory = useMemo(() => {
    return inventory.filter(item => item.region === region);
  }, [inventory, region]);

  // Look up categories matching tag search (real-time dropdown)
  const matchingCategories = useMemo(() => {
    if (!tagSearch) return [];
    return regionalInventory.filter(item => 
      item.tagCode.toLowerCase().includes(tagSearch.toLowerCase()) ||
      item.categoryName.toLowerCase().includes(tagSearch.toLowerCase())
    );
  }, [regionalInventory, tagSearch]);

  const handleSelectCategory = (cat) => {
    setSelectedCategory(cat);
    setTagSearch(`${cat.categoryName} (${cat.tagCode})`);
    setSellWeight('');
    setSellQty('');
    setSellPrice(cat.price_per_gram || '50'); // default mock price
    setAddError('');
  };

  const handleAddToCart = (e) => {
    e.preventDefault();
    setAddError('');

    if (!selectedCategory) {
      setAddError('Please select a category first');
      return;
    }

    const weightVal = parseFloat(sellWeight);
    if (isNaN(weightVal) || weightVal <= 0) {
      setAddError('Weight must be greater than 0');
      return;
    }
    if (weightVal > selectedCategory.totalWeight) {
      setAddError(`Only ${formatWeight(selectedCategory.totalWeight)} available, you are trying to sell ${formatWeight(weightVal)}`);
      return;
    }

    const qtyVal = parseInt(sellQty, 10);
    if (isNaN(qtyVal) || qtyVal <= 0 || !Number.isInteger(Number(sellQty))) {
      setAddError('Quantity must be an integer greater than 0');
      return;
    }
    if (qtyVal > selectedCategory.totalQty) {
      setAddError(`Only ${selectedCategory.totalQty} pieces available, you are trying to sell ${qtyVal}`);
      return;
    }

    // Add to Zustand Cart
    const priceVal = parseFloat(sellPrice) || 50; // price per gram fallback
    addItem({
      categoryId: selectedCategory.categoryId,
      tag: selectedCategory.tagCode,
      name: selectedCategory.categoryName,
      weight: weightVal,
      qty: qtyVal,
      price: priceVal // stored as unit price
    });

    // Clear search form
    setSelectedCategory(null);
    setTagSearch('');
    setSellWeight('');
    setSellQty('');
    setSellPrice('');
    setAddError('');

    // Return focus to search input
    if (searchInputRef.current) searchInputRef.current.focus();
  };

  const startEditCartItem = (index, item) => {
    setEditingIndex(index);
    setEditWeight(item.weight);
    setEditQty(item.qty);
  };

  const saveCartItemEdit = (index, item) => {
    const parsedWeight = parseFloat(editWeight);
    const parsedQty = parseInt(editQty, 10);

    // Look up original stock limits
    const originalStock = regionalInventory.find(inv => inv.categoryId === item.categoryId);
    if (!originalStock) {
      alert('Failed to find stock information');
      return;
    }

    if (isNaN(parsedWeight) || parsedWeight <= 0) {
      alert('Weight must be greater than 0');
      return;
    }
    if (parsedWeight > originalStock.totalWeight) {
      alert(`Only ${formatWeight(originalStock.totalWeight)} available`);
      return;
    }

    if (isNaN(parsedQty) || parsedQty <= 0) {
      alert('Quantity must be greater than 0');
      return;
    }
    if (parsedQty > originalStock.totalQty) {
      alert(`Only ${originalStock.totalQty} pieces available`);
      return;
    }

    updateItem(index, parsedWeight, parsedQty);
    setEditingIndex(-1);
  };

  const totals = getCartTotal();

  const handleCheckout = async () => {
    if (items.length === 0) {
      setError('Your shopping cart is empty');
      return;
    }
    setIsConfirmOpen(true);
  };

  const confirmCheckout = async () => {
    setIsConfirmOpen(false);
    setLoading(true);
    setError('');
    
    try {
      const saleData = {
        region,
        items: items.map(item => ({
          categoryId: item.categoryId,
          weight_grams: item.weight,
          quantity: item.qty,
          price_per_gram: item.price
        }))
      };

      const result = await salesService.confirmSale(saleData);
      
      setReceipt(result);
      setSuccess(`Sale Confirmed! Code: ${result.transactionCode}`);
      clearCart();
      setIsReceiptOpen(true);

      // Refresh inventory totals
      await fetchInventory('both');
    } catch (err) {
      setError(err.message || 'Sale checkout failed');
    } finally {
      setLoading(false);
    }
  };

  const printReceipt = () => {
    window.print();
  };

  return (
    <Layout title="Point of Sale" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={items.length === 0}>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 print:hidden">
        
        {/* Left column: Search / Item Input Form (takes 5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs">
            <h3 className="text-base font-bold text-gray-900 border-b border-gray-200 pb-3 mb-4 flex items-center gap-1.5">
              <ShoppingBag className="h-5 w-5 text-[#D4AF37]" /> Sales Counter
            </h3>

            {error && <Alert type="error" message={error} className="mb-4" onClose={() => setError('')} />}
            {success && <Alert type="success" message={success} className="mb-4" onClose={() => setSuccess('')} />}
            {addError && <Alert type="error" message={addError} className="mb-4" onClose={() => setAddError('')} />}

            <form onSubmit={handleAddToCart} className="space-y-4">
              
              {/* Tag Search Input */}
              <div className="relative">
                <label htmlFor="pos-tag-search" className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Search by Tag Code
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                    <Search className="h-4 w-4" />
                  </span>
                  <input
                    ref={searchInputRef}
                    type="text"
                    id="pos-tag-search"
                    placeholder="Type Tag Code e.g. DR..."
                    value={tagSearch}
                    onChange={(e) => {
                      setTagSearch(e.target.value);
                      if (!e.target.value) setSelectedCategory(null);
                    }}
                    className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
                  />
                  {tagSearch && !selectedCategory && matchingCategories.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-gray-200 rounded-md shadow-lg z-50">
                      {matchingCategories.map(cat => (
                        <div
                          key={cat.categoryId}
                          onClick={() => handleSelectCategory(cat)}
                          className="p-3 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer border-b border-gray-50 flex justify-between items-center"
                        >
                          <span className="font-bold text-gray-800">{cat.categoryName}</span>
                          <span className="font-mono text-xs text-gray-500 bg-gray-105 px-1.5 py-0.5 rounded">{cat.tagCode}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Selected category stock indicators */}
              {selectedCategory && (
                <div className="p-4 bg-gray-50 rounded-md border border-gray-200 text-xs space-y-2 animate-fade-in">
                  <div className="flex justify-between font-bold text-gray-800">
                    <span>Category:</span>
                    <span>{selectedCategory.categoryName}</span>
                  </div>
                  <div className="flex justify-between font-bold text-gray-800">
                    <span>Tag Code:</span>
                    <span className="font-mono">{selectedCategory.tagCode}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-200 pt-2 text-gray-600">
                    <span>Available Weight:</span>
                    <span className="font-mono font-bold text-emerald-600">
                      {formatWeight(selectedCategory.totalWeight)}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Available Qty:</span>
                    <span className="font-mono font-bold text-gray-900">
                      {selectedCategory.totalQty} pieces
                    </span>
                  </div>
                </div>
              )}

              {/* Sell Inputs */}
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Weight (g) to Sell"
                  id="sellWeight"
                  type="number"
                  step="any"
                  placeholder="0.000"
                  value={sellWeight}
                  disabled={!selectedCategory}
                  onChange={(e) => setSellWeight(e.target.value)}
                  required
                />
                <Input
                  label="Qty (pcs) to Sell"
                  id="sellQty"
                  type="number"
                  placeholder="0"
                  value={sellQty}
                  disabled={!selectedCategory}
                  onChange={(e) => setSellQty(e.target.value)}
                  required
                />
              </div>

              <Input
                label={region === 'uk' ? 'Price Per Gram (£)' : 'Price Per Gram (Rs)'}
                id="sellPrice"
                type="number"
                placeholder={region === 'uk' ? '50' : '4000'}
                value={sellPrice}
                disabled={!selectedCategory}
                onChange={(e) => setSellPrice(e.target.value)}
              />

              <Button
                type="submit"
                disabled={!selectedCategory}
                className="w-full flex items-center justify-center gap-1.5 h-[44px] cursor-pointer"
              >
                + Add To Cart
              </Button>

            </form>
          </div>
        </div>

        {/* Right column: Cart / Checkout Panel (takes 7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs flex flex-col min-h-[500px]">
            <div className="flex justify-between items-center border-b border-gray-200 pb-3 mb-4">
              <h3 className="text-base font-bold text-gray-900 flex items-center gap-1.5 my-0">
                Shopping Cart
              </h3>
              <Badge variant={region === 'uk' ? 'uk' : 'pakistan'} className="text-sm font-semibold uppercase">
                {region === 'uk' ? 'UK Region' : 'Pakistan Region'}
              </Badge>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto space-y-4 max-h-[320px] pr-1">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-400 py-16">
                  <ShoppingBag className="h-10 w-10 text-gray-300 mb-2" />
                  <p className="text-sm font-bold text-gray-500">Cart is empty</p>
                  <p className="text-xs">Search and add categories in the left panel.</p>
                </div>
              ) : (
                items.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="p-3 border border-gray-200 rounded-md flex items-center justify-between hover:border-gray-300 transition-colors bg-gray-50/50"
                  >
                    {editingIndex === idx ? (
                      // Inline edit form
                      <div className="flex-1 grid grid-cols-2 gap-4 mr-4">
                        <Input
                          label="Edit Weight"
                          id={`edit-weight-${idx}`}
                          type="number"
                          step="any"
                          value={editWeight}
                          onChange={(e) => setEditWeight(e.target.value)}
                          className="mb-0"
                        />
                        <Input
                          label="Edit Qty"
                          id={`edit-qty-${idx}`}
                          type="number"
                          value={editQty}
                          onChange={(e) => setEditQty(e.target.value)}
                          className="mb-0"
                        />
                      </div>
                    ) : (
                      // Summary display
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-gray-600 bg-gray-200 px-1.5 py-0.5 rounded">{item.tag}</span>
                          <span className="font-semibold text-gray-800 text-sm">{item.name}</span>
                        </div>
                        <div className="flex gap-4 mt-1 text-xs text-gray-500">
                          <span>Weight: <strong className="font-mono text-gray-900">{formatWeight(item.weight)}</strong></span>
                          <span>Qty: <strong className="font-mono text-gray-900">{item.qty} pcs</strong></span>
                          <span>Price/g: <strong className="font-mono text-emerald-600">{formatCurrency(item.price, region)}</strong></span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      {editingIndex === idx ? (
                        <>
                          <button
                            onClick={() => saveCartItemEdit(idx, item)}
                            className="p-1.5 bg-emerald-500 text-white rounded hover:bg-emerald-600 cursor-pointer"
                          >
                            <Check className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => setEditingIndex(-1)}
                            className="p-1.5 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 cursor-pointer"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => startEditCartItem(idx, item)}
                            className="p-1.5 text-gray-400 hover:text-gray-600 cursor-pointer"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => removeItem(idx)}
                            className="p-1.5 text-red-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Summary */}
            <div className="border-t border-gray-200 pt-4 mt-4 space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg flex flex-col gap-2">
                <div className="flex justify-between items-center text-xs text-gray-500 font-medium">
                  <span>Subtotal Weight:</span>
                  <span className="font-mono text-gray-900 font-bold">{formatWeight(totals.totalWeight)}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-gray-500 font-medium">
                  <span>Subtotal Items:</span>
                  <span className="font-mono text-gray-900 font-bold">{totals.totalQty} pieces</span>
                </div>
                <div className="flex justify-between items-center border-t border-gray-200 pt-2 text-sm font-bold text-gray-800">
                  <span>Est. Price:</span>
                  <span className="font-mono text-[#D4AF37] text-base font-extrabold">
                    {formatCurrency(totals.totalPrice, region)}
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={clearCart}
                  disabled={items.length === 0}
                  className="w-full flex items-center justify-center gap-1.5 h-[44px]"
                >
                  Clear Cart
                </Button>
                <Button
                  onClick={handleCheckout}
                  disabled={items.length === 0}
                  className="w-full flex items-center justify-center gap-1.5 h-[44px]"
                >
                  Confirm Sale
                </Button>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        title="Confirm Sales Checkout"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Are you sure you want to finalize this transaction? This action will immediately deduct inventory stock.
          </p>
          <div className="p-3 bg-gray-50 rounded-md text-xs space-y-1">
            <div className="flex justify-between">
              <span>Total Weight:</span>
              <strong className="font-mono">{formatWeight(totals.totalWeight)}</strong>
            </div>
            <div className="flex justify-between">
              <span>Total Items:</span>
              <strong className="font-mono">{totals.totalQty} pcs</strong>
            </div>
            <div className="flex justify-between border-t border-gray-200 pt-1 font-bold">
              <span>Total Sale Value:</span>
              <strong className="font-mono text-[#D4AF37]">{formatCurrency(totals.totalPrice, region)}</strong>
            </div>
          </div>
          <div className="flex gap-3 justify-end pt-3">
            <Button variant="outline" onClick={() => setIsConfirmOpen(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button onClick={confirmCheckout} className="w-full sm:w-auto">
              Confirm
            </Button>
          </div>
        </div>
      </Modal>

      {/* Print styled thermal receipt wrapper */}
      {receipt && (
        <div className={`fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 ${isReceiptOpen ? '' : 'hidden'} print:absolute print:inset-0 print:bg-white print:z-50 print:block`}>
          <div className="bg-white rounded-lg shadow-2xl max-w-sm w-full border border-gray-200 overflow-hidden flex flex-col max-h-[90vh] print:max-w-full print:border-none print:shadow-none">
            {/* Header Controls (Hidden on Print) */}
            <div className="flex justify-between items-center px-4 py-3 bg-gray-900 text-white print:hidden">
              <span className="text-xs font-bold flex items-center gap-1.5"><Printer className="h-4 w-4" /> Thermal Print Receipt</span>
              <button onClick={() => setIsReceiptOpen(false)} className="text-gray-400 hover:text-white cursor-pointer font-bold text-lg">&times;</button>
            </div>

            {/* Thermal paper receipts area */}
            <div id="receipt-print-target" className="p-6 bg-white flex-1 overflow-y-auto font-mono text-xs text-gray-900 border-dashed border-2 border-gray-300 m-4 print:border-none print:m-0">
              <div className="text-center space-y-1 mb-4">
                <span className="font-extrabold text-sm uppercase tracking-wider">JEWELLERY SHOP</span>
                <span className="block text-[10px] text-gray-500 uppercase">POS Sales Counter Receipt</span>
                <span className="block border-b border-dashed border-gray-300 pb-2 text-[10px]">
                  Region: {receipt.region === 'uk' ? 'United Kingdom' : 'Pakistan'}
                </span>
              </div>

              <div className="space-y-1 text-[11px] mb-4">
                <div className="flex justify-between">
                  <span>CODE:</span>
                  <span className="font-bold">{receipt.transactionCode}</span>
                </div>
                <div className="flex justify-between">
                  <span>DATE:</span>
                  <span>{new Date(receipt.timestamp).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>STAFF:</span>
                  <span className="uppercase">{user?.full_name || 'Ahmed'}</span>
                </div>
              </div>

              <div className="border-t border-b border-dashed border-gray-300 py-2 text-[11px] mb-4">
                <div className="grid grid-cols-12 gap-1 font-bold border-b border-dashed border-gray-300 pb-1 mb-1">
                  <span className="col-span-6">Item</span>
                  <span className="col-span-3 text-right">Wt(g)</span>
                  <span className="col-span-3 text-right">Qty</span>
                </div>
                {receipt.items.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-1 py-0.5">
                    <span className="col-span-6 truncate font-semibold">{item.categoryName} ({item.tagCode})</span>
                    <span className="col-span-3 text-right font-mono">{formatWeight(item.weight_grams).replace(' g','')}</span>
                    <span className="col-span-3 text-right font-mono">{item.quantity}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-[11px] border-b border-dashed border-gray-300 pb-2 mb-4 font-bold">
                <div className="flex justify-between">
                  <span>TOTAL WT:</span>
                  <span className="font-mono">{formatWeight(receipt.totalWeight)}</span>
                </div>
                <div className="flex justify-between">
                  <span>TOTAL QTY:</span>
                  <span className="font-mono">{receipt.totalQty} items</span>
                </div>
                <div className="flex justify-between border-t border-dashed border-gray-300 pt-1 font-extrabold text-sm text-[#D4AF37]">
                  <span>TOTAL VALUE:</span>
                  <span className="font-mono">{formatCurrency(receipt.totalPrice, receipt.region)}</span>
                </div>
              </div>

              <div className="text-center text-[10px] text-gray-500 mt-6 border-t border-dashed border-gray-200 pt-4">
                <span>THANK YOU FOR YOUR BUSINESS!</span>
              </div>
            </div>

            {/* Actions button (Hidden on Print) */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex gap-3 print:hidden">
              <Button variant="outline" onClick={() => setIsReceiptOpen(false)} className="w-full">
                Close
              </Button>
              <Button onClick={printReceipt} className="w-full flex items-center justify-center gap-1.5">
                <Printer className="h-4 w-4" /> Print Receipt
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}

export default PosPage;
