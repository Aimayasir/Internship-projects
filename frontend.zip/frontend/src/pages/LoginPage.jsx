import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Coins, Sparkles } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Alert from '../components/common/Alert';

export function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState('');
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    const newErrors = {};
    
    // Email Validation
    if (!email) {
      newErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Password Validation
    if (!password) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters long';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError('');
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      await login(email, password);
      // Success toast trigger
      showToast("Login successful", "success");
      navigate('/dashboard');
    } catch (err) {
      setApiError(err.message || 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  // Helper to trigger temporary toasts since they are expected on success
  const showToast = (msg) => {
    const toast = document.createElement('div');
    toast.className = "fixed bottom-5 right-5 bg-emerald-500 text-white font-bold px-4 py-3 rounded-lg shadow-lg z-50 transition-all duration-300 transform translate-y-0";
    toast.innerText = msg;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-[#111827] flex items-center justify-center px-4 py-12">
      {/* Centered card */}
      <div className="max-w-md w-full bg-[#1F2937] rounded-lg shadow-xl overflow-hidden border border-gray-800 p-8">
        
        {/* Branding Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="h-16 w-16 bg-[#D4AF37]/15 rounded-full flex items-center justify-center border border-[#D4AF37]/35 mb-4 animate-bounce">
            <Coins className="h-8 w-8 text-[#D4AF37]" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-wider flex items-center gap-1.5 my-0">
            JEWELLERY <span className="text-[#D4AF37]">POS</span>
          </h1>
          <p className="text-xs text-gray-400 mt-1.5 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-[#D4AF37]" /> Inventory & POS System
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {apiError && (
            <Alert type="error" message={apiError} className="mb-4" onClose={() => setApiError('')} />
          )}

          <Input
            label="Email Address"
            id="email"
            type="email"
            placeholder="admin@jewellery.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            error={errors.email}
            required
            className="bg-gray-900 border-gray-700 text-white focus:border-[#D4AF37] focus:ring-[#D4AF37]"
            labelClassName="text-gray-300"
          />

          <Input
            label="Password"
            id="password"
            type="password"
            placeholder="••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={errors.password}
            required
            className="bg-gray-900 border-gray-700 text-white focus:border-[#D4AF37] focus:ring-[#D4AF37]"
            labelClassName="text-gray-300"
          />

          <div className="flex justify-between items-center text-xs">
            <span className="text-[#D4AF37] hover:underline cursor-pointer">
              Forgot Password?
            </span>
          </div>

          <Button
            type="submit"
            loading={loading}
            variant="primary"
            className="w-full text-base tracking-wide h-[44px] mt-4"
          >
            Sign In
          </Button>
        </form>
      </div>
    </div>
  );
}

export default LoginPage;
