import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileText, 
  BarChart, 
  TrendingUp, 
  AlertTriangle, 
  Users, 
  Globe, 
  DollarSign, 
  Calendar,
  Download,
  Filter,
  FileSpreadsheet,
  Braces
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Alert from '../components/common/Alert';
import { reportService } from '../services/reportService';
import { inventoryService } from '../services/inventoryService';
import { useAuth } from '../hooks/useAuth';
import { formatWeight } from '../utils/formatWeight';
import { formatCurrency } from '../utils/formatCurrency';

export function ReportsPage() {
  const { user } = useAuth();
  
  // Active Tab
  const [activeTab, setActiveTab] = useState('daily-sales'); // daily-sales, stock-levels, low-stock, movement, regional, audit, valuation

  // Global filters
  const [region, setRegion] = useState('both');
  const [fromDate, setFromDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split('T')[0];
  });
  const [toDate, setToDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [selectedCategory, setSelectedCategory] = useState('');
  const [categories, setCategories] = useState([]);

  // Report results
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Fetch category list
  useEffect(() => {
    const fetchCats = async () => {
      try {
        const result = await inventoryService.getCategories();
        setCategories(result);
      } catch (err) {
        console.error('Failed to load categories', err);
      }
    };
    fetchCats();
  }, []);

  const activeFilters = useMemo(() => {
    return {
      region,
      fromDate,
      toDate,
      categoryId: selectedCategory
    };
  }, [region, fromDate, toDate, selectedCategory]);

  const loadReport = async () => {
    setLoading(true);
    setError('');
    try {
      let result = [];
      switch (activeTab) {
        case 'daily-sales':
          result = await reportService.getDailySales(activeFilters);
          break;
        case 'stock-levels':
          result = await reportService.getStockLevels(activeFilters);
          break;
        case 'low-stock':
          result = await reportService.getLowStock(activeFilters);
          break;
        case 'movement':
          result = await reportService.getStockMovement(activeFilters);
          break;
        case 'regional':
          result = await reportService.getRegionalComparison(activeFilters);
          break;
        case 'audit':
          result = await reportService.getUserActivity(activeFilters);
          break;
        case 'valuation':
          result = await reportService.getInventoryValuation(activeFilters);
          break;
        default:
          result = [];
      }
      setData(result);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch report data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [activeTab, activeFilters]);

  const handleExport = async (format) => {
    if (format === 'json') {
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `${activeTab}_raw_data_${Date.now()}.json`;
      link.click();
      return;
    }
    try {
      await reportService.exportReport(activeTab, format, activeFilters);
    } catch (err) {
      alert('Export failed');
    }
  };

  const tabs = [
    { id: 'daily-sales', label: 'Daily Sales', icon: TrendingUp, roles: ['owner', 'manager', 'cashier'] },
    { id: 'stock-levels', label: 'Stock Levels', icon: BarChart, roles: ['owner', 'manager', 'cashier'] },
    { id: 'low-stock', label: 'Low Stock', icon: AlertTriangle, roles: ['owner', 'manager', 'cashier'] },
    { id: 'movement', label: 'Stock Movement', icon: FileText, roles: ['owner', 'manager', 'cashier'] },
    { id: 'regional', label: 'Regional Comparison', icon: Globe, roles: ['owner', 'manager', 'cashier'] },
    { id: 'valuation', label: 'Valuation', icon: DollarSign, roles: ['owner', 'manager', 'cashier'] },
    { id: 'audit', label: 'Audit Log', icon: Users, roles: ['owner'] } // Owner only
  ];

  const visibleTabs = tabs.filter(t => user && t.roles.includes(user.role));

  return (
    <Layout title="Business Reports" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={false}>
      
      {/* Dynamic Tab Selector */}
      <div className="flex overflow-x-auto border-b border-gray-200 gap-2 mb-6 scrollbar-none pb-1">
        {visibleTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setData([]);
              }}
              className={`
                flex items-center gap-2 px-4 py-3 border-b-2 font-semibold text-xs uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer
                ${isActive 
                  ? 'border-[#D4AF37] text-[#D4AF37] bg-amber-50/20' 
                  : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                }
              `}
            >
              <Icon className="h-4 w-4" /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* Interactive Filters Area */}
      <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs mb-6 space-y-4">
        <div className="flex items-center gap-1.5 font-bold text-sm text-gray-800 border-b border-gray-100 pb-2">
          <Filter className="h-4 w-4 text-[#D4AF37]" /> Report Filters
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          
          {/* Region selector */}
          <div>
            <label htmlFor="report-region-select" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Region</label>
            <select
              id="report-region-select"
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
            >
              <option value="both">Both Regions</option>
              <option value="uk">UK</option>
              <option value="pakistan">Pakistan</option>
            </select>
          </div>

          {/* Date range picker: From */}
          {(activeTab === 'daily-sales' || activeTab === 'movement' || activeTab === 'regional' || activeTab === 'audit') && (
            <>
              <div>
                <label htmlFor="report-from-date" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">From Date</label>
                <input
                  type="date"
                  id="report-from-date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
                />
              </div>
              <div>
                <label htmlFor="report-to-date" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">To Date</label>
                <input
                  type="date"
                  id="report-to-date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
                />
              </div>
            </>
          )}

          {/* Category Filter */}
          {(activeTab === 'daily-sales' || activeTab === 'movement' || activeTab === 'valuation' || activeTab === 'stock-levels') && (
            <div>
              <label htmlFor="report-category-select" className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Category Filter</label>
              <select
                id="report-category-select"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] h-[44px]"
              >
                <option value="">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.tagCode})</option>
                ))}
              </select>
            </div>
          )}

        </div>

        {/* Export Buttons */}
        <div className="flex justify-end gap-2 border-t border-gray-150 pt-4">
          <Button
            variant="outline"
            onClick={() => handleExport('excel')}
            className="flex items-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" /> Excel
          </Button>
          <Button
            variant="outline"
            onClick={() => handleExport('pdf')}
            className="flex items-center gap-1.5 h-[44px] cursor-pointer"
          >
            <FileText className="h-4 w-4 text-red-500" /> PDF
          </Button>
          <Button
            variant="outline"
            onClick={() => handleExport('json')}
            className="flex items-center gap-1.5 h-[44px] cursor-pointer"
          >
            <Braces className="h-4 w-4 text-blue-500" /> Raw JSON
          </Button>
        </div>
      </div>

      {error && <Alert type="error" message={error} className="mb-6" />}

      {/* Report Table Display */}
      {loading ? (
        <div className="h-[250px] flex items-center justify-center bg-white border border-gray-200 rounded-lg">
          <Spinner size="lg" />
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden p-6">
          <div className="flex items-center justify-between mb-4 border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-800 uppercase tracking-wider my-0">Report Results</h4>
            <Badge variant="primary">Compiled {data.length} records</Badge>
          </div>

          <div className="overflow-x-auto">
            {data.length === 0 ? (
              <div className="text-center py-12 text-gray-400 text-sm">
                No matching report records found.
              </div>
            ) : (
              <table className="min-w-full divide-y divide-gray-200 text-xs text-left">
                <thead className="bg-[#1F2937] text-white">
                  {activeTab === 'daily-sales' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Txn Code</th>
                      <th className="px-4 py-3 font-semibold uppercase">Category / Tag</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Weight Sold</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Qty Sold</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Price</th>
                      <th className="px-4 py-3 font-semibold uppercase">Staff</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Time</th>
                    </tr>
                  )}
                  {activeTab === 'stock-levels' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Tag</th>
                      <th className="px-4 py-3 font-semibold uppercase">Category</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Total Added</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Total Sold</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Available Weight</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Qty</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Last Activity</th>
                    </tr>
                  )}
                  {activeTab === 'low-stock' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Tag</th>
                      <th className="px-4 py-3 font-semibold uppercase">Category</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Current Qty</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Min Threshold</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Status</th>
                    </tr>
                  )}
                  {activeTab === 'movement' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Date</th>
                      <th className="px-4 py-3 font-semibold uppercase">Type</th>
                      <th className="px-4 py-3 font-semibold uppercase">Category</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Weight (g)</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Qty</th>
                      <th className="px-4 py-3 font-semibold uppercase">Region</th>
                      <th className="px-4 py-3 font-semibold uppercase">User</th>
                    </tr>
                  )}
                  {activeTab === 'regional' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Metric</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">UK Operations</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Pakistan Operations</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Difference</th>
                    </tr>
                  )}
                  {activeTab === 'valuation' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Category</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Weight</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Price/g</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Total Value</th>
                      <th className="px-4 py-3 font-semibold uppercase text-right">Region</th>
                    </tr>
                  )}
                  {activeTab === 'audit' && (
                    <tr>
                      <th className="px-4 py-3 font-semibold uppercase">Date</th>
                      <th className="px-4 py-3 font-semibold uppercase">User</th>
                      <th className="px-4 py-3 font-semibold uppercase">Action</th>
                      <th className="px-4 py-3 font-semibold uppercase">Entity</th>
                      <th className="px-4 py-3 font-semibold uppercase">Description</th>
                      <th className="px-4 py-3 font-semibold uppercase">IP Address</th>
                    </tr>
                  )}
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {data.map((row, idx) => (
                    <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/40'}>
                      {activeTab === 'daily-sales' && (
                        <>
                          <td className="px-4 py-3 font-mono font-bold text-gray-900">{row.transactionCode}</td>
                          <td className="px-4 py-3 font-semibold">{row.category}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatWeight(row.weightSold)}</td>
                          <td className="px-4 py-3 text-right font-mono">{row.qtySold}</td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-emerald-600">{formatCurrency(row.price, region)}</td>
                          <td className="px-4 py-3 uppercase">{row.staff}</td>
                          <td className="px-4 py-3 text-right font-mono">{row.time}</td>
                        </>
                      )}
                      {activeTab === 'stock-levels' && (
                        <>
                          <td className="px-4 py-3 font-mono font-bold text-gray-800">{row.tagCode}</td>
                          <td className="px-4 py-3 font-semibold">{row.categoryName}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatWeight(row.totalWeightAdded)}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatWeight(row.totalWeightSold)}</td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-emerald-600">{formatWeight(row.availableWeight)}</td>
                          <td className="px-4 py-3 text-right font-mono">{row.currentQty}</td>
                          <td className="px-4 py-3 text-right font-mono">{new Date(row.lastActivityDate).toLocaleDateString()}</td>
                        </>
                      )}
                      {activeTab === 'low-stock' && (
                        <>
                          <td className="px-4 py-3 font-mono font-bold text-gray-800">{row.tagCode}</td>
                          <td className="px-4 py-3 font-semibold">{row.categoryName}</td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-rose-600">{row.currentQty}</td>
                          <td className="px-4 py-3 text-right font-mono">{row.minThreshold}</td>
                          <td className="px-4 py-3 text-right">
                            <Badge variant={row.alertStatus === 'Critical' ? 'danger' : 'warning'}>
                              {row.alertStatus}
                            </Badge>
                          </td>
                        </>
                      )}
                      {activeTab === 'movement' && (
                        <>
                          <td className="px-4 py-3 font-mono">{new Date(row.date).toLocaleDateString()}</td>
                          <td className="px-4 py-3">
                            <Badge variant={row.type === 'ADD' ? 'uk' : 'danger'}>{row.type}</Badge>
                          </td>
                          <td className="px-4 py-3 font-semibold">{row.category}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatWeight(row.weight)}</td>
                          <td className="px-4 py-3 text-right font-mono">{row.qty}</td>
                          <td className="px-4 py-3 uppercase font-semibold text-gray-500">{row.region}</td>
                          <td className="px-4 py-3 uppercase">{row.user}</td>
                        </>
                      )}
                      {activeTab === 'regional' && (
                        <>
                          <td className="px-4 py-3 font-bold text-gray-700">{row.metric}</td>
                          <td className="px-4 py-3 text-right font-mono font-semibold text-blue-600">{row.ukValue}</td>
                          <td className="px-4 py-3 text-right font-mono font-semibold text-emerald-600">{row.pakistanValue}</td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-gray-900">{row.difference}</td>
                        </>
                      )}
                      {activeTab === 'valuation' && (
                        <>
                          <td className="px-4 py-3 font-bold text-gray-700">{row.category}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatWeight(row.weight_grams)}</td>
                          <td className="px-4 py-3 text-right font-mono">{formatCurrency(row.price_per_gram, row.region)}</td>
                          <td className="px-4 py-3 text-right font-mono font-extrabold text-emerald-600">{formatCurrency(row.totalValue, row.region)}</td>
                          <td className="px-4 py-3 text-right uppercase">
                            <Badge variant={row.region === 'uk' ? 'uk' : 'pakistan'}>{row.region}</Badge>
                          </td>
                        </>
                      )}
                      {activeTab === 'audit' && (
                        <>
                          <td className="px-4 py-3 font-mono">{new Date(row.date).toLocaleString()}</td>
                          <td className="px-4 py-3 font-semibold text-gray-800">{row.user}</td>
                          <td className="px-4 py-3">
                            <Badge variant="primary">{row.action}</Badge>
                          </td>
                          <td className="px-4 py-3 text-gray-500 font-semibold">{row.entityType}</td>
                          <td className="px-4 py-3 text-gray-600">{row.description}</td>
                          <td className="px-4 py-3 font-mono text-gray-550">{row.ipAddress}</td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

    </Layout>
  );
}

export default ReportsPage;
