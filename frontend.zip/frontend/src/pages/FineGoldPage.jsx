import React, { useState, useEffect, useMemo } from 'react';
import { Coins, Plus, Minus, ArrowUpRight, ArrowDownRight, RefreshCw, Edit2, Check, X, Calendar } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Alert from '../components/common/Alert';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import Table from '../components/common/Table';
import { useFineGold } from '../hooks/useFineGold';
import { useAuth } from '../hooks/useAuth';
import { formatWeight } from '../utils/formatWeight';
import { formatCurrency } from '../utils/formatCurrency';

export function FineGoldPage() {
  const { user } = useAuth();
  const [region, setRegion] = useState('uk'); // UK is default
  const {
    summary,
    transactions,
    loading,
    error,
    fetchSummary,
    fetchTransactions,
    updatePrice,
    buyGold,
    sellGold
  } = useFineGold(region);

  // Buy form states
  const [buyGrams, setBuyGrams] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [buySupplier, setBuySupplier] = useState('');
  const [buyNotes, setBuyNotes] = useState('');
  const [buyErrors, setBuyErrors] = useState({});

  // Sell form states
  const [sellGrams, setSellGrams] = useState('');
  const [sellPrice, setSellPrice] = useState('');
  const [sellCustomer, setSellCustomer] = useState('');
  const [sellNotes, setSellNotes] = useState('');
  const [sellErrors, setSellErrors] = useState({});

  // Edit price states
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [newPriceInput, setNewPriceInput] = useState('');

  useEffect(() => {
    fetchSummary(region);
    fetchTransactions(region);
  }, [region, fetchSummary, fetchTransactions]);

  const handleUpdatePrice = async () => {
    const val = parseFloat(newPriceInput);
    if (isNaN(val) || val <= 0) {
      alert('Price must be greater than 0');
      return;
    }
    try {
      await updatePrice(region, val);
      setIsEditingPrice(false);
    } catch (e) {
      alert('Failed to update price');
    }
  };

  const handleBuySubmit = async (e) => {
    e.preventDefault();
    setBuyErrors({});

    const errs = {};
    const grams = parseFloat(buyGrams);
    const price = parseFloat(buyPrice);

    if (isNaN(grams) || grams <= 0) errs.grams = 'Grams to Buy must be greater than 0';
    if (isNaN(price) || price <= 0) errs.price = 'Price Per Gram must be greater than 0';
    if (!buySupplier) errs.supplier = 'Supplier Name is required';

    if (Object.keys(errs).length > 0) {
      setBuyErrors(errs);
      return;
    }

    try {
      await buyGold({
        weight_grams: grams,
        price_per_gram: price,
        supplier_name: buySupplier,
        region,
        notes: buyNotes
      });
      alert('Gold purchase logged successfully!');
      setBuyGrams('');
      setBuyPrice('');
      setBuySupplier('');
      setBuyNotes('');
    } catch (err) {
      alert(err.message || 'Failed to complete purchase');
    }
  };

  const handleSellSubmit = async (e) => {
    e.preventDefault();
    setSellErrors({});

    const errs = {};
    const grams = parseFloat(sellGrams);
    const price = parseFloat(sellPrice);

    if (isNaN(grams) || grams <= 0) errs.grams = 'Grams to Sell must be greater than 0';
    if (summary && grams > summary.availableGrams) {
      errs.grams = `Only ${formatWeight(summary.availableGrams)} available, you cannot sell ${formatWeight(grams)}`;
    }
    if (isNaN(price) || price <= 0) errs.price = 'Sale Price Per Gram must be greater than 0';
    if (!sellCustomer) errs.customer = 'Customer Name is required';

    if (Object.keys(errs).length > 0) {
      setSellErrors(errs);
      return;
    }

    try {
      await sellGold({
        weight_grams: grams,
        price_per_gram: price,
        customer_name: sellCustomer,
        region,
        notes: sellNotes
      });
      alert('Gold sale logged successfully!');
      setSellGrams('');
      setSellPrice('');
      setSellCustomer('');
      setSellNotes('');
    } catch (err) {
      alert(err.message || 'Failed to complete sale');
    }
  };

  // Calculations for overall Profit & Loss
  const pnlStats = useMemo(() => {
    let lastPnl = null;
    let overallPnl = 0;

    // Filter sell transactions to compute PNL
    const sellTxs = transactions.filter(t => t.type === 'SELL');
    
    if (sellTxs.length > 0) {
      lastPnl = sellTxs[0].profitLoss; // most recent sell P&L
    }

    overallPnl = sellTxs.reduce((sum, t) => sum + (t.profitLoss || 0), 0);

    return {
      lastPnl,
      overallPnl
    };
  }, [transactions]);

  const columns = [
    { 
      key: 'type', 
      header: 'Type', 
      sortable: true,
      render: (row) => (
        <Badge variant={row.type === 'BUY' ? 'uk' : 'success'}>
          {row.type === 'BUY' ? 'BUY' : 'SELL'}
        </Badge>
      )
    },
    { 
      key: 'date', 
      header: 'Date & Time', 
      sortable: true,
      render: (row) => <span>{new Date(row.date).toLocaleString()}</span>
    },
    { 
      key: 'grams', 
      header: 'Grams', 
      sortable: true,
      render: (row) => <span className="font-mono text-gray-900">{formatWeight(row.grams)}</span>
    },
    { 
      key: 'pricePerGram', 
      header: 'Price/g', 
      sortable: true,
      render: (row) => <span className="font-mono font-semibold">{formatCurrency(row.pricePerGram, region)}</span>
    },
    { 
      key: 'supplierOrCustomer', 
      header: 'Source / Client',
      render: (row) => <span className="font-medium text-gray-800">{row.supplierOrCustomer}</span>
    },
    { 
      key: 'profitLoss', 
      header: 'P&L',
      render: (row) => {
        if (row.type === 'BUY' || row.profitLoss === null || row.profitLoss === undefined) {
          return <span className="text-gray-400 font-bold">—</span>;
        }
        const isProfit = row.profitLoss >= 0;
        return (
          <span className={`font-mono font-bold flex items-center gap-0.5 ${isProfit ? 'text-emerald-600' : 'text-rose-600'}`}>
            {isProfit ? '+' : ''}{formatCurrency(row.profitLoss, region)}
          </span>
        );
      }
    }
  ];

  return (
    <Layout title="Fine Gold Management" selectedRegion={region} onRegionChange={setRegion} showRegionSelector={true}>
      
      {error && (
        <div className="mb-6 flex gap-4 items-center">
          <Alert type="error" message={error} className="flex-1" />
          <Button onClick={() => { fetchSummary(region); fetchTransactions(region); }}>Retry</Button>
        </div>
      )}

      {loading && !summary ? (
        <div className="h-[300px] flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* Top Panel: Summary & Profit/Loss stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Summary details card */}
            <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Available Fine Gold</span>
                <span className="text-3xl font-extrabold text-[#1F2937] block mt-1">
                  {summary ? formatWeight(summary.availableGrams) : '0.000 g'}
                </span>
              </div>
              <div className="mt-6 border-t border-gray-100 pt-3 flex justify-between items-center text-xs">
                <div>
                  <span className="text-gray-400 font-semibold block">Total Value:</span>
                  <strong className="font-mono text-emerald-600 font-extrabold text-sm block">
                    {summary ? formatCurrency(summary.totalValue, region) : formatCurrency(0, region)}
                  </strong>
                </div>
                
                {/* Editable price per gram */}
                <div className="text-right">
                  <span className="text-gray-400 font-semibold block">Market Price:</span>
                  {isEditingPrice ? (
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <input
                        type="number"
                        id="gold-market-price-input"
                        value={newPriceInput}
                        onChange={(e) => setNewPriceInput(e.target.value)}
                        className="w-16 px-1.5 py-0.5 border border-gray-300 rounded font-mono text-xs focus:outline-none"
                      />
                      <button onClick={handleUpdatePrice} className="p-0.5 bg-emerald-500 text-white rounded cursor-pointer">
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={() => setIsEditingPrice(false)} className="p-0.5 bg-gray-200 text-gray-700 rounded cursor-pointer">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-end gap-1.5 mt-0.5">
                      <strong className="font-mono text-gray-800">
                        {summary ? formatCurrency(summary.currentPricePerGram, region) : '0'}/g
                      </strong>
                      {(user?.role === 'owner' || user?.role === 'manager') && (
                        <button
                          onClick={() => {
                            setNewPriceInput(summary?.currentPricePerGram || '');
                            setIsEditingPrice(true);
                          }}
                          className="text-[#D4AF37] hover:text-[#C59B27] cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Overall PNL Card */}
            <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Overall Profit / Loss</span>
                <span className={`text-3xl font-extrabold block mt-1 font-mono ${pnlStats.overallPnl >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {pnlStats.overallPnl >= 0 ? '+' : ''}{formatCurrency(pnlStats.overallPnl, region)}
                </span>
              </div>
              <div className="mt-4 flex items-center text-xs gap-1 font-semibold">
                {pnlStats.overallPnl >= 0 ? (
                  <span className="text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-0.5">
                    <ArrowUpRight className="h-3.5 w-3.5" /> Profitable operation
                  </span>
                ) : (
                  <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded flex items-center gap-0.5">
                    <ArrowDownRight className="h-3.5 w-3.5" /> Overall Loss margin
                  </span>
                )}
              </div>
            </div>

            {/* Last Transaction Card */}
            <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Last Transaction P&L</span>
                <span className={`text-2xl font-extrabold block mt-2 font-mono ${
                  pnlStats.lastPnl === null 
                    ? 'text-gray-400' 
                    : pnlStats.lastPnl >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {pnlStats.lastPnl === null ? '—' : `${pnlStats.lastPnl >= 0 ? '+' : ''}${formatCurrency(pnlStats.lastPnl, region)}`}
                </span>
              </div>
              <span className="text-[10px] text-gray-400 font-medium">Auto computed during sales based on initial gold buy cost</span>
            </div>

          </div>

          {/* Center Split forms: Buy on left, Sell on right */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* BUY GOLD FORM */}
            <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs">
              <h3 className="text-base font-bold text-gray-900 border-b border-gray-200 pb-3 mb-4 flex items-center gap-1.5 my-0">
                <Plus className="h-5 w-5 text-blue-500" /> BUY FINE GOLD
              </h3>
              <form onSubmit={handleBuySubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Grams to Buy"
                    id="buyGrams"
                    type="number"
                    step="any"
                    placeholder="0.000"
                    value={buyGrams}
                    onChange={(e) => setBuyGrams(e.target.value)}
                    error={buyErrors.grams}
                    required
                  />
                  <Input
                    label={region === 'uk' ? 'Price Per Gram (£)' : 'Price Per Gram (Rs)'}
                    id="buyPrice"
                    type="number"
                    step="any"
                    placeholder="0.00"
                    value={buyPrice}
                    onChange={(e) => setBuyPrice(e.target.value)}
                    error={buyErrors.price}
                    required
                  />
                </div>
                <Input
                  label="Supplier Name"
                  id="buySupplier"
                  placeholder="e.g. Al-Hafiz Jewellers"
                  value={buySupplier}
                  onChange={(e) => setBuySupplier(e.target.value)}
                  error={buyErrors.supplier}
                  required
                />
                <div>
                  <label htmlFor="buyNotes" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">
                    Notes
                  </label>
                  <textarea
                    id="buyNotes"
                    rows="2"
                    placeholder="Purchase notes..."
                    value={buyNotes}
                    onChange={(e) => setBuyNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors"
                  />
                </div>
                <Button type="submit" variant="primary" className="w-full h-[44px]">
                  Confirm Purchase Buy
                </Button>
              </form>
            </div>

            {/* SELL GOLD FORM */}
            <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs">
              <h3 className="text-base font-bold text-gray-900 border-b border-gray-200 pb-3 mb-4 flex items-center gap-1.5 my-0">
                <Minus className="h-5 w-5 text-emerald-500" /> SELL FINE GOLD
              </h3>
              <form onSubmit={handleSellSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Grams to Sell"
                    id="sellGrams"
                    type="number"
                    step="any"
                    placeholder="0.000"
                    value={sellGrams}
                    onChange={(e) => setSellGrams(e.target.value)}
                    error={sellErrors.grams}
                    required
                  />
                  <Input
                    label={region === 'uk' ? 'Sale Price Per Gram (£)' : 'Sale Price Per Gram (Rs)'}
                    id="sellPrice"
                    type="number"
                    step="any"
                    placeholder="0.00"
                    value={sellPrice}
                    onChange={(e) => setSellPrice(e.target.value)}
                    error={sellErrors.price}
                    required
                  />
                </div>
                <Input
                  label="Customer Name"
                  id="sellCustomer"
                  placeholder="e.g. Zahid Khan"
                  value={sellCustomer}
                  onChange={(e) => setSellCustomer(e.target.value)}
                  error={sellErrors.customer}
                  required
                />
                <div>
                  <label htmlFor="sellNotes" className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">
                    Notes
                  </label>
                  <textarea
                    id="sellNotes"
                    rows="2"
                    placeholder="Sale notes..."
                    value={sellNotes}
                    onChange={(e) => setSellNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors"
                  />
                </div>
                <Button type="submit" variant="success" className="w-full h-[44px]">
                  Confirm Sales Log
                </Button>
              </form>
            </div>

          </div>

          {/* Bottom Table: Transaction History logs */}
          <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-xs">
            <h3 className="text-base font-bold text-gray-900 border-b border-gray-200 pb-3 mb-4 flex items-center gap-1.5 my-0">
              <Calendar className="h-5 w-5 text-gray-400" /> TRANSACTION HISTORY
            </h3>
            <Table
              columns={columns}
              data={transactions}
              emptyMessage="No fine gold transaction logs found for this region."
              mobileCardRender={(row) => (
                <div className="space-y-3">
                  <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                    <Badge variant={row.type === 'BUY' ? 'uk' : 'success'}>
                      {row.type === 'BUY' ? 'BUY' : 'SELL'}
                    </Badge>
                    <span className="text-[10px] text-gray-400">{new Date(row.date).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-gray-700">Weight: <strong className="font-mono text-gray-950">{formatWeight(row.grams)}</strong></span>
                    <span className="font-semibold text-gray-750">Price/g: <strong className="font-mono text-gray-950">{formatCurrency(row.pricePerGram, region)}</strong></span>
                  </div>
                  <div className="text-xs pt-1 border-t border-gray-105 flex justify-between items-center">
                    <span className="text-gray-500 font-semibold">{row.supplierOrCustomer}</span>
                    {row.type === 'SELL' && row.profitLoss !== null && (
                      <span className={`font-mono font-bold ${row.profitLoss >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        P&L: {row.profitLoss >= 0 ? '+' : ''}{formatCurrency(row.profitLoss, region)}
                      </span>
                    )}
                  </div>
                </div>
              )}
            />
          </div>

        </div>
      )}

    </Layout>
  );
}

export default FineGoldPage;
