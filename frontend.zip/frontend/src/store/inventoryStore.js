import { create } from 'zustand';
import { inventoryService } from '../services/inventoryService';

export const useInventoryStore = create((set, get) => ({
  categories: [],
  inventory: [],
  loading: false,
  error: null,

  setCategories: (categories) => set({ categories }),
  setInventory: (inventory) => set({ inventory }),

  fetchInventory: async (region = 'both') => {
    set({ loading: true, error: null });
    try {
      const data = await inventoryService.getInventory(region);
      set({ inventory: data, loading: false });
    } catch (err) {
      set({ error: err.message || 'Failed to fetch inventory', loading: false });
    }
  },

  fetchCategories: async () => {
    try {
      const data = await inventoryService.getCategories();
      set({ categories: data });
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  },

  updateLocalInventory: (categoryId, region, weight, qty) => {
    const { inventory } = get();
    const updatedInventory = inventory.map((item) => {
      if (item.categoryId === categoryId && item.region === region) {
        return {
          ...item,
          totalWeight: Math.max(0, item.totalWeight + weight),
          totalQty: Math.max(0, item.totalQty + qty),
        };
      }
      return item;
    });
    set({ inventory: updatedInventory });
  }
}));
