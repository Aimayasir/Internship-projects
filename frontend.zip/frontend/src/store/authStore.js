import { create } from 'zustand';
import { authService } from '../services/authService';
import { JWT_STORAGE_KEY } from '../utils/constants';

const getInitialState = () => {
  const token = sessionStorage.getItem(JWT_STORAGE_KEY) || '';
  const storedUser = sessionStorage.getItem('jewellery_pos_user');
  let user = null;
  if (storedUser) {
    try {
      user = JSON.parse(storedUser);
    } catch (e) {
      user = null;
    }
  }
  return {
    user,
    token,
    isAuthenticated: !!token,
  };
};

export const useAuthStore = create((set, get) => ({
  ...getInitialState(),

  login: async (email, password) => {
    try {
      const response = await authService.login(email, password);
      const { token, user } = response;
      
      sessionStorage.setItem(JWT_STORAGE_KEY, token);
      sessionStorage.setItem('jewellery_pos_user', JSON.stringify(user));
      
      set({ user, token, isAuthenticated: true });
      return { success: true, user };
    } catch (error) {
      throw error;
    }
  },

  logout: () => {
    sessionStorage.removeItem(JWT_STORAGE_KEY);
    sessionStorage.removeItem('jewellery_pos_user');
    set({ user: null, token: '', isAuthenticated: false });
  },

  setUser: (user, token) => {
    if (token) {
      sessionStorage.setItem(JWT_STORAGE_KEY, token);
      set({ token, isAuthenticated: true });
    }
    if (user) {
      sessionStorage.setItem('jewellery_pos_user', JSON.stringify(user));
      set({ user });
    }
  },

  getToken: () => {
    return get().token || sessionStorage.getItem(JWT_STORAGE_KEY);
  }
}));
