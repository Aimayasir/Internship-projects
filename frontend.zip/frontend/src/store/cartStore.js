import { create } from 'zustand';

export const useCartStore = create((set, get) => ({
  items: [],

  addItem: (item) => {
    // Check if item already exists in the cart, and merge it if it does
    const { items } = get();
    const existingIndex = items.findIndex(i => i.categoryId === item.categoryId);
    if (existingIndex > -1) {
      const updated = [...items];
      updated[existingIndex] = {
        ...updated[existingIndex],
        weight: updated[existingIndex].weight + parseFloat(item.weight),
        qty: updated[existingIndex].qty + parseInt(item.qty, 10),
        price: item.price || updated[existingIndex].price // keep or update price
      };
      set({ items: updated });
    } else {
      set({ items: [...items, { ...item, weight: parseFloat(item.weight), qty: parseInt(item.qty, 10) }] });
    }
  },

  removeItem: (index) => {
    set((state) => ({
      items: state.items.filter((_, i) => i !== index),
    }));
  },

  updateItem: (index, weight, qty) => {
    set((state) => ({
      items: state.items.map((item, i) =>
        i === index ? { ...item, weight: parseFloat(weight), qty: parseInt(qty, 10) } : item
      ),
    }));
  },

  clearCart: () => set({ items: [] }),

  getCartTotal: () => {
    const { items } = get();
    return items.reduce(
      (totals, item) => {
        totals.totalWeight += item.weight || 0;
        totals.totalQty += item.qty || 0;
        // Total price = price * quantity, or price directly if it's already a total
        totals.totalPrice += (item.price || 0) * (item.qty || 1);
        return totals;
      },
      { totalWeight: 0, totalQty: 0, totalPrice: 0 }
    );
  }
}));
