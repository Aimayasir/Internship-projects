import api from './api';

const MOCK_GOLD_SUMMARY_KEY = 'mock_gold_summary_';
const MOCK_GOLD_TXS_KEY = 'mock_gold_txs_';

const defaultTxs = [
  { id: 'tx-1', type: 'BUY', date: '2024-01-10T10:00:00Z', grams: 100, pricePerGram: 9900, supplierOrCustomer: 'Al-Hafiz Jewellers', notes: 'Initial buy', profitLoss: null },
  { id: 'tx-2', type: 'SELL', date: '2024-01-15T15:30:00Z', grams: 50, pricePerGram: 10200, supplierOrCustomer: 'Zahid Khan', notes: 'Sale to client', profitLoss: 15000 }
];

export const fineGoldService = {
  getSummary: async (region = 'uk') => {
    try {
      const response = await api.get(`/fine-gold/summary?region=${region}`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const stored = sessionStorage.getItem(MOCK_GOLD_SUMMARY_KEY + region);
        if (stored) {
          return JSON.parse(stored);
        }
        
        // Default values
        const isPak = region === 'pakistan';
        const defaultSum = {
          availableGrams: 500.5,
          totalBoughtGrams: 1000,
          totalSoldGrams: 499.5,
          currentPricePerGram: isPak ? 9990 : 55.50,
          totalValue: 5000950,
          region
        };
        sessionStorage.setItem(MOCK_GOLD_SUMMARY_KEY + region, JSON.stringify(defaultSum));
        return defaultSum;
      }
      throw error;
    }
  },

  updateCurrentPrice: async (region, price) => {
    try {
      const response = await api.patch(`/fine-gold/price`, { region, price });
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const sum = await fineGoldService.getSummary(region);
        sum.currentPricePerGram = parseFloat(price);
        sum.totalValue = sum.availableGrams * sum.currentPricePerGram;
        sessionStorage.setItem(MOCK_GOLD_SUMMARY_KEY + region, JSON.stringify(sum));
        return sum;
      }
      throw error;
    }
  },

  getTransactions: async (region = 'uk') => {
    try {
      const response = await api.get(`/fine-gold/transactions?region=${region}`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const txsKey = MOCK_GOLD_TXS_KEY + region;
        const stored = sessionStorage.getItem(txsKey);
        if (stored) return JSON.parse(stored);
        
        sessionStorage.setItem(txsKey, JSON.stringify(defaultTxs));
        return defaultTxs;
      }
      throw error;
    }
  },

  buyGold: async (buyData) => {
    try {
      const response = await api.post('/fine-gold/buy', buyData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const region = buyData.region;
        const sum = await fineGoldService.getSummary(region);
        const txsKey = MOCK_GOLD_TXS_KEY + region;
        const txs = await fineGoldService.getTransactions(region);

        const grams = parseFloat(buyData.weight_grams);
        const price = parseFloat(buyData.price_per_gram);

        sum.availableGrams += grams;
        sum.totalBoughtGrams += grams;
        sum.totalValue = sum.availableGrams * sum.currentPricePerGram;

        const newTx = {
          id: 'tx-' + Date.now(),
          type: 'BUY',
          date: new Date().toISOString(),
          grams,
          pricePerGram: price,
          supplierOrCustomer: buyData.supplier_name,
          notes: buyData.notes || '',
          profitLoss: null
        };

        txs.unshift(newTx);
        sessionStorage.setItem(MOCK_GOLD_SUMMARY_KEY + region, JSON.stringify(sum));
        sessionStorage.setItem(txsKey, JSON.stringify(txs));

        return { success: true, transaction: newTx };
      }
      throw new Error(error.response?.data?.error || 'Failed to buy gold');
    }
  },

  sellGold: async (sellData) => {
    try {
      const response = await api.post('/fine-gold/sell', sellData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const region = sellData.region;
        const sum = await fineGoldService.getSummary(region);
        const txsKey = MOCK_GOLD_TXS_KEY + region;
        const txs = await fineGoldService.getTransactions(region);

        const grams = parseFloat(sellData.weight_grams);
        const price = parseFloat(sellData.price_per_gram);

        if (sum.availableGrams < grams) {
          throw new Error(`Only ${sum.availableGrams}g available, you are trying to sell ${grams}g`);
        }

        sum.availableGrams -= grams;
        sum.totalSoldGrams += grams;
        sum.totalValue = sum.availableGrams * sum.currentPricePerGram;

        const costPrice = region === 'pakistan' ? 9900 : 50;
        const profitLoss = (price - costPrice) * grams;

        const newTx = {
          id: 'tx-' + Date.now(),
          type: 'SELL',
          date: new Date().toISOString(),
          grams,
          pricePerGram: price,
          supplierOrCustomer: sellData.customer_name,
          notes: sellData.notes || '',
          profitLoss
        };

        txs.unshift(newTx);
        sessionStorage.setItem(MOCK_GOLD_SUMMARY_KEY + region, JSON.stringify(sum));
        sessionStorage.setItem(txsKey, JSON.stringify(txs));

        return {
          success: true,
          transaction: {
            grams,
            costPrice,
            salePrice: price,
            profitLoss
          }
        };
      }
      throw new Error(error.response?.data?.error || 'Failed to sell gold');
    }
  }
};
