import api from './api';

const MOCK_SALES_KEY = 'mock_sales';

const defaultSales = [
  {
    saleId: 'sale-1',
    transactionCode: 'TXN-2024-0001',
    timestamp: '2024-01-15T14:30:00Z',
    region: 'uk',
    itemCount: 4,
    totalWeight: 55.700,
    totalPrice: 2450.00,
    staffName: 'Ahmed',
    items: [
      { categoryId: 'cat-1', categoryName: 'Diamond Rings', tagCode: 'DR', weight_grams: 10.500, quantity: 3, price_per_gram: 50.0 },
      { categoryId: 'cat-3', categoryName: 'Gold Necklaces', tagCode: 'GN', weight_grams: 45.200, quantity: 1, price_per_gram: 50.0 }
    ],
    isVoided: false
  },
  {
    saleId: 'sale-2',
    transactionCode: 'TXN-2024-0002',
    timestamp: '2024-01-16T11:15:00Z',
    region: 'pakistan',
    itemCount: 2,
    totalWeight: 24.500,
    totalPrice: 120000.00,
    staffName: 'Aman',
    items: [
      { categoryId: 'cat-2', categoryName: 'Gold Rings', tagCode: 'GR', weight_grams: 24.500, quantity: 2, price_per_gram: 4000.0 }
    ],
    isVoided: false
  }
];

const getStoredSales = () => {
  const data = sessionStorage.getItem(MOCK_SALES_KEY);
  if (!data) {
    sessionStorage.setItem(MOCK_SALES_KEY, JSON.stringify(defaultSales));
    return defaultSales;
  }
  return JSON.parse(data);
};

export const salesService = {
  getSales: async (filters = {}) => {
    try {
      let queryParams = [];
      if (filters.region && filters.region !== 'both') queryParams.push(`region=${filters.region}`);
      if (filters.fromDate) queryParams.push(`fromDate=${filters.fromDate}`);
      if (filters.toDate) queryParams.push(`toDate=${filters.toDate}`);
      const qs = queryParams.length ? `?${queryParams.join('&')}` : '';
      const response = await api.get(`/sales${qs}`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        let sales = getStoredSales();
        if (filters.region && filters.region !== 'both') {
          sales = sales.filter(s => s.region === filters.region);
        }
        if (filters.fromDate) {
          const from = new Date(filters.fromDate);
          sales = sales.filter(s => new Date(s.timestamp) >= from);
        }
        if (filters.toDate) {
          const to = new Date(filters.toDate);
          to.setHours(23, 59, 59, 999);
          sales = sales.filter(s => new Date(s.timestamp) <= to);
        }
        return sales;
      }
      throw error;
    }
  },

  confirmSale: async (saleData) => {
    try {
      const response = await api.post('/sales', saleData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        // Mock inventory deduction & sale creation
        const sales = getStoredSales();
        
        // Deduct stock from mock inventory
        const invData = sessionStorage.getItem('mock_inventory');
        if (invData) {
          const inv = JSON.parse(invData);
          for (const item of saleData.items) {
            const index = inv.findIndex(i => i.categoryId === item.categoryId && i.region === saleData.region);
            if (index > -1) {
              if (inv[index].totalWeight < item.weight_grams || inv[index].totalQty < item.quantity) {
                throw new Error(`Insufficient stock for ${inv[index].categoryName}`);
              }
              inv[index].totalWeight -= item.weight_grams;
              inv[index].totalQty -= item.quantity;
            }
          }
          sessionStorage.setItem('mock_inventory', JSON.stringify(inv));
        }

        const catsData = sessionStorage.getItem('mock_categories');
        const cats = catsData ? JSON.parse(catsData) : [];

        let totalWeight = 0;
        let totalQty = 0;
        let totalPrice = 0;

        const saleItems = saleData.items.map(item => {
          const cat = cats.find(c => c.id === item.categoryId);
          totalWeight += parseFloat(item.weight_grams);
          totalQty += parseInt(item.quantity, 10);
          const price = item.price_per_gram ? (item.price_per_gram * item.weight_grams) : 500;
          totalPrice += price;
          return {
            categoryId: item.categoryId,
            categoryName: cat ? cat.name : 'Unknown',
            tagCode: cat ? cat.tagCode : '??',
            weight_grams: parseFloat(item.weight_grams),
            quantity: parseInt(item.quantity, 10),
            price_per_gram: item.price_per_gram || 500
          };
        });

        const newSale = {
          saleId: 'sale-' + Date.now(),
          transactionCode: 'TXN-' + new Date().getFullYear() + '-' + String(sales.length + 1).padStart(4, '0'),
          timestamp: new Date().toISOString(),
          region: saleData.region,
          itemCount: saleItems.length,
          totalWeight,
          totalPrice,
          staffName: 'Ahmed',
          items: saleItems,
          isVoided: false
        };

        sales.push(newSale);
        sessionStorage.setItem(MOCK_SALES_KEY, JSON.stringify(sales));
        return newSale;
      }
      throw new Error(error.response?.data?.error || 'Failed to complete sale');
    }
  },

  voidSale: async (saleId) => {
    try {
      const response = await api.post(`/sales/${saleId}/void`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const sales = getStoredSales();
        const index = sales.findIndex(s => s.saleId === saleId);
        if (index > -1) {
          sales[index].isVoided = true;
          
          // Restore inventory stock
          const invData = sessionStorage.getItem('mock_inventory');
          if (invData) {
            const inv = JSON.parse(invData);
            for (const item of sales[index].items) {
              const invIdx = inv.findIndex(i => i.categoryId === item.categoryId && i.region === sales[index].region);
              if (invIdx > -1) {
                inv[invIdx].totalWeight += item.weight_grams;
                inv[invIdx].totalQty += item.quantity;
              }
            }
            sessionStorage.setItem('mock_inventory', JSON.stringify(inv));
          }

          sessionStorage.setItem(MOCK_SALES_KEY, JSON.stringify(sales));
          return { success: true, message: 'Sale voided' };
        }
        throw new Error('Sale not found');
      }
      throw new Error(error.response?.data?.error || 'Failed to void sale');
    }
  }
};
