import api from './api';

export const reportService = {
  getDailySales: async (filters = {}) => {
    try {
      const response = await api.get('/reports/daily-sales', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { transactionCode: 'TXN-2024-0001', category: 'Diamond Rings (DR)', weightSold: 10.500, qtySold: 3, price: 1500, staff: 'Ahmed', time: '14:30' },
        { transactionCode: 'TXN-2024-0002', category: 'Gold Necklaces (GN)', weightSold: 45.200, qtySold: 1, price: 950, staff: 'Ahmed', time: '14:35' },
        { transactionCode: 'TXN-2024-0003', category: 'Gold Rings (GR)', weightSold: 24.500, qtySold: 2, price: 120000, staff: 'Aman', time: '11:15' }
      ];
    }
  },

  getStockLevels: async (filters = {}) => {
    try {
      const response = await api.get('/reports/stock-levels', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { tagCode: 'DR', categoryName: 'Diamond Rings', totalWeightAdded: 2500.000, totalWeightSold: 1250.567, availableWeight: 1249.433, currentQty: 45, lastActivityDate: '2024-01-15T10:30:00Z' },
        { tagCode: 'GR', categoryName: 'Gold Rings', totalWeightAdded: 1500.000, totalWeightSold: 840.120, availableWeight: 659.880, currentQty: 25, lastActivityDate: '2024-01-16T11:15:00Z' },
        { tagCode: 'GN', categoryName: 'Gold Necklaces', totalWeightAdded: 3000.000, totalWeightSold: 45.200, availableWeight: 2954.800, currentQty: 50, lastActivityDate: '2024-01-15T14:30:00Z' }
      ];
    }
  },

  getLowStock: async (filters = {}) => {
    try {
      const response = await api.get('/reports/low-stock', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { tagCode: 'DR', categoryName: 'Diamond Rings', currentQty: 5, minThreshold: 10, alertStatus: 'Critical' },
        { tagCode: 'GR', categoryName: 'Gold Rings', currentQty: 3, minThreshold: 5, alertStatus: 'Warning' }
      ];
    }
  },

  getStockMovement: async (filters = {}) => {
    try {
      const response = await api.get('/reports/stock-movement', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { date: '2024-01-15T14:30:00Z', type: 'DEDUCT', category: 'Diamond Rings (DR)', weight: 10.500, qty: 3, region: 'uk', user: 'Ahmed' },
        { date: '2024-01-15T10:30:00Z', type: 'ADD', category: 'Diamond Rings (DR)', weight: 500.000, qty: 15, region: 'uk', user: 'Ahmed' },
        { date: '2024-01-16T11:15:00Z', type: 'DEDUCT', category: 'Gold Rings (GR)', weight: 24.500, qty: 2, region: 'pakistan', user: 'Aman' }
      ];
    }
  },

  getRegionalComparison: async (filters = {}) => {
    try {
      const response = await api.get('/reports/regional', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { metric: 'Total Stock Weight', ukValue: '12,500.000 g', pakistanValue: '8,400.000 g', difference: '+4,100.000 g' },
        { metric: 'Total Sales Weight (Today)', ukValue: '55.700 g', pakistanValue: '24.500 g', difference: '+31.200 g' },
        { metric: 'Active Cashiers', ukValue: '3', pakistanValue: '2', difference: '+1' },
        { metric: 'Fine Gold On Hand', ukValue: '500.500 g', pakistanValue: '1,200.000 g', difference: '-699.500 g' }
      ];
    }
  },

  getUserActivity: async (filters = {}) => {
    try {
      const response = await api.get('/reports/audit-log', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { date: '2024-01-16T12:00:00Z', user: 'Super Admin', action: 'CREATE_USER', entityType: 'User', description: 'Created cashier user cashier_pk@jewellery.com', ipAddress: '192.168.1.50' },
        { date: '2024-01-15T14:35:00Z', user: 'Ahmed', action: 'CONFIRM_SALE', entityType: 'Sale', description: 'Confirmed sale TXN-2024-0001', ipAddress: '192.168.1.101' },
        { date: '2024-01-15T10:30:00Z', user: 'Ahmed', action: 'ADD_STOCK', entityType: 'Inventory', description: 'Added 500g to Diamond Rings', ipAddress: '192.168.1.101' }
      ];
    }
  },

  getInventoryValuation: async (filters = {}) => {
    try {
      const response = await api.get('/reports/inventory-valuation', { params: filters });
      return response.data;
    } catch (e) {
      return [
        { category: 'Diamond Rings (DR)', weight_grams: 1250.567, price_per_gram: 50.0, totalValue: 62528.35, region: 'uk' },
        { category: 'Gold Rings (GR)', weight_grams: 840.120, price_per_gram: 4000.0, totalValue: 3360480.00, region: 'pakistan' },
        { category: 'Gold Necklaces (GN)', weight_grams: 2954.800, price_per_gram: 4200.0, totalValue: 12410160.00, region: 'pakistan' }
      ];
    }
  },

  exportReport: async (type, format, filters = {}) => {
    try {
      const response = await api.get(`/reports/export/${format}`, {
        params: { type, ...filters },
        responseType: 'blob'
      });
      const blob = new Blob([response.data], { type: format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `${type}_report_${Date.now()}.${format === 'excel' ? 'xlsx' : 'pdf'}`;
      link.click();
      return true;
    } catch (error) {
      console.log(`Simulating ${format.toUpperCase()} export for report type: ${type}`);
      const link = document.createElement('a');
      const mockContent = `Mock file content for ${type} report (${format.toUpperCase()})`;
      const blob = new Blob([mockContent], { type: 'text/plain' });
      link.href = window.URL.createObjectURL(blob);
      link.download = `${type}_report_${Date.now()}.${format === 'excel' ? 'xlsx' : 'pdf'}`;
      link.click();
      return true;
    }
  }
};
