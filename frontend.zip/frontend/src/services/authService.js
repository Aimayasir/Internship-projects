import api from './api';

export const authService = {
  login: async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      return response.data;
    } catch (error) {
      // For testing / offline demo fallback
      if (error.code === 'ERR_NETWORK' || !error.response) {
        if (email.endsWith('@jewellery.com') && password.length >= 6) {
          let role = 'owner';
          let region = 'both';
          if (email.startsWith('cashier')) {
            role = 'cashier';
            region = 'uk';
          } else if (email.startsWith('manager')) {
            role = 'manager';
            region = 'pakistan';
          }
          return {
            token: 'mock_jwt_token_for_' + email,
            user: {
              id: 'mock-uuid-123',
              email,
              role,
              region_access: region,
              full_name: email.split('@')[0].toUpperCase()
            }
          };
        }
        throw new Error('Connection error. Server is unreachable.');
      }
      
      if (error.response && error.response.status === 401) {
        throw new Error('Invalid email or password');
      }
      throw new Error(error.response?.data?.error || 'Login failed');
    }
  },
  logout: async () => {
    try {
      await api.post('/auth/logout');
    } catch (e) {
      // ignore
    }
  }
};
