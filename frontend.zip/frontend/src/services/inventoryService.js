import api from './api';

// Simple mock inventory DB in sessionStorage for testing when API is not running
const MOCK_CATEGORIES_KEY = 'mock_categories';
const MOCK_INVENTORY_KEY = 'mock_inventory';

const defaultCategories = [
  { id: 'cat-1', tagCode: 'DR', name: 'Diamond Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 1 },
  { id: 'cat-2', tagCode: 'GR', name: 'Gold Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 2 },
  { id: 'cat-3', tagCode: 'GN', name: 'Gold Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 3 },
  { id: 'cat-4', tagCode: 'GB', name: 'Gold Bangles', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 4 },
  { id: 'cat-5', tagCode: 'DN', name: 'Diamond Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 5 },
  { id: 'cat-6', tagCode: 'GE', name: 'Gold Earrings', weightUnit: 'grams (g)', quantityUnit: 'pairs', isActive: true, isCustom: false, sortOrder: 6 },
  { id: 'cat-7', tagCode: 'DE', name: 'Diamond Earrings', weightUnit: 'grams (g)', quantityUnit: 'pairs', isActive: true, isCustom: false, sortOrder: 7 },
  { id: 'cat-8', tagCode: 'GBR', name: 'Gold Bracelets', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 8 },
  { id: 'cat-9', tagCode: 'SR', name: 'Silver Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 9 },
  { id: 'cat-10', tagCode: 'SN', name: 'Silver Necklaces', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 10 },
  { id: 'cat-11', tagCode: 'GSR', name: 'Gemstone Rings', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 11 },
  { id: 'cat-12', tagCode: 'GC', name: 'Gold Chains', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 12 },
  { id: 'cat-13', tagCode: 'GP', name: 'Gold Pendants', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 13 },
  { id: 'cat-14', tagCode: 'DP', name: 'Diamond Pendants', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 14 },
  { id: 'cat-15', tagCode: 'GS', name: 'Gold Sets', weightUnit: 'grams (g)', quantityUnit: 'sets', isActive: true, isCustom: false, sortOrder: 15 },
  { id: 'cat-16', tagCode: 'LD', name: 'Loose Diamonds', weightUnit: 'grams (g)', quantityUnit: 'pieces', isActive: true, isCustom: false, sortOrder: 16 }
];

const defaultInventory = [];
defaultCategories.forEach(cat => {
  defaultInventory.push({
    categoryId: cat.id,
    tagCode: cat.tagCode,
    categoryName: cat.name,
    totalWeight: 1250.567,
    totalQty: 45,
    region: 'uk'
  });
  defaultInventory.push({
    categoryId: cat.id,
    tagCode: cat.tagCode,
    categoryName: cat.name,
    totalWeight: 840.120,
    totalQty: 25,
    region: 'pakistan'
  });
});

const getStoredCategories = () => {
  const data = sessionStorage.getItem(MOCK_CATEGORIES_KEY);
  if (!data) {
    sessionStorage.setItem(MOCK_CATEGORIES_KEY, JSON.stringify(defaultCategories));
    return defaultCategories;
  }
  return JSON.parse(data);
};

const getStoredInventory = () => {
  const data = sessionStorage.getItem(MOCK_INVENTORY_KEY);
  if (!data) {
    sessionStorage.setItem(MOCK_INVENTORY_KEY, JSON.stringify(defaultInventory));
    return defaultInventory;
  }
  return JSON.parse(data);
};

export const inventoryService = {
  getCategories: async () => {
    try {
      const response = await api.get('/categories');
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        return getStoredCategories();
      }
      throw error;
    }
  },

  getInventory: async (region = 'both') => {
    try {
      const response = await api.get(`/inventory?region=${region}`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const inv = getStoredInventory();
        const cats = getStoredCategories();
        const activeCatIds = cats.filter(c => c.isActive).map(c => c.id);
        const filtered = inv.filter(item => activeCatIds.includes(item.categoryId));
        if (region === 'both' || !region) {
          return filtered;
        }
        return filtered.filter(item => item.region === region);
      }
      throw error;
    }
  },

  addStockEntry: async (stockData) => {
    try {
      const response = await api.post('/stock-entries', stockData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const inv = getStoredInventory();
        const cats = getStoredCategories();
        const category = cats.find(c => c.id === stockData.categoryId);
        const categoryName = category ? category.name : 'Unknown';
        const tagCode = category ? category.tagCode : '??';

        const index = inv.findIndex(item => item.categoryId === stockData.categoryId && item.region === stockData.region);
        if (index > -1) {
          inv[index].totalWeight += parseFloat(stockData.weight_grams);
          inv[index].totalQty += parseInt(stockData.quantity, 10);
        } else {
          inv.push({
            categoryId: stockData.categoryId,
            tagCode: tagCode,
            categoryName: categoryName,
            totalWeight: parseFloat(stockData.weight_grams),
            totalQty: parseInt(stockData.quantity, 10),
            region: stockData.region
          });
        }
        sessionStorage.setItem(MOCK_INVENTORY_KEY, JSON.stringify(inv));
        return {
          success: true,
          message: "Stock added successfully",
          updatedInventory: inv
        };
      }
      throw new Error(error.response?.data?.error || 'Failed to add stock');
    }
  },

  addCustomCategory: async (categoryData) => {
    try {
      const response = await api.post('/categories', categoryData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const cats = getStoredCategories();
        if (cats.some(c => c.tagCode.toUpperCase() === categoryData.tagCode.toUpperCase())) {
          throw new Error('Tag code already exists');
        }
        const newCat = {
          id: 'cat-' + Date.now(),
          tagCode: categoryData.tagCode.toUpperCase(),
          name: categoryData.name,
          weightUnit: 'grams (g)',
          quantityUnit: categoryData.quantityUnit || 'pieces',
          isActive: true,
          isCustom: true,
          sortOrder: cats.length + 1
        };
        cats.push(newCat);
        sessionStorage.setItem(MOCK_CATEGORIES_KEY, JSON.stringify(cats));
        return { success: true, category: newCat };
      }
      throw new Error(error.response?.data?.error || 'Failed to create category');
    }
  },

  updateCategory: async (id, categoryData) => {
    try {
      const response = await api.patch(`/categories/${id}`, categoryData);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const cats = getStoredCategories();
        const index = cats.findIndex(c => c.id === id);
        if (index > -1) {
          cats[index].name = categoryData.name;
          if (categoryData.sortOrder !== undefined) {
            cats[index].sortOrder = parseInt(categoryData.sortOrder, 10);
          }
          sessionStorage.setItem(MOCK_CATEGORIES_KEY, JSON.stringify(cats));
          return { success: true, category: cats[index] };
        }
        throw new Error('Category not found');
      }
      throw new Error(error.response?.data?.error || 'Failed to update category');
    }
  },

  deactivateCategory: async (id) => {
    try {
      const response = await api.delete(`/categories/${id}`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const cats = getStoredCategories();
        const index = cats.findIndex(c => c.id === id);
        if (index > -1) {
          cats[index].isActive = false;
          sessionStorage.setItem(MOCK_CATEGORIES_KEY, JSON.stringify(cats));
          return { success: true, message: 'Category deactivated' };
        }
        throw new Error('Category not found');
      }
      throw new Error(error.response?.data?.error || 'Failed to deactivate category');
    }
  },

  reactivateCategory: async (id) => {
    try {
      const response = await api.patch(`/categories/${id}/reactivate`);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK' || !error.response) {
        const cats = getStoredCategories();
        const index = cats.findIndex(c => c.id === id);
        if (index > -1) {
          cats[index].isActive = true;
          sessionStorage.setItem(MOCK_CATEGORIES_KEY, JSON.stringify(cats));
          return { success: true, message: 'Category reactivated' };
        }
        throw new Error('Category not found');
      }
      throw new Error(error.response?.data?.error || 'Failed to reactivate category');
    }
  }
};
