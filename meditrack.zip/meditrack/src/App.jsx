import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import ClinicManagement from './pages/ClinicManagement';
import FinanceReporting from './pages/FinanceReporting';
import PatientManagement from './pages/PatientManagement';
import Appointments from './pages/Appointments';
import Messages from './pages/Messages';
import Settings from './pages/Settings';
import Inventory from './pages/Inventory';
import InventoryReporting from './pages/InventoryReporting';
import './App.css';

function AppContent() {
  const location = useLocation();

  // Core clinics state
  const [clinics, setClinics] = useState([
    { name: 'City Clinic', doctors: 17, appointments: 11, alerts: 1 },
    { name: 'Westside Branch', doctors: 16, appointments: 3, alerts: 1 },
    { name: 'General Hospital', doctors: 3, appointments: 0, alerts: 1 },
  ]);

  // Selected clinic state (shared filter across pages)
  const [activeClinic, setActiveClinic] = useState('City Clinic');

  const isLoginPage = location.pathname === '/login';

  // Determine if the current page should show the secondary wide sidebar
  const showSecondary =
    location.pathname === '/ClinicManagement' ||
    location.pathname === '/FinanceReporting' ||
    location.pathname === '/Inventory' ||
    location.pathname === '/InventoryReporting';

  if (isLoginPage) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  return (
    <div className="min-h-screen bg-lightBlueBg flex flex-col font-sans">
      {/* Top Fixed Navbar */}
      <Navbar
        clinics={clinics}
        activeClinic={activeClinic}
        setActiveClinic={setActiveClinic}
      />

      <div className="flex flex-1 pt-16">
        {/* Navigation Sidebar(s) */}
        <Sidebar showSecondary={showSecondary} />

        {/* Scrollable Main Content Area */}
        <main
          className={`flex-1 p-6 transition-all duration-300 ${
            showSecondary
              ? 'pl-[60px] md:pl-[280px]'
              : 'pl-[60px]'
          }`}
        >
          <div className="max-w-7xl mx-auto h-full">
            <Routes>
              <Route
                path="/ClinicManagement"
                element={
                  <ClinicManagement
                    clinics={clinics}
                    setClinics={setClinics}
                  />
                }
              />
              <Route
                path="/FinanceReporting"
                element={<FinanceReporting activeClinic={activeClinic} />}
              />
              <Route
                path="/Inventory"
                element={<Inventory activeClinic={activeClinic} />}
              />
              <Route
                path="/InventoryReporting"
                element={<InventoryReporting activeClinic={activeClinic} />}
              />
              <Route
                path="/PatientManagement"
                element={<PatientManagement activeClinic={activeClinic} />}
              />
              <Route
                path="/Appointments"
                element={<Appointments activeClinic={activeClinic} />}
              />
              <Route
                path="/Messages"
                element={<Messages />}
              />
              <Route
                path="/Settings"
                element={<Settings />}
              />
              {/* Catch-all redirects to ClinicManagement */}
              <Route path="*" element={<Navigate to="/ClinicManagement" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
