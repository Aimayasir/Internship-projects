import React from 'react';
import { FileBarChart, Download, ArrowDownRight, ArrowUpRight, TrendingUp } from 'lucide-react';

export default function InventoryReporting({ activeClinic }) {
  // Mock reporting data based on active clinic
  const reportingStats = {
    'City Clinic': { usage: '4,820 Units', wastage: '$420.00', turnRate: '4.8 days', trends: '+12.4% Usage' },
    'Westside Branch': { usage: '1,450 Units', wastage: '$120.00', turnRate: '7.2 days', trends: '-2.1% Usage' },
    'General Hospital': { usage: '920 Units', wastage: '$85.00', turnRate: '3.1 days', trends: '+6.8% Usage' }
  };

  const activeStats = reportingStats[activeClinic] || { usage: '0 Units', wastage: '$0.00', turnRate: '0 days', trends: '0% Usage' };

  // Category consumption distribution
  const consumptionCats = [
    { name: 'Medicines', percentage: 65, color: 'bg-primaryBlue', count: '3,120 Tablets' },
    { name: 'Consumables', percentage: 22, color: 'bg-emerald-500', count: '1,050 Units' },
    { name: 'Personal Protective Equipment (PPE)', percentage: 10, color: 'bg-amber-500', count: '480 Units' },
    { name: 'Diagnostic Kits', percentage: 3, color: 'bg-red-500', count: '170 Kits' }
  ];

  // Recent audit log
  const auditLogs = [
    { id: 1, action: 'Stock Replenished', item: 'Paracetamol 500mg', change: '+500 Tablets', user: 'Dr. Masa', date: 'May 25, 11:20 AM' },
    { id: 2, action: 'Stock Depleted (Dispensed)', item: 'Disposable Syringes 5ml', change: '-40 Units', user: 'Dr. Mava', date: 'May 25, 10:45 AM' },
    { id: 3, action: 'Stock Added', item: 'Amoxicillin 250mg', change: '+100 Capsules', user: 'Dr. Abaath', date: 'May 25, 09:30 AM' },
    { id: 4, action: 'Waste Logged (Expired)', item: 'Surgical Masks (3-ply)', change: '-5 Boxes', user: 'System Admin', date: 'May 24, 04:00 PM' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Inventory Reporting</h1>
        <button className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue">
          <Download className="w-4 h-4" />
          <span>Export Inventory Report</span>
        </button>
      </div>

      {/* Summary Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Usage Volume */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-5">
          <div className="text-[10px] font-bold text-textSecondary uppercase tracking-wider mb-1">Monthly Consumption</div>
          <div className="text-xl font-bold text-textPrimary mb-1.5">{activeStats.usage}</div>
          <div className="flex items-center text-xs font-semibold text-emerald-600 gap-0.5">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{activeStats.trends}</span>
          </div>
        </div>

        {/* wastage value */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-5">
          <div className="text-[10px] font-bold text-textSecondary uppercase tracking-wider mb-1">Discarded / Expired Value</div>
          <div className="text-xl font-bold text-textPrimary mb-1.5">{activeStats.wastage}</div>
          <div className="flex items-center text-xs font-semibold text-red-500 gap-0.5">
            <ArrowDownRight className="w-3.5 h-3.5" />
            <span>Loss Logged</span>
          </div>
        </div>

        {/* turnaround rate */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-5">
          <div className="text-[10px] font-bold text-textSecondary uppercase tracking-wider mb-1">Restock Turnaround</div>
          <div className="text-xl font-bold text-textPrimary mb-1.5">{activeStats.turnRate}</div>
          <div className="flex items-center text-xs font-semibold text-emerald-600 gap-0.5">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Optimal Range</span>
          </div>
        </div>

        {/* inventory accuracy */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-5">
          <div className="text-[10px] font-bold text-textSecondary uppercase tracking-wider mb-1">Audit Reconciliation</div>
          <div className="text-xl font-bold text-textPrimary mb-1.5">99.8%</div>
          <div className="flex items-center text-xs font-semibold text-emerald-600 gap-0.5">
            <span>Verified May 25</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        {/* Usage Chart Progress Meters (2/3 width) */}
        <div className="lg:col-span-2 bg-white border border-borderGray rounded-lg shadow-custom p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-textPrimary mb-1">Consumption By Category</h3>
            <p className="text-xs text-textSecondary mb-6">Percentage allocation of total units dispensed in the current month.</p>
            
            <div className="space-y-4">
              {consumptionCats.map((cat, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold text-textPrimary">
                    <span>{cat.name}</span>
                    <span>{cat.percentage}% ({cat.count})</span>
                  </div>
                  {/* Progress Bar Container */}
                  <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${cat.color}`}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Audit Log Activities (1/3 width) */}
        <div className="bg-white border border-borderGray rounded-lg shadow-custom p-6">
          <h3 className="text-base font-bold text-textPrimary mb-4">Recent Audit Activity</h3>
          
          <div className="space-y-4 overflow-y-auto max-h-[300px] pr-1">
            {auditLogs.map((log) => (
              <div key={log.id} className="text-xs border-l-2 border-l-primaryBlue pl-3 py-1 space-y-1">
                <div className="flex justify-between font-semibold text-textPrimary">
                  <span>{log.action}</span>
                  <span className={log.change.startsWith('+') ? 'text-emerald-600' : 'text-red-500'}>
                    {log.change}
                  </span>
                </div>
                <div className="text-[10px] text-textSecondary font-medium">
                  {log.item} &bull; {log.user}
                </div>
                <div className="text-[9px] text-textSecondary font-medium">
                  {log.date}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
