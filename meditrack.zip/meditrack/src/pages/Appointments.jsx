import React, { useState } from 'react';
import { Calendar as CalendarIcon, Clock, Plus, X, User } from 'lucide-react';

export default function Appointments({ activeClinic }) {
  const [showModal, setShowModal] = useState(false);
  const [patientName, setPatientName] = useState('');
  const [doctorName, setDoctorName] = useState('Dr. Masa');
  const [time, setTime] = useState('10:00 AM');
  const [type, setType] = useState('Consultation');

  // Appointments database by clinic
  const [appointmentsList, setAppointmentsList] = useState({
    'City Clinic': [
      { id: 1, patient: 'Anna Sav', doctor: 'Dr. Mava', time: '11:00 AM', type: 'Consultation', status: 'Checked In' },
      { id: 2, patient: 'Anna Darah', doctor: 'Dr. Abhamnah', time: '12:00 PM', type: 'Follow-up', status: 'Checked In' },
      { id: 3, patient: 'Anna Name', doctor: 'Dr. Masa', time: '12:00 PM', type: 'Consultation', status: 'Waiting' },
      { id: 4, patient: 'Anna Ehiram', doctor: 'Dr. Abaath', time: '03:00 PM', type: 'Urgent Care', status: 'Waiting' },
    ],
    'Westside Branch': [
      { id: 5, patient: 'Robb Stark', doctor: 'Dr. Catelyn', time: '09:30 AM', type: 'Consultation', status: 'Checked In' },
      { id: 6, patient: 'Sansa Stark', doctor: 'Dr. Luwin', time: '10:30 AM', type: 'Follow-up', status: 'Waiting' },
    ],
    'General Hospital': [
      { id: 7, patient: 'Jon Snow', doctor: 'Dr. Aemon', time: '09:00 AM', type: 'Surgery Prep', status: 'In Consultation' },
    ]
  });

  const activeAppts = appointmentsList[activeClinic] || [];

  const handleScheduleAppt = (e) => {
    e.preventDefault();
    if (!patientName) return;

    const newAppt = {
      id: Date.now(),
      patient: patientName,
      doctor: doctorName,
      time,
      type,
      status: 'Waiting',
    };

    setAppointmentsList((prev) => ({
      ...prev,
      [activeClinic]: [...(prev[activeClinic] || []), newAppt],
    }));

    setShowModal(false);
    setPatientName('');
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case 'Checked In':
        return 'bg-[#D1FAE5] text-statusGreen border-[#A7F3D0]';
      case 'Waiting':
        return 'bg-[#FEF3C7] text-statusAmber border-[#FDE68A]';
      case 'In Consultation':
        return 'bg-[#DBEAFE] text-statusBlue border-[#BFDBFE]';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Appointments</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Appointment</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Appointments List (2/3 width) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-borderGray rounded-lg shadow-custom p-6">
            <h2 className="text-18px font-bold text-textPrimary mb-4">Today's Schedule ({activeClinic})</h2>
            
            <div className="divide-y divide-gray-100">
              {activeAppts.map((appt) => (
                <div key={appt.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 first:pt-0 last:pb-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-lightBlueBg flex items-center justify-center text-primaryBlue">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-textPrimary">{appt.patient}</h4>
                      <p className="text-xs text-textSecondary">{appt.type} &bull; {appt.doctor}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5 text-xs font-medium text-textSecondary">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span>{appt.time}</span>
                    </div>
                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${getStatusStyle(appt.status)}`}>
                      {appt.status}
                    </span>
                  </div>
                </div>
              ))}
              {activeAppts.length === 0 && (
                <div className="text-center py-12 text-sm text-textSecondary">
                  No appointments scheduled for today in {activeClinic}.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mini Calendar Widgets (1/3 width) */}
        <div className="space-y-6">
          <div className="bg-white border border-borderGray rounded-lg shadow-custom p-6">
            <div className="flex items-center gap-2 mb-4">
              <CalendarIcon className="w-5 h-5 text-primaryBlue" />
              <h3 className="text-sm font-bold text-textPrimary uppercase tracking-wider">Calendar Overview</h3>
            </div>
            
            {/* Simple Grid Calendar */}
            <div className="border border-borderGray rounded-lg p-3">
              <div className="flex justify-between items-center border-b border-gray-100 pb-2 mb-3">
                <span className="text-xs font-bold text-textPrimary">May 2026</span>
                <span className="text-[10px] text-textSecondary font-semibold">Today: May 25</span>
              </div>
              <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-textSecondary mb-2">
                <div>Su</div><div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div>
              </div>
              <div className="grid grid-cols-7 gap-1 text-center text-xs">
                {/* Pad days */}
                <div className="text-gray-300 py-1">26</div>
                <div className="text-gray-300 py-1">27</div>
                <div className="text-gray-300 py-1">28</div>
                <div className="text-gray-300 py-1">29</div>
                <div className="text-gray-300 py-1">30</div>
                <div className="py-1">1</div>
                <div className="py-1">2</div>
                
                <div className="py-1">3</div><div className="py-1">4</div><div className="py-1">5</div><div className="py-1">6</div><div className="py-1">7</div><div className="py-1">8</div><div className="py-1">9</div>
                <div className="py-1">10</div><div className="py-1">11</div><div className="py-1">12</div><div className="py-1">13</div><div className="py-1">14</div><div className="py-1">15</div><div className="py-1">16</div>
                <div className="py-1">17</div><div className="py-1">18</div><div className="py-1">19</div><div className="py-1">20</div><div className="py-1">21</div><div className="py-1">22</div><div className="py-1">23</div>
                <div className="py-1">24</div>
                {/* Active Highlight */}
                <div className="bg-primaryBlue text-white font-bold rounded-full py-1">25</div>
                <div className="py-1">26</div><div className="py-1">27</div><div className="py-1">28</div><div className="py-1">29</div><div className="py-1">30</div><div className="py-1">31</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-900/50 flex justify-center items-center p-4 z-50">
          <div className="fixed inset-0" onClick={() => setShowModal(false)} />
          <div className="bg-white rounded-xl border border-borderGray shadow-modal w-full max-w-md p-6 relative z-10">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1.5 hover:bg-gray-50 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-18px font-bold text-textPrimary mb-6">Schedule Appointment</h2>

            <form onSubmit={handleScheduleAppt} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Patient Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jane Doe"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Assigned Doctor
                </label>
                <select
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                >
                  <option value="Dr. Mava">Dr. Mava</option>
                  <option value="Dr. Abhamnah">Dr. Abhamnah</option>
                  <option value="Dr. Masa">Dr. Masa</option>
                  <option value="Dr. Abaath">Dr. Abaath</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Appointment Time
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 10:00 AM"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Appointment Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  >
                    <option value="Consultation">Consultation</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Urgent Care">Urgent Care</option>
                    <option value="Check-up">Check-up</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-borderGray text-textSecondary font-semibold rounded-md hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-semibold rounded-md transition-colors"
                >
                  Confirm Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
