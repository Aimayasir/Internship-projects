import React, { useState } from 'react';
import { Download, MoreHorizontal } from 'lucide-react';

export default function FinanceReporting({ activeClinic }) {
  // Checkbox state for rows
  const [selectedRows, setSelectedRows] = useState({});

  // Mock financial data mapped by clinic
  const financeData = {
    'City Clinic': [
      { id: 1, name: 'Anna Sav', location: 'City Clinic', service: 'Consultation', fee: '₹1000.00', hospital: '$290.00', doctor: '$230.00' },
      { id: 2, name: 'Anna Darah', location: 'City Clinic', service: 'Panemts', fee: '₹1500.00', hospital: '$350.00', doctor: '$230.00' },
      { id: 3, name: 'Anna Name', location: 'City Clinic', service: 'Consultation', fee: '₹2000.00', hospital: '$450.00', doctor: '$130.00' },
      { id: 4, name: 'Anna Ehiram', location: 'City Clinic', service: 'Consultation', fee: '₹2000.00', hospital: '$400.00', doctor: '$100.00' },
      { id: 5, name: 'Medih Rarah', location: 'City Clinic', service: 'English', fee: '₹1500.00', hospital: '$350.00', doctor: '$200.00' },
      { id: 6, name: 'John Adam', location: 'City Clinic', service: 'Service', fee: '₹2000.00', hospital: '$300.00', doctor: '$50.00' },
      { id: 7, name: 'Covari Shutt', location: 'City Clinic', service: 'Consultation', fee: '₹1300.00', hospital: '$100.00', doctor: '$50.00' },
    ],
    'Westside Branch': [
      { id: 10, name: 'Bredon Stark', location: 'Westside Branch', service: 'Consultation', fee: '₹1200.00', hospital: '$320.00', doctor: '$250.00' },
      { id: 11, name: 'Lyanna Mormont', location: 'Westside Branch', service: 'Service', fee: '₹1800.00', hospital: '$400.00', doctor: '$280.00' },
      { id: 12, name: 'Arya Sand', location: 'Westside Branch', service: 'Panemts', fee: '₹1500.00', hospital: '$350.00', doctor: '$230.00' },
    ],
    'General Hospital': [
      { id: 20, name: 'Jaime Lanny', location: 'General Hospital', service: 'Consultation', fee: '₹2500.00', hospital: '$600.00', doctor: '$400.00' },
      { id: 21, name: 'Tyrion Short', location: 'General Hospital', service: 'English', fee: '₹1500.00', hospital: '$350.00', doctor: '$200.00' },
    ]
  };

  const records = financeData[activeClinic] || [];

  // Summary counts based on clinic
  const getStats = () => {
    switch (activeClinic) {
      case 'City Clinic':
        return { revenue: '$14,630.00', collections: '$17.00', splits: '0' };
      case 'Westside Branch':
        return { revenue: '$4,500.00', collections: '$120.00', splits: '2' };
      case 'General Hospital':
        return { revenue: '$8,900.00', collections: '$0.00', splits: '1' };
      default:
        return { revenue: '$0.00', collections: '$0.00', splits: '0' };
    }
  };

  const stats = getStats();

  const handleSelectAll = (e) => {
    const checked = e.target.checked;
    const newSelected = {};
    if (checked) {
      records.forEach((row) => {
        newSelected[row.id] = true;
      });
    }
    setSelectedRows(newSelected);
  };

  const handleSelectRow = (id) => {
    setSelectedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const isAllSelected = records.length > 0 && records.every((row) => selectedRows[row.id]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Finance Reporting</h1>
        <button className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue">
          <Download className="w-4 h-4" />
          <span>Generate Monthly Report</span>
        </button>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Total Revenue */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 relative">
          <button className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1 rounded-full hover:bg-gray-50 transition-colors">
            <MoreHorizontal className="w-4 h-4" />
          </button>
          <div className="text-sm font-semibold text-textSecondary uppercase tracking-wider mb-2">
            Total Revenue
          </div>
          <div className="text-3xl font-bold text-textPrimary">{stats.revenue}</div>
        </div>

        {/* Today's Collections */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 relative">
          <button className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1 rounded-full hover:bg-gray-50 transition-colors">
            <MoreHorizontal className="w-4 h-4" />
          </button>
          <div className="text-sm font-semibold text-textSecondary uppercase tracking-wider mb-2">
            Today's Collections
          </div>
          <div className="text-3xl font-bold text-textPrimary">{stats.collections}</div>
        </div>

        {/* Pending Splits */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 relative">
          <button className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1 rounded-full hover:bg-gray-50 transition-colors">
            <MoreHorizontal className="w-4 h-4" />
          </button>
          <div className="text-sm font-semibold text-textSecondary uppercase tracking-wider mb-2">
            Pending Splits
          </div>
          <div className="text-3xl font-bold text-textPrimary">{stats.splits}</div>
        </div>
      </div>

      {/* Financial Records Data Table */}
      <div className="bg-white rounded-lg border border-borderGray shadow-custom overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-borderGray">
                <th className="px-6 py-4 w-12">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={handleSelectAll}
                    className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                  />
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Patient Name
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Clinic Location
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Service Rendered
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Total Fee
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Hospital Split
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Doctor Split
                </th>
                <th className="px-6 py-4 w-16"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {records.length > 0 ? (
                records.map((row) => (
                  <tr
                    key={row.id}
                    className="hover:bg-[#F9FAFB] transition-colors"
                  >
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={!!selectedRows[row.id]}
                        onChange={() => handleSelectRow(row.id)}
                        className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                      />
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-textPrimary">
                      {row.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary">
                      {row.location}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary">
                      {row.service}
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-textPrimary">
                      {row.fee}
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-textPrimary">
                      {row.hospital}
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-textPrimary">
                      {row.doctor}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-textSecondary hover:text-textPrimary p-1 rounded hover:bg-gray-100 transition-colors">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="px-6 py-12 text-center text-sm text-textSecondary">
                    No transactions found for {activeClinic}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
