import React, { useState } from 'react';
import { MoreVertical, Plus, X, Eye, EyeOff, MoreHorizontal } from 'lucide-react';

export default function PatientManagement({ activeClinic }) {
  // State for modal visibility
  const [showModal, setShowModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [cnic, setCnic] = useState('CNIC00000003'); // Prefilled example
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('+112-4567890');

  // Checkbox selection state
  const [selectedRows, setSelectedRows] = useState({});

  // Dynamic patient list by clinic
  const [patientsData, setPatientsData] = useState({
    'City Clinic': [
      { id: 1, name: 'Anna Sav', cnic: 'CNIC00000001', phone: '+112-4567890', status: 'Checked In' },
      { id: 2, name: 'Anna Darah', cnic: 'CNIC00000002', phone: '+112-4567890', status: 'Checked In' },
      { id: 3, name: 'Anna Name', cnic: 'CNIC00000003', phone: '+112-4567890', status: 'Waiting' },
      { id: 4, name: 'Anna Ehiram', cnic: 'CNIC00000004', phone: '+112-4567890', status: 'Waiting' },
      { id: 5, name: 'Medih Rarah', cnic: 'CNIC00000005', phone: '+112-4567890', status: 'In Consultation' },
      { id: 6, name: 'Maranad Anmilr', cnic: 'CNIC00000006', phone: '+112-4567890', status: 'In Consultation' },
      { id: 7, name: 'Jahn Adam', cnic: 'CNIC00000007', phone: '+112-4567890', status: 'In Consultation' },
      { id: 8, name: 'Josah Name', cnic: 'CNIC00000020', phone: '+112-4567890', status: 'In Consultation' },
      { id: 9, name: 'Elinna Chray', cnic: 'CNIC00000033', phone: '+112-4567890', status: 'Checked In' },
      { id: 10, name: 'Covari Shutt', cnic: 'CNIC00000083', phone: '+112-4567890', status: 'Waiting' },
    ],
    'Westside Branch': [
      { id: 11, name: 'Robb Stark', cnic: 'CNIC00000101', phone: '+112-4567890', status: 'Checked In' },
      { id: 12, name: 'Sansa Stark', cnic: 'CNIC00000102', phone: '+112-4567890', status: 'Waiting' },
      { id: 13, name: 'Bran Stark', cnic: 'CNIC00000103', phone: '+112-4567890', status: 'In Consultation' },
    ],
    'General Hospital': [
      { id: 14, name: 'Jon Snow', cnic: 'CNIC00000201', phone: '+112-4567890', status: 'In Consultation' },
      { id: 15, name: 'Daenerys Targ', cnic: 'CNIC00000202', phone: '+112-4567890', status: 'Checked In' },
    ]
  });

  const queueData = {
    'City Clinic': [
      { id: 1, slot: '09:00', time: '11:00 AM', doctor: 'Mava' },
      { id: 2, slot: '10:00', time: '12:00 AM', doctor: 'Abhamnah' },
      { id: 3, slot: '12:00', time: '12:00 PM', doctor: 'Masa' },
      { id: 4, slot: '13:00', time: '03:00 AM', doctor: 'Abaath' },
    ],
    'Westside Branch': [
      { id: 5, slot: '09:00', time: '09:30 AM', doctor: 'Catelyn' },
      { id: 6, slot: '10:00', time: '10:30 AM', doctor: 'Luwin' },
    ],
    'General Hospital': [
      { id: 7, slot: '09:00', time: '09:00 AM', doctor: 'Aemon' },
    ]
  };

  const activePatients = patientsData[activeClinic] || [];
  const activeQueue = queueData[activeClinic] || [];

  const handleRegisterPatient = (e) => {
    e.preventDefault();
    if (!name) return;

    const newPatient = {
      id: Date.now(),
      name,
      cnic,
      phone: phoneNumber,
      status: 'Waiting', // Default status for new registrations
    };

    setPatientsData((prev) => ({
      ...prev,
      [activeClinic]: [newPatient, ...(prev[activeClinic] || [])],
    }));

    setShowModal(false);
    // Reset form fields
    setName('');
    setCnic(`CNIC00000${Math.floor(Math.random() * 1000)}`);
    setPassword('');
    setPhoneNumber('+112-4567890');
  };

  const handleSelectAll = (e) => {
    const checked = e.target.checked;
    const newSelected = {};
    if (checked) {
      activePatients.forEach((p) => {
        newSelected[p.id] = true;
      });
    }
    setSelectedRows(newSelected);
  };

  const handleSelectRow = (id) => {
    setSelectedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const isAllSelected = activePatients.length > 0 && activePatients.every((p) => selectedRows[p.id]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Checked In':
        return (
          <span className="bg-[#D1FAE5] text-statusGreen text-xs font-semibold px-2.5 py-1 rounded-full border border-[#A7F3D0]">
            Checked In
          </span>
        );
      case 'Waiting':
        return (
          <span className="bg-[#FEF3C7] text-statusAmber text-xs font-semibold px-2.5 py-1 rounded-full border border-[#FDE68A]">
            Waiting
          </span>
        );
      case 'In Consultation':
        return (
          <span className="bg-[#DBEAFE] text-statusBlue text-xs font-semibold px-2.5 py-1 rounded-full border border-[#BFDBFE]">
            In Consultation
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex gap-6 h-full items-stretch">
      {/* 1. Left Queue Panel (260px) */}
      <div className="w-[260px] flex-shrink-0 bg-white border border-borderGray rounded-lg p-4 shadow-custom flex flex-col">
        <h2 className="text-lg font-bold text-textPrimary mb-4">Today's Queue</h2>
        <div className="space-y-4 overflow-y-auto flex-1 pr-1">
          {activeQueue.map((item) => (
            <div key={item.id} className="flex gap-3 items-start">
              {/* Slot time label */}
              <div className="text-xs font-semibold text-textSecondary w-10 pt-3">
                {item.slot}
              </div>
              {/* Appointment Card */}
              <div className="flex-1 bg-white border border-borderGray border-l-4 border-l-statusGreen rounded-lg p-3 shadow-custom relative group">
                <button className="absolute top-2.5 right-2 text-textSecondary hover:text-textPrimary p-0.5 rounded hover:bg-gray-50 opacity-0 group-hover:opacity-100 transition-all">
                  <MoreVertical className="w-4 h-4" />
                </button>
                <div className="text-sm font-bold text-textPrimary mb-1">
                  {item.time}
                </div>
                <div className="text-xs text-textSecondary font-medium">
                  Doctor: {item.doctor}
                </div>
              </div>
            </div>
          ))}
          {activeQueue.length === 0 && (
            <div className="text-center text-xs text-textSecondary py-8">
              No appointments scheduled.
            </div>
          )}
        </div>
      </div>

      {/* 2. Main Patient Table Area */}
      <div className="flex-1 bg-white border border-borderGray rounded-lg shadow-custom flex flex-col overflow-hidden">
        {/* Table Header Controls */}
        <div className="p-6 border-b border-borderGray flex justify-between items-center bg-white">
          <h1 className="text-24px font-bold text-textPrimary">Patient Management</h1>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
          >
            <Plus className="w-4 h-4" />
            <span>New Registration</span>
          </button>
        </div>

        {/* Data Table */}
        <div className="overflow-y-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-borderGray sticky top-0 z-10">
                <th className="px-6 py-4 w-12">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={handleSelectAll}
                    className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                  />
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  CNIC
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Phone No.
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Appointment
                </th>
                <th className="px-6 py-4 w-16"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {activePatients.length > 0 ? (
                activePatients.map((patient) => (
                  <tr
                    key={patient.id}
                    className="hover:bg-[#F9FAFB] transition-colors"
                  >
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={!!selectedRows[patient.id]}
                        onChange={() => handleSelectRow(patient.id)}
                        className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                      />
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-textPrimary">
                      {patient.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary font-medium">
                      {patient.cnic}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary font-medium">
                      {patient.phone}
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(patient.status)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-textSecondary hover:text-textPrimary p-1 rounded hover:bg-gray-100 transition-colors">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-6 py-12 text-center text-sm text-textSecondary bg-white">
                    No patient records found for {activeClinic}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. New Patient Registration Modal Overlay */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-900/50 flex justify-center items-center p-4 z-50 animate-fade-in">
          {/* Backdrop dismiss */}
          <div className="fixed inset-0" onClick={() => setShowModal(false)} />

          <div className="bg-white rounded-xl border border-borderGray shadow-modal w-full max-w-[500px] p-6 relative z-10 max-h-[90vh] overflow-y-auto">
            {/* Close button */}
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1.5 hover:bg-gray-50 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-textPrimary mb-6">New Patient Registration</h2>

            <form onSubmit={handleRegisterPatient} className="space-y-4">
              {/* Name (with Email Address placeholder) */}
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Email Address"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue focus:border-transparent transition-all"
                />
              </div>

              {/* CNIC (prefilled example) */}
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  CNIC
                </label>
                <input
                  type="text"
                  required
                  placeholder="CNIC00000003"
                  value={cnic}
                  onChange={(e) => setCnic(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue focus:border-transparent transition-all"
                />
              </div>

              {/* Password (with eye toggle) */}
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue focus:border-transparent transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-textSecondary hover:text-textPrimary focus:outline-none"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Phone Number
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+112-4567890"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue focus:border-transparent transition-all"
                />
              </div>

              {/* Form Buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-borderGray text-textSecondary font-semibold rounded-md hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-semibold rounded-md transition-colors"
                >
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
