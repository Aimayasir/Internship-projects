import React, { useState } from 'react';
import { Plus, X, MoreHorizontal, AlertTriangle, Package, ShieldAlert } from 'lucide-react';

export default function Inventory({ activeClinic }) {
  const [showModal, setShowModal] = useState(false);
  const [itemName, setItemName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('Medicine');
  const [stockQty, setStockQty] = useState('');
  const [unit, setUnit] = useState('Vials');

  // Selected rows checkboxes
  const [selectedRows, setSelectedRows] = useState({});

  // Dynamic inventory data by clinic
  const [inventoryList, setInventoryList] = useState({
    'City Clinic': [
      { id: 1, name: 'Paracetamol 500mg', sku: 'MED-PR-500', category: 'Medicine', qty: 1200, unit: 'Tablets', status: 'In Stock' },
      { id: 2, name: 'Amoxicillin 250mg', sku: 'MED-AM-250', category: 'Medicine', qty: 80, unit: 'Capsules', status: 'Low Stock' },
      { id: 3, name: 'Disposable Syringes 5ml', sku: 'CON-SY-05', category: 'Consumable', qty: 2500, unit: 'Units', status: 'In Stock' },
      { id: 4, name: 'Surgical Masks (3-ply)', sku: 'PPE-MS-3P', category: 'PPE', qty: 15, unit: 'Boxes', status: 'Out of Stock' },
      { id: 5, name: 'Adrenaline Injection', sku: 'MED-AD-01', category: 'Medicine', qty: 45, unit: 'Ampoules', status: 'Low Stock' },
    ],
    'Westside Branch': [
      { id: 6, name: 'Ibuprofen 400mg', sku: 'MED-IB-400', category: 'Medicine', qty: 600, unit: 'Tablets', status: 'In Stock' },
      { id: 7, name: 'Sterile Gauze Pads', sku: 'CON-GP-04', category: 'Consumable', qty: 12, unit: 'Packs', status: 'Low Stock' },
      { id: 8, name: 'N95 Respirators', sku: 'PPE-N95-R', category: 'PPE', qty: 120, unit: 'Units', status: 'In Stock' },
    ],
    'General Hospital': [
      { id: 9, name: 'Saline IV Solution 0.9%', sku: 'MED-SL-IV', category: 'Medicine', qty: 150, unit: 'Bags', status: 'In Stock' },
      { id: 10, name: 'Surgical Gloves (Size 7)', sku: 'PPE-GL-07', category: 'PPE', qty: 8, unit: 'Boxes', status: 'Low Stock' },
    ]
  });

  const activeInventory = inventoryList[activeClinic] || [];

  const handleAddItem = (e) => {
    e.preventDefault();
    if (!itemName || !stockQty) return;

    const qtyVal = parseInt(stockQty) || 0;
    let status = 'In Stock';
    if (qtyVal === 0) status = 'Out of Stock';
    else if (qtyVal < 100) status = 'Low Stock';

    const newItem = {
      id: Date.now(),
      name: itemName,
      sku: sku || `SKU-${Math.floor(Math.random() * 10000)}`,
      category,
      qty: qtyVal,
      unit,
      status,
    };

    setInventoryList((prev) => ({
      ...prev,
      [activeClinic]: [...(prev[activeClinic] || []), newItem],
    }));

    setShowModal(false);
    setItemName('');
    setSku('');
    setCategory('Medicine');
    setStockQty('');
    setUnit('Units');
  };

  const handleSelectAll = (e) => {
    const checked = e.target.checked;
    const newSelected = {};
    if (checked) {
      activeInventory.forEach((item) => {
        newSelected[item.id] = true;
      });
    }
    setSelectedRows(newSelected);
  };

  const handleSelectRow = (id) => {
    setSelectedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const isAllSelected = activeInventory.length > 0 && activeInventory.every((item) => selectedRows[item.id]);

  // Aggregate stats
  const totalItems = activeInventory.length;
  const lowStockCount = activeInventory.filter((i) => i.status === 'Low Stock').length;
  const outOfStockCount = activeInventory.filter((i) => i.status === 'Out of Stock').length;

  const getStatusStyle = (status) => {
    switch (status) {
      case 'In Stock':
        return 'bg-emerald-50 text-statusGreen border-emerald-200';
      case 'Low Stock':
        return 'bg-[#FEF3C7] text-statusAmber border-[#FDE68A]';
      case 'Out of Stock':
        return 'bg-red-50 text-red-600 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Inventory Management</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
        >
          <Plus className="w-4 h-4" />
          <span>Add Inventory Item</span>
        </button>
      </div>

      {/* Roster Summary Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Total Stocked Items */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-primaryBlue flex items-center justify-center flex-shrink-0">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-textSecondary uppercase tracking-wider mb-0.5">Total Unique Items</div>
            <div className="text-2xl font-bold text-textPrimary">{totalItems}</div>
          </div>
        </div>

        {/* Low Stock Warn */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-statusAmber flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-textSecondary uppercase tracking-wider mb-0.5">Low Stock Warnings</div>
            <div className="text-2xl font-bold text-textPrimary">{lowStockCount}</div>
          </div>
        </div>

        {/* Critical Depletion */}
        <div className="bg-white rounded-lg border border-borderGray shadow-custom p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center flex-shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-textSecondary uppercase tracking-wider mb-0.5">Out of Stock Items</div>
            <div className="text-2xl font-bold text-textPrimary">{outOfStockCount}</div>
          </div>
        </div>
      </div>

      {/* Inventory Data Table */}
      <div className="bg-white rounded-lg border border-borderGray shadow-custom overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-borderGray">
                <th className="px-6 py-4 w-12">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={handleSelectAll}
                    className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                  />
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Item Name
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  SKU
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Stock Qty
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Unit
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-textSecondary uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 w-16"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {activeInventory.length > 0 ? (
                activeInventory.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-[#F9FAFB] transition-colors"
                  >
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={!!selectedRows[item.id]}
                        onChange={() => handleSelectRow(item.id)}
                        className="w-4 h-4 text-primaryBlue border-gray-300 rounded focus:ring-primaryBlue"
                      />
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-textPrimary">
                      {item.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary font-medium">
                      {item.sku}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary font-medium">
                      {item.category}
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-textPrimary">
                      {item.qty.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-textSecondary">
                      {item.unit}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${getStatusStyle(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-textSecondary hover:text-textPrimary p-1 rounded hover:bg-gray-100 transition-colors">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="px-6 py-12 text-center text-sm text-textSecondary bg-white">
                    No inventory records found for {activeClinic}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Supply Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-900/50 flex justify-center items-center p-4 z-50">
          <div className="fixed inset-0" onClick={() => setShowModal(false)} />
          <div className="bg-white rounded-xl border border-borderGray shadow-modal w-full max-w-md p-6 relative z-10">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1.5 hover:bg-gray-50 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-18px font-bold text-textPrimary mb-6">Add Supply Item</h2>

            <form onSubmit={handleAddItem} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                  Item Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Syringes 5ml"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    SKU Code
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. CON-SY-05"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  >
                    <option value="Medicine">Medicine</option>
                    <option value="Consumable">Consumable</option>
                    <option value="PPE">PPE</option>
                    <option value="Equipment">Equipment</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Stock Quantity
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="0"
                    value={stockQty}
                    onChange={(e) => setStockQty(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Unit Type
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Tablets, Vials"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-borderGray text-textSecondary font-semibold rounded-md hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-semibold rounded-md transition-colors"
                >
                  Record Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
