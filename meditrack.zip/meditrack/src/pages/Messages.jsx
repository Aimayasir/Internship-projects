import React, { useState } from 'react';
import { Search, Send, User } from 'lucide-react';

export default function Messages() {
  const [activeChatId, setActiveChatId] = useState(1);
  const [typedMessage, setTypedMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Initial messages state
  const [conversations, setConversations] = useState([
    {
      id: 1,
      name: 'Dr. Mava',
      role: 'MD Cardiology',
      unread: true,
      messages: [
        { sender: 'incoming', text: 'Hi, did you review the lab reports for Anna Sav?', time: '10:42 AM' },
        { sender: 'outgoing', text: 'Yes Doctor, I uploaded them to the file section. Blood counts are normal.', time: '10:45 AM' },
        { sender: 'incoming', text: 'Excellent. Please schedule a follow-up for next Tuesday.', time: '10:48 AM' },
      ]
    },
    {
      id: 2,
      name: 'Anna Darah',
      role: 'Patient',
      unread: false,
      messages: [
        { sender: 'incoming', text: 'Is Dr. Masa available for consultation today?', time: '09:15 AM' },
        { sender: 'outgoing', text: 'Dr. Masa is in consultations from 12:00 PM to 04:00 PM. Would you like to reserve a slot?', time: '09:20 AM' },
        { sender: 'incoming', text: 'Yes, please book the 12:00 PM slot for me.', time: '09:22 AM' },
      ]
    },
    {
      id: 3,
      name: 'Dr. Abhamnah',
      role: 'General Physician',
      unread: false,
      messages: [
        { sender: 'outgoing', text: 'Doctor, the new medical supplies have arrived at Westside Branch.', time: 'Yesterday' },
        { sender: 'incoming', text: 'Great, thanks for the update. I will inspect the inventory after rounds.', time: 'Yesterday' },
      ]
    }
  ]);

  const activeChat = conversations.find(c => c.id === activeChatId) || conversations[0];

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!typedMessage.trim()) return;

    const newMsg = {
      sender: 'outgoing',
      text: typedMessage,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setConversations(prevConvs =>
      prevConvs.map(conv => {
        if (conv.id === activeChatId) {
          return {
            ...conv,
            unread: false,
            messages: [...conv.messages, newMsg]
          };
        }
        return conv;
      })
    );

    setTypedMessage('');
  };

  const filteredConvs = conversations.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex gap-6 h-[calc(100vh-160px)] items-stretch">
      {/* Left Chat List (320px) */}
      <div className="w-[320px] bg-white border border-borderGray rounded-lg shadow-custom flex flex-col overflow-hidden">
        {/* Search */}
        <div className="p-4 border-b border-borderGray">
          <div className="relative">
            <Search className="w-4 h-4 text-textSecondary absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
            />
          </div>
        </div>

        {/* Chat List Items */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
          {filteredConvs.map((conv) => {
            const lastMsg = conv.messages[conv.messages.length - 1];
            return (
              <button
                key={conv.id}
                onClick={() => {
                  setActiveChatId(conv.id);
                  // Mark as read
                  setConversations(prev =>
                    prev.map(c => c.id === conv.id ? { ...c, unread: false } : c)
                  );
                }}
                className={`w-full text-left p-4 flex gap-3 transition-colors hover:bg-gray-50 ${
                  activeChatId === conv.id ? 'bg-lightBlueBg/50 border-r-2 border-r-primaryBlue' : ''
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-lightBlueBg flex items-center justify-center text-primaryBlue font-semibold flex-shrink-0">
                  {conv.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <h4 className="text-sm font-semibold text-textPrimary truncate">{conv.name}</h4>
                    <span className="text-[10px] text-textSecondary">{lastMsg ? lastMsg.time : ''}</span>
                  </div>
                  <p className="text-xs text-textSecondary truncate">{conv.role}</p>
                  <p className={`text-xs mt-1 truncate ${conv.unread ? 'text-primaryBlue font-semibold' : 'text-textSecondary'}`}>
                    {lastMsg ? lastMsg.text : ''}
                  </p>
                </div>
                {conv.unread && (
                  <div className="w-2.5 h-2.5 rounded-full bg-primaryBlue self-center flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Right Conversation Window */}
      <div className="flex-1 bg-white border border-borderGray rounded-lg shadow-custom flex flex-col overflow-hidden">
        {/* Active Header */}
        <div className="p-4 border-b border-borderGray flex items-center gap-3 bg-white">
          <div className="w-10 h-10 rounded-full bg-lightBlueBg flex items-center justify-center text-primaryBlue font-bold">
            {activeChat.name.charAt(0)}
          </div>
          <div>
            <h3 className="text-sm font-bold text-textPrimary">{activeChat.name}</h3>
            <p className="text-xs text-textSecondary">{activeChat.role} &bull; Active Now</p>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50">
          {activeChat.messages.map((msg, i) => {
            const isOutgoing = msg.sender === 'outgoing';
            return (
              <div key={i} className={`flex ${isOutgoing ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] rounded-lg p-3 shadow-custom text-sm ${
                  isOutgoing
                    ? 'bg-primaryBlue text-white rounded-br-none'
                    : 'bg-white text-textPrimary border border-borderGray rounded-bl-none'
                }`}>
                  <p>{msg.text}</p>
                  <p className={`text-[9px] mt-1 text-right ${isOutgoing ? 'text-blue-100' : 'text-textSecondary'}`}>
                    {msg.time}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Message Input Form */}
        <form onSubmit={handleSendMessage} className="p-4 border-t border-borderGray bg-white flex gap-2">
          <input
            type="text"
            placeholder="Type a message..."
            value={typedMessage}
            onChange={(e) => setTypedMessage(e.target.value)}
            className="flex-1 px-4 py-2.5 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
          />
          <button
            type="submit"
            className="p-2.5 bg-primaryBlue hover:bg-[#1D4ED8] text-white rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
