import React, { useState } from 'react';
import { Settings as SettingsIcon, Shield, Bell, CheckCircle } from 'lucide-react';

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);

  // Profile forms state
  const [clinicName, setClinicName] = useState('Meditrack City Clinic');
  const [address, setAddress] = useState('123 Health Street, City Center');
  const [phone, setPhone] = useState('+112-4567890');

  // Notifications state
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsQueue, setSmsQueue] = useState(true);
  const [inventoryAlerts, setInventoryAlerts] = useState(false);

  // Security state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const handleSave = (e) => {
    e.preventDefault();
    setShowSuccessAlert(true);
    setTimeout(() => {
      setShowSuccessAlert(false);
    }, 3000);

    // Reset password fields if in security tab
    if (activeTab === 'security') {
      setCurrentPassword('');
      setNewPassword('');
    }
  };

  const tabs = [
    { id: 'profile', label: 'Clinic Profile', icon: SettingsIcon },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Settings</h1>
      </div>

      {showSuccessAlert && (
        <div className="bg-emerald-50 border border-emerald-200 text-statusGreen px-4 py-3 rounded-lg flex items-center gap-2 animate-fade-in shadow-custom">
          <CheckCircle className="w-5 h-5 text-statusGreen" />
          <span className="text-sm font-semibold">Settings saved successfully!</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
        {/* Tab Controls (Left Sidebar Menu) */}
        <div className="bg-white border border-borderGray rounded-lg shadow-custom p-2 space-y-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-semibold transition-all text-left ${
                  active
                    ? 'bg-lightBlueBg text-primaryBlue shadow-custom'
                    : 'text-textSecondary hover:text-textPrimary hover:bg-gray-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Contents (Right Panel) */}
        <div className="md:col-span-3 bg-white border border-borderGray rounded-lg shadow-custom p-6">
          <form onSubmit={handleSave} className="space-y-6">
            
            {activeTab === 'profile' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-textPrimary border-b border-gray-100 pb-2">Clinic Profile Settings</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                      Clinic Name
                    </label>
                    <input
                      type="text"
                      required
                      value={clinicName}
                      onChange={(e) => setClinicName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                      Contact Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Address
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h3 className="text-lg font-bold text-textPrimary border-b border-gray-100 pb-2">Notification Preferences</h3>
                
                <div className="space-y-4">
                  {/* Item 1 */}
                  <div className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div>
                      <h4 className="text-sm font-semibold text-textPrimary">Email Reports</h4>
                      <p className="text-xs text-textSecondary">Receive daily and weekly diagnostic summaries via email</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEmailAlerts(!emailAlerts)}
                      className={`w-11 h-6 flex items-center rounded-full p-1 transition-all ${
                        emailAlerts ? 'bg-primaryBlue' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-all ${
                        emailAlerts ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Item 2 */}
                  <div className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div>
                      <h4 className="text-sm font-semibold text-textPrimary">SMS Queue Reminders</h4>
                      <p className="text-xs text-textSecondary">Alert patients automatically when they are next in line</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSmsQueue(!smsQueue)}
                      className={`w-11 h-6 flex items-center rounded-full p-1 transition-all ${
                        smsQueue ? 'bg-primaryBlue' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-all ${
                        smsQueue ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Item 3 */}
                  <div className="flex items-center justify-between py-2">
                    <div>
                      <h4 className="text-sm font-semibold text-textPrimary">Inventory Alert Thresholds</h4>
                      <p className="text-xs text-textSecondary">Ping clinicians immediately when medicine stock falls below 10%</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setInventoryAlerts(!inventoryAlerts)}
                      className={`w-11 h-6 flex items-center rounded-full p-1 transition-all ${
                        inventoryAlerts ? 'bg-primaryBlue' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-all ${
                        inventoryAlerts ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-textPrimary border-b border-gray-100 pb-2">Change Password</h3>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full max-w-md px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-textSecondary uppercase tracking-wider mb-1.5">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full max-w-md px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
              </div>
            )}

            {/* Save Button */}
            <div className="pt-4 border-t border-gray-100 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-semibold rounded-md shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
              >
                Save Settings
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
}
