import React, { useState } from 'react';
import { MoreVertical, Plus, X } from 'lucide-react';

export default function ClinicManagement({ clinics, setClinics }) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newClinicName, setNewClinicName] = useState('');
  const [doctors, setDoctors] = useState('');
  const [appointments, setAppointments] = useState('');
  const [alerts, setAlerts] = useState('');

  const handleAddClinic = (e) => {
    e.preventDefault();
    if (!newClinicName) return;

    const newClinic = {
      name: newClinicName,
      doctors: parseInt(doctors) || 0,
      appointments: parseInt(appointments) || 0,
      alerts: parseInt(alerts) || 0,
    };

    setClinics([...clinics, newClinic]);
    setShowAddModal(false);
    // Reset form
    setNewClinicName('');
    setDoctors('');
    setAppointments('');
    setAlerts('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-24px font-bold text-textPrimary">Clinic Management</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-medium rounded-md shadow-sm hover:shadow transition-colors focus:outline-none focus:ring-2 focus:ring-primaryBlue"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Clinic</span>
        </button>
      </div>

      {/* Grid of Clinic Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {clinics.map((clinic, index) => (
          <div
            key={index}
            className="bg-white rounded-lg border border-borderGray shadow-custom p-6 relative hover:shadow-md transition-all group"
          >
            {/* 3-Dot Actions */}
            <button className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1 rounded-full hover:bg-gray-50 transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>

            {/* Clinic Name */}
            <h3 className="text-18px font-semibold text-textPrimary mb-6 pr-6">
              {clinic.name}
            </h3>

            {/* Statistics */}
            <div className="space-y-4 text-14px">
              <div className="flex justify-between items-center py-2 border-b border-gray-100">
                <span className="text-textSecondary">Active Doctors</span>
                <span className="font-semibold text-textPrimary">{clinic.doctors}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-100">
                <span className="text-textSecondary">Today's Appointments</span>
                <span className="font-semibold text-textPrimary">{clinic.appointments}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-textSecondary">Inventory Alerts</span>
                <span className="bg-badgeOrange text-white text-xs font-bold px-2.5 py-0.5 rounded-full">
                  {clinic.alerts}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Clinic Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-gray-900/50 flex justify-center items-center p-4 z-50 animate-fade-in">
          {/* Backdrop click close */}
          <div className="fixed inset-0" onClick={() => setShowAddModal(false)} />

          <div className="bg-white rounded-xl border border-borderGray shadow-modal w-full max-w-lg p-6 relative z-10">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 text-textSecondary hover:text-textPrimary p-1.5 hover:bg-gray-50 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-18px font-bold text-textPrimary mb-6">Add New Clinic Branch</h2>

            <form onSubmit={handleAddClinic} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-textSecondary uppercase tracking-wider mb-1">
                  Clinic Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Northside Health Center"
                  value={newClinicName}
                  onChange={(e) => setNewClinicName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary uppercase tracking-wider mb-1">
                    Doctors
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={doctors}
                    onChange={(e) => setDoctors(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary uppercase tracking-wider mb-1">
                    Appointments
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={appointments}
                    onChange={(e) => setAppointments(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary uppercase tracking-wider mb-1">
                    Alerts
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={alerts}
                    onChange={(e) => setAlerts(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-md text-sm text-textPrimary focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-borderGray text-textSecondary font-semibold rounded-md hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primaryBlue hover:bg-[#1D4ED8] text-white font-semibold rounded-md transition-colors"
                >
                  Create Clinic
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
