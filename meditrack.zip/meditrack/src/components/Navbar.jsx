import React, { useState } from 'react';
import { HelpCircle, Bell, ChevronDown } from 'lucide-react';

export default function Navbar({ clinics, activeClinic, setActiveClinic }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-borderGray px-4 flex items-center justify-between z-40">
      {/* Left: Logo */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-lightBlueBg flex items-center justify-center text-primaryBlue font-bold">
          <svg
            className="w-5 h-5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </div>
        <span className="text-xl font-bold text-textPrimary tracking-tight">Meditrack</span>
      </div>

      {/* Center-Right: Tools and Dropdown */}
      <div className="flex items-center gap-6">
        {/* Clinic Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-2 px-3 py-1.5 border border-borderGray rounded-lg bg-white text-sm font-medium text-textPrimary hover:bg-gray-50 focus:outline-none focus:border-primaryBlue transition-all"
            id="clinic-dropdown-trigger"
          >
            <span>{activeClinic}</span>
            <ChevronDown className={`w-4 h-4 text-textSecondary transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </button>

          {isOpen && (
            <>
              {/* Backdrop to close */}
              <div
                className="fixed inset-0 z-10"
                onClick={() => setIsOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-56 rounded-lg border border-borderGray bg-white shadow-lg py-1 z-20">
                {clinics.map((clinic) => (
                  <button
                    key={clinic.name}
                    onClick={() => {
                      setActiveClinic(clinic.name);
                      setIsOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-sm transition-colors hover:bg-gray-50 ${
                      activeClinic === clinic.name
                        ? 'text-primaryBlue bg-lightBlueBg font-semibold'
                        : 'text-textPrimary'
                    }`}
                  >
                    {clinic.name}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Action Icons */}
        <div className="flex items-center gap-3 text-textSecondary">
          <button className="p-1.5 hover:text-textPrimary hover:bg-gray-50 rounded-full transition-all">
            <HelpCircle className="w-5 h-5" />
          </button>
          <button className="p-1.5 hover:text-textPrimary hover:bg-gray-50 rounded-full transition-all relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-badgeOrange rounded-full" />
          </button>
        </div>

        {/* User Profile Avatar */}
        <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center font-semibold text-sm select-none">
          M
        </div>
      </div>
    </nav>
  );
}
