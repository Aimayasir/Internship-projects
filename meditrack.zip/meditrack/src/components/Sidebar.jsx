import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Users, Calendar, MessageSquare, Settings, LogOut, DollarSign, Box, FileBarChart } from 'lucide-react';

export default function Sidebar({ showSecondary }) {
  const navigate = useNavigate();
  const location = useLocation();

  const primaryNavItems = [
    { id: 'home', icon: Home, label: 'Home', path: '/ClinicManagement' },
    { id: 'patients', icon: Users, label: 'Patients', path: '/PatientManagement' },
    { id: 'appointments', icon: Calendar, label: 'Appointments', path: '/Appointments' },
    { id: 'messages', icon: MessageSquare, label: 'Messages', path: '/Messages' },
    { id: 'settings', icon: Settings, label: 'Settings', path: '/Settings' },
  ];

  const secondaryNavItems = [
    { id: 'finance', icon: DollarSign, label: 'Finance', path: '/FinanceReporting' },
    { id: 'inventory', icon: Box, label: 'Inventory', path: '/Inventory' },
    { id: 'inventory-reporting-1', icon: FileBarChart, label: 'Inventory Reporting', path: '/InventoryReporting' },
    { id: 'inventory-reporting-2', icon: FileBarChart, label: 'Inventory Reporting', path: '/InventoryReporting' },
  ];

  const isPrimaryActive = (path) => {
    if (path === '#') return false;
    return location.pathname === path;
  };

  const isSecondaryActive = (path) => {
    if (path === '#') return false;
    return location.pathname === path;
  };

  return (
    <div className="flex fixed top-16 bottom-0 left-0 z-30 select-none">
      {/* 1. Narrow Left Sidebar (60px) */}
      <div className="w-[60px] bg-white border-r border-borderGray flex flex-col justify-between items-center py-4">
        {/* Top Icons */}
        <div className="flex flex-col gap-2 w-full items-center">
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const active = isPrimaryActive(item.path);

            return (
              <div key={item.id} className="relative group w-full flex justify-center">
                <button
                  onClick={() => item.path !== '#' && navigate(item.path)}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                    active
                      ? 'bg-lightBlueBg text-primaryBlue font-semibold'
                      : 'text-textSecondary hover:text-textPrimary hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </button>

                {/* Tooltip */}
                <div className="absolute left-14 top-1/2 -translate-y-1/2 scale-0 group-hover:scale-100 transition-all origin-left bg-gray-900 text-white text-xs font-medium px-2.5 py-1.5 rounded shadow-lg z-50 whitespace-nowrap">
                  {item.label}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Logout Icon */}
        <div className="relative group w-full flex justify-center">
          <button
            onClick={() => navigate('/login')}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-textSecondary hover:text-red-600 hover:bg-red-50 transition-all"
          >
            <LogOut className="w-5 h-5" />
          </button>
          <div className="absolute left-14 top-1/2 -translate-y-1/2 scale-0 group-hover:scale-100 transition-all origin-left bg-gray-900 text-white text-xs font-medium px-2.5 py-1.5 rounded shadow-lg z-50 whitespace-nowrap">
            Logout
          </div>
        </div>
      </div>

      {/* 2. Secondary Sidebar (220px) */}
      {showSecondary && (
        <div className="hidden md:flex w-[220px] bg-lightBlueBg border-r border-borderGray flex flex-col p-4">
          <div className="text-xs font-bold text-textSecondary uppercase tracking-wider mb-4 px-2">
            Other
          </div>
          <nav className="flex flex-col gap-1">
            {secondaryNavItems.map((item) => {
              const Icon = item.icon;
              const active = isSecondaryActive(item.path);

              return (
                <button
                  key={item.id}
                  onClick={() => item.path !== '#' && navigate(item.path)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    active
                      ? 'bg-white text-primaryBlue shadow-custom'
                      : 'text-textSecondary hover:text-textPrimary hover:bg-gray-100/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${active ? 'text-primaryBlue' : 'text-textSecondary'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </div>
  );
}
